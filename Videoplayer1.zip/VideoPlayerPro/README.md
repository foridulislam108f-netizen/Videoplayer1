# Video Player Pro

Native Android video player (Kotlin + Media3 ExoPlayer). Fullscreen, portrait & landscape.

## Features
- Full-screen immersive player, works in portrait and landscape, rotate button (long-press = auto rotate)
- Gestures: tap to show/hide controls, double-tap left/right = ∓10s, double-tap centre = play/pause,
  swipe left side = brightness, swipe right side = volume, swipe horizontally = seek,
  pinch = zoom, long-press = 2× speed
- Screen lock (unlock button stays reachable)
- Seek bar with buffered indicator, `mm:ss / h:mm:ss` time
- Playback speed 0.25× – 4×
- Aspect modes: Fit / Stretch / Crop / Fit width / Fit height
- Picture-in-Picture (auto-enters when you leave the app while playing)
- Audio track & embedded subtitle selection, external subtitles (.srt .vtt .ass .ssa .ttml), subtitle size
- Volume boost (+3 … +12 dB), sleep timer, repeat (off / one / all)
- Playlist (next / previous), resume from last position
- Local library list with thumbnails + search, multi-file picker, network stream (MP4, MKV, HLS .m3u8, DASH .mpd)
- Opens videos from other apps ("Open with"), video info dialog, keyboard / remote keys

## Build with GitHub Actions
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab → **Build APK** → it runs on every push (or press *Run workflow*).
3. Download `VideoPlayerPro-apk` from the finished run's **Artifacts** → unzip → install `VideoPlayerPro.apk`.
4. Optional: push a tag like `v1.0.0` and the APK is attached to a GitHub Release automatically.

## Build locally
Android Studio (Hedgehog or newer) → *Open* this folder → *Run*.
Or with Gradle 8.7+ and the Android SDK installed: `gradle assembleDebug`.

minSdk 26 (Android 8.0), targetSdk 34.
