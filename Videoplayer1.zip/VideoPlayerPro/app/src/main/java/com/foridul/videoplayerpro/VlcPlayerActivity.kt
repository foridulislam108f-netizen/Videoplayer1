package com.foridul.videoplayerpro

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale

/**
 * Universal fallback engine (libVLC). The main ExoPlayer screen hands over here whenever a file
 * cannot be decoded by the phone's hardware codecs (e.g. VP9 / AV1 / HEVC 2K-4K WebM / MKV, AVI,
 * FLV, WMV, MPEG-TS, DivX ...). libVLC decodes in software when needed.
 */
class VlcPlayerActivity : AppCompatActivity() {

    private var libVlc: LibVLC? = null
    private var vlc: MediaPlayer? = null
    private var pfd: ParcelFileDescriptor? = null

    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var controls: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var btnPlay: ImageButton
    private lateinit var seek: SeekBar
    private lateinit var tvTime: TextView
    private lateinit var tvTitle: TextView

    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private var controlsVisible = true
    private var fitMode = 0
    private var videoUri: android.net.Uri? = null
    private var reachedEnd = false

    private val ticker = object : Runnable {
        override fun run() {
            val p = vlc
            if (p != null && !userSeeking) {
                val len = p.length
                val t = p.time
                if (len > 0) {
                    seek.max = 1000
                    seek.progress = (t * 1000 / len).toInt().coerceIn(0, 1000)
                }
                tvTime.text = fmt(t) + " / " + fmt(len)
            }
            handler.postDelayed(this, 500)
        }
    }
    private val hideRunnable = Runnable { setControls(false) }

    private val pickSubtitle =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadExternalSubtitle(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val orient = OrientationPrefs.get(getSharedPreferences(OrientationPrefs.PREFS, MODE_PRIVATE))
        requestedOrientation = if (orient == OrientationPrefs.FIT)
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR
        else OrientationPrefs.activityInfoFor(orient)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()
        hideSystemBars()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = finish()
        })

        val uri = intent.data
        if (uri == null) {
            Toast.makeText(this, "No video", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        videoUri = uri
        tvTitle.text = intent.getStringExtra("title") ?: ""
        val passedMs = intent.getLongExtra("pos", 0L)
        val startMs = if (passedMs > 3000) passedMs else savedPosition()

        try {
            val args = arrayListOf(
                "--no-drop-late-frames",
                "--no-skip-frames",
                "--avcodec-skiploopfilter=0",
                "--network-caching=3000",
                "--file-caching=1500",
                "--audio-time-stretch",
                "--sub-text-scale=100"
            )
            val lib = LibVLC(this, args)
            libVlc = lib
            val player = MediaPlayer(lib)
            vlc = player
            player.attachViews(videoLayout, null, false, false)
            player.videoScale = MediaPlayer.ScaleType.SURFACE_BEST_FIT

            val media = if (uri.scheme == "content") {
                val d = contentResolver.openFileDescriptor(uri, "r")
                pfd = d
                Media(lib, d!!.fileDescriptor)
            } else {
                Media(lib, uri)
            }
            media.setHWDecoderEnabled(true, false) // hardware first, software if it fails
            media.addOption(":avcodec-hw=any")
            if (startMs > 3000) media.addOption(":start-time=" + String.format(Locale.US, "%.1f", startMs / 1000.0))
            player.media = media
            media.release()

            player.setEventListener { e ->
                when (e.type) {
                    MediaPlayer.Event.Playing, MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped ->
                        updatePlayIcon()
                    MediaPlayer.Event.EndReached -> { reachedEnd = true; clearResume(); updatePlayIcon(); setControls(true) }
                    MediaPlayer.Event.EncounteredError -> {
                        Toast.makeText(this, "This file cannot be played", Toast.LENGTH_LONG).show()
                    }
                }
            }
            player.play()
        } catch (t: Throwable) {
            Toast.makeText(this, "Player error: " + (t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        handler.post(ticker)
        scheduleHide()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun icon(res: Int, onClick: () -> Unit): ImageButton = ImageButton(this).apply {
        setImageResource(res)
        setBackgroundColor(Color.TRANSPARENT)
        setColorFilter(Color.WHITE)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        setOnClickListener { onClick(); scheduleHide() }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        videoLayout = VLCVideoLayout(this)
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        // tap anywhere = show / hide controls
        val tapLayer = View(this).apply { setOnClickListener { setControls(!controlsVisible) } }
        root.addView(tapLayer, FrameLayout.LayoutParams(-1, -1))

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(8), dp(28), dp(8), dp(8))
        }
        topBar.addView(icon(R.drawable.ic_back) { finish() })
        tvTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        topBar.addView(tvTitle, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(icon(R.drawable.ic_subtitles) { showSubtitleMenu() })
        topBar.addView(icon(R.drawable.ic_aspect) { cycleFit() })
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val len = vlc?.length ?: 0L
                        tvTime.text = fmt(len * p / 1000) + " / " + fmt(len)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar) { userSeeking = true; handler.removeCallbacks(hideRunnable) }
                override fun onStopTrackingTouch(s: SeekBar) {
                    val len = vlc?.length ?: 0L
                    if (len > 0) vlc?.time = len * s.progress / 1000
                    userSeeking = false
                    scheduleHide()
                }
            })
        }
        controls.addView(seek, LinearLayout.LayoutParams(-1, -2))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tvTime = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "00:00 / 00:00" }
        row.addView(tvTime, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(icon(R.drawable.ic_prev) { vlc?.let { it.time = (it.time - 10_000).coerceAtLeast(0) } })
        btnPlay = icon(R.drawable.ic_pause) { toggle() }
        row.addView(btnPlay)
        row.addView(icon(R.drawable.ic_next) { vlc?.let { it.time = it.time + 10_000 } })
        controls.addView(row, LinearLayout.LayoutParams(-1, -2))
        root.addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        setContentView(root, ViewGroup.LayoutParams(-1, -1))
    }

    private fun toggle() {
        val p = vlc ?: return
        if (p.isPlaying) p.pause() else p.play()
        updatePlayIcon()
    }

    private fun updatePlayIcon() {
        val playing = vlc?.isPlaying == true
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun showSubtitleMenu() {
        val p = vlc ?: return
        handler.removeCallbacks(hideRunnable)
        val items = arrayOf("Load subtitle file (.srt .vtt .ass)", "Subtitle tracks", "Subtitles off")
        AlertDialog.Builder(this)
            .setTitle("Subtitles")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pickSubtitle.launch(arrayOf("*/*"))
                    1 -> showSubtitleTracks(p)
                    2 -> { p.spuTrack = -1; Toast.makeText(this, "Subtitles off", Toast.LENGTH_SHORT).show() }
                }
            }
            .setOnDismissListener { scheduleHide() }
            .show()
    }

    private fun showSubtitleTracks(p: MediaPlayer) {
        val tracks = p.spuTracks?.filter { it.id >= 0 } ?: emptyList()
        if (tracks.isEmpty()) {
            Toast.makeText(this, "No subtitle tracks", Toast.LENGTH_SHORT).show()
            return
        }
        val names = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
        val cur = tracks.indexOfFirst { it.id == p.spuTrack }
        AlertDialog.Builder(this)
            .setTitle("Subtitle tracks")
            .setSingleChoiceItems(names, cur) { dlg, which ->
                p.spuTrack = tracks[which].id
                dlg.dismiss()
            }
            .show()
    }

    /** libVLC reads subtitles from a real file path, so copy the picked file into the cache first. */
    private fun loadExternalSubtitle(uri: android.net.Uri) {
        val p = vlc ?: return
        try {
            var name = "subtitle.srt"
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0)?.takeIf { n -> n.isNotBlank() }?.let { n -> name = n }
            }
            val ext = name.substringAfterLast('.', "srt").lowercase(Locale.ROOT).ifEmpty { "srt" }
            val dir = java.io.File(cacheDir, "subs").also { it.mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val f = java.io.File(dir, "sub_" + System.currentTimeMillis() + "." + ext)
            contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } }
                ?: throw java.io.IOException("cannot open file")
            val ok = p.addSlave(IMedia.Slave.Type.Subtitle, android.net.Uri.fromFile(f), true)
            Toast.makeText(this, if (ok) "Subtitle loaded" else "Could not load subtitle", Toast.LENGTH_SHORT).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Could not load subtitle", Toast.LENGTH_SHORT).show()
        }
    }

    private fun cycleFit() {
        val modes = arrayOf(
            MediaPlayer.ScaleType.SURFACE_BEST_FIT,
            MediaPlayer.ScaleType.SURFACE_FILL,
            MediaPlayer.ScaleType.SURFACE_FIT_SCREEN,
            MediaPlayer.ScaleType.SURFACE_16_9,
            MediaPlayer.ScaleType.SURFACE_4_3
        )
        val names = arrayOf("Fit", "Stretch", "Crop", "16:9", "4:3")
        fitMode = (fitMode + 1) % modes.size
        vlc?.videoScale = modes[fitMode]
        Toast.makeText(this, names[fitMode], Toast.LENGTH_SHORT).show()
    }

    private fun setControls(show: Boolean) {
        controlsVisible = show
        topBar.visibility = if (show) View.VISIBLE else View.GONE
        controls.visibility = if (show) View.VISIBLE else View.GONE
        if (show) scheduleHide()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        if (vlc?.isPlaying == true) handler.postDelayed(hideRunnable, 3500)
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun fmt(ms: Long): String {
        if (ms < 0) return "00:00"
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    // Same prefs file + key scheme as PlayerActivity, so both engines share resume positions.
    private fun resumeKey(u: android.net.Uri) = "pos_" + u.toString().hashCode()

    private fun savedPosition(): Long {
        val u = videoUri ?: return 0L
        val pos = getSharedPreferences("player_prefs", MODE_PRIVATE).getLong(resumeKey(u), 0L)
        return if (pos > 5000) pos else 0L
    }

    private fun clearResume() {
        val u = videoUri ?: return
        getSharedPreferences("player_prefs", MODE_PRIVATE).edit().remove(resumeKey(u)).apply()
    }

    private fun saveResume() {
        val u = videoUri ?: return
        val p = vlc ?: return
        if (reachedEnd) return
        val len = p.length
        val pos = p.time
        if (len <= 0 || pos < 0) return // not ready yet: keep whatever was saved before
        val e = getSharedPreferences("player_prefs", MODE_PRIVATE).edit()
        if (pos > 5000 && pos < len - 8000) e.putLong(resumeKey(u), pos) else e.remove(resumeKey(u))
        e.apply()
    }

    override fun onPause() {
        super.onPause()
        saveResume()
        vlc?.pause()
    }

    override fun onStop() {
        super.onStop()
        saveResume()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        saveResume()
        try {
            vlc?.setEventListener(null)
            vlc?.stop()
            vlc?.detachViews()
            vlc?.release()
            libVlc?.release()
        } catch (_: Throwable) {
        }
        vlc = null
        libVlc = null
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        super.onDestroy()
    }
}
