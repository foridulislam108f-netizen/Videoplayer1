package com.foridul.videoplayerpro

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Universal engine (libVLC). The main ExoPlayer screen hands over here whenever a file cannot be
 * decoded by the phone's hardware codecs (VP9 / AV1 / HEVC 2K-4K, AVI, FLV, WMV, TS, AC3/DTS audio ...).
 *
 * This screen has the SAME controls as the ExoPlayer screen: audio / subtitle menus, More menu
 * (repeat, sleep timer, volume boost, orientation, video info), speed, rotate, aspect, lock, PiP,
 * previous / next video, +-10 s, and swipe gestures (brightness, volume, seek, double-tap seek).
 */
class VlcPlayerActivity : AppCompatActivity() {

    private var libVlc: LibVLC? = null
    private var vlc: MediaPlayer? = null
    private var pfd: ParcelFileDescriptor? = null

    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var controls: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var btnPlay: ImageButton
    private lateinit var btnLock: ImageButton
    private lateinit var btnUnlock: ImageButton
    private lateinit var seek: SeekBar
    private lateinit var tvTime: TextView
    private lateinit var tvTitle: TextView
    private lateinit var hud: TextView
    private lateinit var loading: ProgressBar

    private val handler = Handler(Looper.getMainLooper())
    private var userSeeking = false
    private var controlsVisible = true
    private var locked = false
    private var inPip = false
    private var fitMode = 0
    private var reachedEnd = false

    // playlist
    private var uris: List<Uri> = emptyList()
    private var titles: List<String> = emptyList()
    private var index = 0
    private var videoUri: Uri? = null

    // settings
    private var speed = 1f
    private var audioDelayMs = 0L
    private var subDelayMs = 0L
    private var volumePct = 100
    private var repeatMode = 0 // 0 off, 1 this video, 2 all
    private var orientMode = OrientationPrefs.SYSTEM
    private var sleepRunnable: Runnable? = null

    // gestures
    private enum class G { NONE, SEEK, BRIGHT, VOL }
    private var gesture = G.NONE
    private var gBase = 0L
    private var gDelta = 0L
    private var gTarget = 0L
    private var gFloat = 0f

    private val ticker = object : Runnable {
        override fun run() {
            val p = vlc
            if (p != null && !userSeeking && gesture != G.SEEK) {
                val len = p.length
                val t = p.time
                if (len > 0) {
                    seek.max = 1000
                    seek.progress = (t * 1000 / len).toInt().coerceIn(0, 1000)
                }
                tvTime.text = fmt(t) + " / " + fmt(len)
            }
            handler.postDelayed(this, 500)
        }
    }
    private val hideRunnable = Runnable { setControls(false) }
    private val hideHud = Runnable { hud.visibility = View.GONE }

    private val pickSubtitle =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadExternalSubtitle(uri)
        }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(OrientationPrefs.PREFS, MODE_PRIVATE)
        orientMode = OrientationPrefs.get(prefs)
        requestedOrientation = if (orientMode == OrientationPrefs.FIT) ActivityInfo.SCREEN_ORIENTATION_SENSOR
        else OrientationPrefs.activityInfoFor(orientMode)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        buildUi()
        hideSystemBars()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = finish()
        })

        // playlist from the main player (falls back to the single file in intent.data)
        val list = intent.getStringArrayListExtra(PlayerActivity.EXTRA_URIS)
        if (!list.isNullOrEmpty()) {
            uris = list.map { Uri.parse(it) }
            titles = intent.getStringArrayListExtra(PlayerActivity.EXTRA_TITLES) ?: arrayListOf()
            index = intent.getIntExtra(PlayerActivity.EXTRA_INDEX, 0).coerceIn(0, uris.lastIndex)
        } else {
            val u = intent.data
            if (u == null) {
                Toast.makeText(this, "No video", Toast.LENGTH_SHORT).show()
                finish()
                return
            }
            uris = listOf(u)
            titles = listOf(intent.getStringExtra("title") ?: "")
            index = 0
        }

        try {
            val args = arrayListOf(
                "--no-drop-late-frames",
                "--no-skip-frames",
                "--avcodec-skiploopfilter=0",
                "--network-caching=3000",
                "--file-caching=1500",
                "--audio-time-stretch",
                "--sub-text-scale=100"
            )
            val lib = LibVLC(this, args)
            libVlc = lib
            val player = MediaPlayer(lib)
            vlc = player
            player.attachViews(videoLayout, null, false, false)
            player.videoScale = MediaPlayer.ScaleType.SURFACE_BEST_FIT

            // SOUND FIX 1: never send AC3/E-AC3/DTS/TrueHD out as raw "digital passthrough" - phones
            // cannot play that, which is the classic "picture but no sound" case. Always decode.
            runCatching { player.setAudioDigitalOutputEnabled(false) }
            // SOUND FIX 2: user-selectable audio output (menu: Audio > Audio output)
            val aout = getSharedPreferences("player_prefs", MODE_PRIVATE).getString(KEY_AOUT, "") ?: ""
            if (aout.isNotEmpty()) runCatching { player.setAudioOutput(aout) }

            player.setEventListener { e ->
                when (e.type) {
                    MediaPlayer.Event.Playing -> {
                        loading.visibility = View.GONE
                        updatePlayIcon()
                        initialSub?.let { s ->
                            initialSub = null
                            val path = Uri.parse(s).path
                            if (path != null) handler.postDelayed({ attachSubtitle(java.io.File(path), false) }, 700)
                        }
                        ensureAudio()
                        runCatching { if (speed != 1f) { vlc?.setRate(speed) } }
                        handler.postDelayed({ ensureAudio() }, 800)
                        handler.postDelayed({ ensureAudio() }, 2500)
                    }
                    MediaPlayer.Event.ESAdded -> ensureAudio()
                    MediaPlayer.Event.Buffering -> {
                        loading.visibility = if (e.buffering < 100f && vlc?.isPlaying != true) View.VISIBLE else View.GONE
                    }
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> updatePlayIcon()
                    MediaPlayer.Event.EndReached -> onEnded()
                    MediaPlayer.Event.EncounteredError -> {
                        loading.visibility = View.GONE
                        Toast.makeText(this, "This file cannot be played", Toast.LENGTH_LONG).show()
                    }
                }
            }

            initialSub = intent.getStringExtra("sub")
            val passedMs = intent.getLongExtra("pos", 0L)
            playIndex(index, if (passedMs > 3000) passedMs else savedPosition())
        } catch (t: Throwable) {
            Toast.makeText(this, "Player error: " + (t.message ?: t.javaClass.simpleName), Toast.LENGTH_LONG).show()
            finish()
            return
        }
        handler.post(ticker)
        scheduleHide()
    }

    /** Load video number [i] of the playlist and start it. */
    private fun playIndex(i: Int, startMs: Long) {
        val lib = libVlc ?: return
        val p = vlc ?: return
        val uri = uris.getOrNull(i) ?: return
        index = i
        videoUri = uri
        tvTitle.text = titles.getOrNull(i) ?: ""
        reachedEnd = false
        audioDelayMs = 0
        subDelayMs = 0
        loading.visibility = View.VISIBLE
        runCatching { p.stop() }
        val oldPfd = pfd
        pfd = null
        try {
            val media = if (uri.scheme == "content") {
                val d = contentResolver.openFileDescriptor(uri, "r")
                pfd = d
                Media(lib, d!!.fileDescriptor)
            } else {
                Media(lib, uri)
            }
            media.setHWDecoderEnabled(true, false) // hardware first, software if it fails
            media.addOption(":avcodec-hw=any")
            if (startMs > 3000) media.addOption(":start-time=" + String.format(Locale.US, "%.1f", startMs / 1000.0))
            p.media = media
            media.release()
            p.play()
        } catch (t: Throwable) {
            loading.visibility = View.GONE
            toast("Cannot open this video")
        }
        try { oldPfd?.close() } catch (_: Throwable) {}
        updateNavAlpha()
    }

    /**
     * SOUND FIX 3: make sure an audio track is really selected and the volume is up. libVLC often
     * reports the tracks a moment AFTER "Playing", so this is re-run when tracks are added.
     */
    private fun ensureAudio() {
        val p = vlc ?: return
        runCatching {
            val tracks = p.audioTracks?.filter { it.id >= 0 } ?: emptyList()
            if (tracks.isNotEmpty() && tracks.none { it.id == p.audioTrack }) {
                p.audioTrack = tracks.first().id
            }
            p.volume = volumePct
        }
    }

    private fun onEnded() {
        updatePlayIcon()
        when {
            repeatMode == 1 -> playIndex(index, 0)
            index < uris.lastIndex -> { clearResume(); playIndex(index + 1, 0) }
            repeatMode == 2 && uris.size > 1 -> { clearResume(); playIndex(0, 0) }
            repeatMode == 2 -> playIndex(index, 0)
            else -> { reachedEnd = true; clearResume(); setControls(true) }
        }
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun icon(res: Int, size: Int = 52, onClick: () -> Unit): ImageButton = ImageButton(this).apply {
        setImageResource(res)
        setBackgroundColor(Color.TRANSPARENT)
        setColorFilter(Color.WHITE)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        setOnClickListener { onClick(); scheduleHide() }
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        videoLayout = VLCVideoLayout(this)
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        // gesture layer: tap = controls, double-tap = +-10 s / play, swipes = brightness / volume / seek
        val gestureLayer = View(this)
        setupGestures(gestureLayer)
        root.addView(gestureLayer, FrameLayout.LayoutParams(-1, -1))

        // ---- top bar
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(8), dp(28), dp(8), dp(8))
        }
        topBar.addView(icon(R.drawable.ic_back) { finish() })
        tvTitle = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        topBar.addView(tvTitle, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(icon(R.drawable.ic_audiotrack) { showAudioMenu() })
        topBar.addView(icon(R.drawable.ic_subtitles) { showSubtitleMenu() })
        topBar.addView(icon(R.drawable.ic_more) { showMoreDialog() })
        root.addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- bottom controls
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x99000000.toInt())
            setPadding(dp(12), dp(8), dp(12), dp(24))
        }
        seek = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val len = vlc?.length ?: 0L
                        tvTime.text = fmt(len * p / 1000) + " / " + fmt(len)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar) { userSeeking = true; handler.removeCallbacks(hideRunnable) }
                override fun onStopTrackingTouch(s: SeekBar) {
                    val len = vlc?.length ?: 0L
                    if (len > 0) vlc?.time = len * s.progress / 1000
                    userSeeking = false
                    scheduleHide()
                }
            })
        }
        controls.addView(seek, LinearLayout.LayoutParams(-1, -2))
        tvTime = TextView(this).apply { setTextColor(Color.WHITE); textSize = 13f; text = "00:00 / 00:00" }
        controls.addView(tvTime, LinearLayout.LayoutParams(-2, -2))

        // transport row: previous video, -10 s, play/pause, +10 s, next video
        val transport = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        transport.addView(icon(R.drawable.ic_prev, 56) { previous() }.also { btnPrev = it })
        transport.addView(icon(R.drawable.ic_rewind, 56) { seekBy(-10_000) })
        btnPlay = icon(R.drawable.ic_pause, 64) { toggle() }
        transport.addView(btnPlay)
        transport.addView(icon(R.drawable.ic_fast_forward, 56) { seekBy(10_000) })
        transport.addView(icon(R.drawable.ic_next, 56) { next() }.also { btnNext = it })
        controls.addView(transport, LinearLayout.LayoutParams(-1, -2))

        // tools row: lock, speed, rotate, aspect, PiP
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        fun tool(res: Int, onClick: () -> Unit) {
            val b = icon(res, 48, onClick)
            b.layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
            tools.addView(b)
        }
        tool(R.drawable.ic_lock) { setLocked(true) }
        tool(R.drawable.ic_rotate) { rotateScreen() }
        tool(R.drawable.ic_aspect) { cycleFit() }
        tool(R.drawable.ic_pip) { enterPip() }
        controls.addView(tools, LinearLayout.LayoutParams(-1, -2))
        root.addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))

        // unlock button (visible only while locked)
        btnUnlock = ImageButton(this).apply {
            setImageResource(R.drawable.ic_unlock)
            setColorFilter(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()) }
            setPadding(dp(14), dp(14), dp(14), dp(14))
            visibility = View.GONE
            setOnClickListener { setLocked(false) }
        }
        root.addView(btnUnlock, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER_VERTICAL or Gravity.START).apply { leftMargin = dp(24) })

        // centre HUD (brightness / volume / seek / speed ...)
        hud = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(12), dp(22), dp(12))
            background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(0xB3000000.toInt()) }
            visibility = View.GONE
        }
        root.addView(hud, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

        loading = ProgressBar(this).apply { visibility = View.GONE }
        root.addView(loading, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.CENTER))

        setContentView(root, ViewGroup.LayoutParams(-1, -1))
    }

    private lateinit var btnPrev: ImageButton
    private lateinit var btnNext: ImageButton

    private fun updateNavAlpha() {
        if (!::btnPrev.isInitialized) return
        btnPrev.alpha = if (index > 0) 1f else 0.4f
        btnNext.alpha = if (index < uris.lastIndex) 1f else 0.4f
    }

    private fun showHud(text: String) {
        hud.text = text
        hud.visibility = View.VISIBLE
        handler.removeCallbacks(hideHud)
        handler.postDelayed(hideHud, 900)
    }

    // ------------------------------------------------------------------ gestures

    private fun setupGestures(layer: View) {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) showUnlockTemporarily() else setControls(!controlsVisible)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = layer.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-10_000)
                    e.x > w * 2f / 3f -> seekBy(10_000)
                    else -> toggle()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || e1 == null || inPip) return false
                val p = vlc ?: return false
                if (gesture == G.NONE) {
                    gesture = when {
                        abs(e2.x - e1.x) > abs(e2.y - e1.y) -> G.SEEK
                        e1.x < layer.width / 2f -> G.BRIGHT
                        else -> G.VOL
                    }
                    when (gesture) {
                        G.SEEK -> { gBase = p.time; gDelta = 0; gTarget = gBase }
                        G.BRIGHT -> {
                            val b = window.attributes.screenBrightness
                            gFloat = if (b < 0f) 0.5f else b
                        }
                        G.VOL -> {
                            val am = getSystemService(AUDIO_SERVICE) as AudioManager
                            gFloat = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                        }
                        else -> {}
                    }
                }
                when (gesture) {
                    G.SEEK -> {
                        val len = p.length
                        if (len > 0) {
                            gDelta += (-dx * 120).toLong()
                            gTarget = (gBase + gDelta).coerceIn(0, len)
                            val d = (gTarget - gBase) / 1000
                            showHud(fmt(gTarget) + "  (" + (if (d >= 0) "+" else "") + d + "s)")
                        }
                    }
                    G.BRIGHT -> {
                        gFloat = (gFloat + dy / layer.height * 1.3f).coerceIn(0.02f, 1f)
                        val lp = window.attributes
                        lp.screenBrightness = gFloat
                        window.attributes = lp
                        showHud("Brightness " + (gFloat * 100).roundToInt() + "%")
                    }
                    G.VOL -> {
                        val am = getSystemService(AUDIO_SERVICE) as AudioManager
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        gFloat = (gFloat + dy / layer.height * max * 1.3f).coerceIn(0f, max.toFloat())
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, gFloat.roundToInt(), 0)
                        showHud("Volume " + (gFloat / max * 100).roundToInt() + "%")
                    }
                    else -> {}
                }
                return true
            }
        })
        layer.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (gesture == G.SEEK) vlc?.time = gTarget
                gesture = G.NONE
            }
            true
        }
    }

    // ------------------------------------------------------------------ transport

    private fun toggle() {
        val p = vlc ?: return
        if (reachedEnd) { reachedEnd = false; playIndex(index, 0); return }
        if (p.isPlaying) p.pause() else p.play()
        updatePlayIcon()
    }

    private fun updatePlayIcon() {
        val playing = vlc?.isPlaying == true
        btnPlay.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun seekBy(ms: Long) {
        val p = vlc ?: return
        val len = p.length
        val t = (p.time + ms).coerceAtLeast(0)
        p.time = if (len > 0) t.coerceAtMost(len - 300) else t
        showHud((if (ms > 0) "+" else "") + (ms / 1000) + "s")
    }

    private fun previous() {
        val p = vlc ?: return
        if (p.time > 3000 || index == 0) { p.time = 0; return }
        saveResume()
        playIndex(index - 1, 0)
    }

    private fun next() {
        if (index >= uris.lastIndex) { toast("This is the last video"); return }
        saveResume()
        playIndex(index + 1, 0)
    }

    // ------------------------------------------------------------------ lock / controls

    private fun setLocked(l: Boolean) {
        locked = l
        if (l) {
            setControls(false)
            showUnlockTemporarily()
            showHud("Locked")
        } else {
            btnUnlock.visibility = View.GONE
            setControls(true)
            showHud("Unlocked")
        }
    }

    private fun showUnlockTemporarily() {
        btnUnlock.visibility = View.VISIBLE
        handler.removeCallbacks(hideUnlock)
        handler.postDelayed(hideUnlock, 2500)
    }

    private val hideUnlock = Runnable { if (locked) btnUnlock.visibility = View.GONE }

    private fun setControls(show: Boolean) {
        if (locked && show) return
        controlsVisible = show
        topBar.visibility = if (show) View.VISIBLE else View.GONE
        controls.visibility = if (show) View.VISIBLE else View.GONE
        if (show) scheduleHide() else hideSystemBars()
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        if (vlc?.isPlaying == true) handler.postDelayed(hideRunnable, 3500)
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showDialog(builder: ModernDialog.Builder) {
        handler.removeCallbacks(hideRunnable)
        val d = builder.create()
        d.setOnDismissListener {
            hideSystemBars()
            scheduleHide()
        }
        d.show()
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    // ------------------------------------------------------------------ speed / aspect / rotate / PiP

    private fun showSpeedDialog() {
        val values = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 3f, 4f)
        val labels = values.map { (if (it == it.toInt().toFloat()) it.toInt().toString() else it.toString()) + "x" }.toTypedArray()
        val cur = values.indexOfFirst { abs(it - speed) < 0.01f }
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Playback speed")
                .setSingleChoiceItems(labels, cur) { dlg, which ->
                    speed = values[which]
                    vlc?.setRate(speed)
                    showHud("Speed " + labels[which])
                    dlg.dismiss()
                }
        )
    }

    private fun cycleFit() {
        val modes = arrayOf(
            MediaPlayer.ScaleType.SURFACE_BEST_FIT,
            MediaPlayer.ScaleType.SURFACE_FILL,
            MediaPlayer.ScaleType.SURFACE_FIT_SCREEN,
            MediaPlayer.ScaleType.SURFACE_16_9,
            MediaPlayer.ScaleType.SURFACE_4_3
        )
        val names = arrayOf("Fit", "Stretch", "Crop", "16:9", "4:3")
        fitMode = (fitMode + 1) % modes.size
        vlc?.videoScale = modes[fitMode]
        showHud(names[fitMode])
    }

    private fun rotateScreen() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        requestedOrientation = if (land) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26 || !packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            toast("Picture-in-picture is not supported on this phone")
            return
        }
        try {
            val t = runCatching { vlc?.currentVideoTrack }.getOrNull()
            var w = t?.width ?: 16
            var h = t?.height ?: 9
            if (w <= 0 || h <= 0) { w = 16; h = 9 }
            val ratio = (w.toFloat() / h).coerceIn(0.42f, 2.38f)
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational((ratio * 1000).toInt(), 1000))
                .build()
            setControls(false)
            enterPictureInPictureMode(params)
        } catch (t: Throwable) {
            toast("Cannot enter picture-in-picture")
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (vlc?.isPlaying == true && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            topBar.visibility = View.GONE
            controls.visibility = View.GONE
            btnUnlock.visibility = View.GONE
        } else {
            setControls(true)
        }
    }

    // ------------------------------------------------------------------ audio menu

    private fun showAudioMenu() {
        val p = vlc ?: return
        val aout = getSharedPreferences("player_prefs", MODE_PRIVATE).getString(KEY_AOUT, "") ?: ""
        val aoutName = when (aout) { "audiotrack" -> "AudioTrack"; "opensles_android" -> "OpenSL ES"; else -> "Automatic" }
        val items = arrayOf(
            "Audio track",
            "Audio delay: ${audioDelayMs} ms  (+100 ms)",
            "Audio delay: -100 ms",
            "Reset audio delay",
            "Volume boost: ${volumePct}%",
            "Audio output: $aoutName  (use if there is no sound)"
        )
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Audio")
                .setItems(items) { dlg, which ->
                    dlg.dismiss()
                    when (which) {
                        0 -> showAudioTracks(p)
                        1 -> { audioDelayMs += 100; p.setAudioDelay(audioDelayMs * 1000); showHud("Audio delay $audioDelayMs ms") }
                        2 -> { audioDelayMs -= 100; p.setAudioDelay(audioDelayMs * 1000); showHud("Audio delay $audioDelayMs ms") }
                        3 -> { audioDelayMs = 0; p.setAudioDelay(0); showHud("Audio delay reset") }
                        4 -> showBoostDialog()
                        5 -> showAoutDialog()
                    }
                }
        )
    }

    private fun showAudioTracks(p: MediaPlayer) {
        val tracks = p.audioTracks?.filter { it.id >= 0 } ?: emptyList()
        if (tracks.isEmpty()) { toast("No audio tracks"); return }
        val names = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
        val cur = tracks.indexOfFirst { it.id == p.audioTrack }
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Audio track")
                .setSingleChoiceItems(names, cur) { dlg, which ->
                    p.audioTrack = tracks[which].id
                    dlg.dismiss()
                }
        )
    }

    private fun showBoostDialog() {
        val values = intArrayOf(100, 125, 150, 175, 200)
        val labels = values.map { "$it%" }.toTypedArray()
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Volume boost")
                .setSingleChoiceItems(labels, values.indexOf(volumePct)) { dlg, which ->
                    volumePct = values[which]
                    vlc?.volume = volumePct
                    showHud("Volume boost $volumePct%")
                    dlg.dismiss()
                }
        )
    }

    /** Switch the Android audio output and restart the video at the same spot. */
    private fun showAoutDialog() {
        val keys = arrayOf("", "audiotrack", "opensles_android")
        val labels = arrayOf("Automatic", "AudioTrack", "OpenSL ES")
        val prefs = getSharedPreferences("player_prefs", MODE_PRIVATE)
        val cur = keys.indexOf(prefs.getString(KEY_AOUT, "") ?: "").coerceAtLeast(0)
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Audio output")
                .setSingleChoiceItems(labels, cur) { dlg, which ->
                    dlg.dismiss()
                    prefs.edit().putString(KEY_AOUT, keys[which]).apply()
                    val p = vlc ?: return@setSingleChoiceItems
                    val pos = p.time
                    runCatching { p.stop() }
                    if (keys[which].isNotEmpty()) runCatching { p.setAudioOutput(keys[which]) }
                    runCatching { p.setAudioDigitalOutputEnabled(false) }
                    showHud("Audio output: " + labels[which])
                    handler.postDelayed({ playIndex(index, pos) }, 300)
                }
        )
    }

    // ------------------------------------------------------------------ subtitles

    private fun showSubtitleMenu() {
        val p = vlc ?: return
        val items = arrayOf(
            "Load subtitle file (.srt .vtt .ass)",
            "Subtitle tracks",
            "Subtitle delay: ${subDelayMs} ms  (+100 ms)",
            "Subtitle delay: -100 ms",
            "Reset subtitle delay",
            "Subtitles off"
        )
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Subtitles")
                .setItems(items) { dlg, which ->
                    dlg.dismiss()
                    when (which) {
                        0 -> pickSubtitle.launch(arrayOf("*/*"))
                        1 -> showSubtitleTracks(p)
                        2 -> { subDelayMs += 100; p.setSpuDelay(subDelayMs * 1000); showHud("Subtitle delay $subDelayMs ms") }
                        3 -> { subDelayMs -= 100; p.setSpuDelay(subDelayMs * 1000); showHud("Subtitle delay $subDelayMs ms") }
                        4 -> { subDelayMs = 0; p.setSpuDelay(0); showHud("Subtitle delay reset") }
                        5 -> { p.spuTrack = -1; showHud("Subtitles off") }
                    }
                }
        )
    }

    private fun showSubtitleTracks(p: MediaPlayer) {
        val tracks = p.spuTracks?.filter { it.id >= 0 } ?: emptyList()
        if (tracks.isEmpty()) { toast("No subtitle tracks"); return }
        val names = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
        val cur = tracks.indexOfFirst { it.id == p.spuTrack }
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Subtitle tracks")
                .setSingleChoiceItems(names, cur) { dlg, which ->
                    p.spuTrack = tracks[which].id
                    dlg.dismiss()
                }
        )
    }

    private var subGen = 0
    private var initialSub: String? = null

    /** libVLC reads subtitles from a real file path, so the picked file is copied (as clean UTF-8) first. */
    private fun loadExternalSubtitle(uri: Uri) {
        val r = SubtitleUtil.importToCache(this, uri)
        if (r == null) {
            toast("Could not load subtitle")
            return
        }
        attachSubtitle(r.file, true)
    }

    /**
     * addSlave() alone is unreliable: the player may be paused (the file picker paused it) or the
     * track is registered a moment later, so it was often not selected. Add it, then wait until the
     * NEW subtitle track shows up and select it explicitly; add once more if it never appears.
     */
    private fun attachSubtitle(f: java.io.File, announce: Boolean) {
        val p = vlc ?: return
        subGen++
        val gen = subGen
        val before = p.spuTracks?.map { it.id }?.toSet() ?: emptySet()
        p.addSlave(IMedia.Slave.Type.Subtitle, Uri.fromFile(f), true)
        pollSubtitle(gen, before, 0, f, announce)
    }

    private fun pollSubtitle(gen: Int, before: Set<Int>, n: Int, f: java.io.File, announce: Boolean) {
        if (gen != subGen) return
        val p = vlc ?: return
        val fresh = p.spuTracks?.firstOrNull { it.id >= 0 && it.id !in before }
        if (fresh != null) {
            p.spuTrack = fresh.id
            if (announce) toast("Subtitle loaded")
            return
        }
        if (n >= 14) {
            if (announce) toast("Could not load subtitle")
            return
        }
        if (n == 6) p.addSlave(IMedia.Slave.Type.Subtitle, Uri.fromFile(f), true)
        handler.postDelayed({ pollSubtitle(gen, before, n + 1, f, announce) }, 300)
    }

    // ------------------------------------------------------------------ More menu

    private fun showMoreDialog() {
        val repeatLabel = when (repeatMode) {
            1 -> "Repeat: this video"
            2 -> "Repeat: all videos"
            else -> "Repeat: off"
        }
        val items = arrayOf(
            repeatLabel,
            "Sleep timer" + if (sleepRunnable != null) " (on)" else "",
            "Volume boost: ${volumePct}%",
            "Screen orientation: " + OrientationPrefs.NAMES[orientMode],
            "Video info"
        )
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("More")
                .setItems(items) { dlg, which ->
                    dlg.dismiss()
                    when (which) {
                        0 -> {
                            repeatMode = (repeatMode + 1) % 3
                            showHud(when (repeatMode) { 1 -> "Repeat this video"; 2 -> "Repeat all"; else -> "Repeat off" })
                        }
                        1 -> showSleepDialog()
                        2 -> showBoostDialog()
                        3 -> showOrientationDialog()
                        4 -> showVideoInfo()
                    }
                }
        )
    }

    private fun showSleepDialog() {
        val labels = arrayOf("Off", "10 minutes", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        val mins = intArrayOf(0, 10, 15, 30, 45, 60, 90)
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Sleep timer")
                .setItems(labels) { dlg, which ->
                    dlg.dismiss()
                    sleepRunnable?.let { handler.removeCallbacks(it) }
                    sleepRunnable = null
                    if (mins[which] > 0) {
                        val r = Runnable {
                            vlc?.pause()
                            sleepRunnable = null
                            Toast.makeText(this, "Sleep timer: paused", Toast.LENGTH_LONG).show()
                        }
                        sleepRunnable = r
                        handler.postDelayed(r, mins[which] * 60_000L)
                        showHud("Sleep in ${mins[which]} min")
                    } else {
                        showHud("Sleep timer off")
                    }
                }
        )
    }

    private fun showOrientationDialog() {
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Screen orientation")
                .setSingleChoiceItems(OrientationPrefs.NAMES, orientMode) { dlg, which ->
                    orientMode = which
                    OrientationPrefs.set(getSharedPreferences(OrientationPrefs.PREFS, MODE_PRIVATE), which)
                    requestedOrientation = if (which == OrientationPrefs.FIT) ActivityInfo.SCREEN_ORIENTATION_SENSOR
                    else OrientationPrefs.activityInfoFor(which)
                    dlg.dismiss()
                }
        )
    }

    private fun showVideoInfo() {
        val p = vlc ?: return
        val sb = StringBuilder()
        sb.append("Title: ").append(titles.getOrNull(index) ?: "-").append('\n')
        sb.append("Duration: ").append(fmt(p.length)).append('\n')
        runCatching {
            val m = p.media
            if (m != null) {
                for (i in 0 until m.trackCount) {
                    val t = m.getTrack(i)
                    when (t.type) {
                        IMedia.Track.Type.Video -> {
                            val v = t as IMedia.VideoTrack
                            sb.append("Video: ").append(v.width).append('×').append(v.height)
                            if (v.frameRateDen > 0 && v.frameRateNum > 0)
                                sb.append(" @ ").append(String.format(Locale.US, "%.2f", v.frameRateNum.toFloat() / v.frameRateDen)).append(" fps")
                            sb.append('\n')
                            if (!t.codec.isNullOrEmpty()) sb.append("Video codec: ").append(t.codec).append('\n')
                            if (t.bitrate > 0) sb.append("Video bitrate: ").append(t.bitrate / 1000).append(" kbps\n")
                        }
                        IMedia.Track.Type.Audio -> {
                            val a = t as IMedia.AudioTrack
                            if (!t.codec.isNullOrEmpty()) sb.append("Audio codec: ").append(t.codec).append('\n')
                            if (a.channels > 0) sb.append("Channels: ").append(a.channels).append('\n')
                            if (a.rate > 0) sb.append("Sample rate: ").append(a.rate).append(" Hz\n")
                        }
                        else -> {}
                    }
                }
                m.release()
            }
        }
        sb.append("Engine: libVLC\n")
        sb.append("Source: ").append(uris.getOrNull(index) ?: "-")
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Video info")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
        )
    }

    // ------------------------------------------------------------------ keys

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && !locked) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { toggle(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> { seekBy(-10_000); return true }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seekBy(10_000); return true }
                KeyEvent.KEYCODE_MEDIA_NEXT -> { next(); return true }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { previous(); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    // ------------------------------------------------------------------ helpers / resume

    private fun fmt(ms: Long): String {
        if (ms < 0) return "00:00"
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    // Same prefs file + key scheme as PlayerActivity, so both engines share resume positions.
    private fun resumeKey(u: Uri) = "pos_" + u.toString().hashCode()

    private fun savedPosition(): Long {
        val u = videoUri ?: uris.getOrNull(index) ?: return 0L
        val pos = getSharedPreferences("player_prefs", MODE_PRIVATE).getLong(resumeKey(u), 0L)
        return if (pos > 5000) pos else 0L
    }

    private fun clearResume() {
        val u = videoUri ?: return
        getSharedPreferences("player_prefs", MODE_PRIVATE).edit().remove(resumeKey(u)).apply()
    }

    private fun saveResume() {
        val u = videoUri ?: return
        val p = vlc ?: return
        if (reachedEnd) return
        val len = p.length
        val pos = p.time
        if (len <= 0 || pos < 0) return // not ready yet: keep whatever was saved before
        val e = getSharedPreferences("player_prefs", MODE_PRIVATE).edit()
        if (pos > 5000 && pos < len - 8000) e.putLong(resumeKey(u), pos) else e.remove(resumeKey(u))
        e.apply()
    }

    override fun onPause() {
        super.onPause()
        saveResume()
        // keep playing while in picture-in-picture
        val pip = Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode
        if (!pip) vlc?.pause()
    }

    override fun onStop() {
        super.onStop()
        saveResume()
        // the PiP window was closed with its X button
        if (Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode) {
            vlc?.pause()
            finish()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        saveResume()
        try {
            vlc?.setEventListener(null)
            vlc?.stop()
            vlc?.detachViews()
            vlc?.release()
            libVlc?.release()
        } catch (_: Throwable) {
        }
        vlc = null
        libVlc = null
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        super.onDestroy()
    }

    companion object {
        private const val KEY_AOUT = "vlc_aout"
    }
}
