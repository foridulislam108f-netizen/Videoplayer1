package com.foridul.videoplayerpro

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.foridul.videoplayerpro.databinding.ItemFolderBinding

data class FolderItem(
    val name: String,
    val path: String,
    val videoCount: Int,
    val videos: List<VideoItem>
)

class FolderAdapter(
    private val onFolderClick: (FolderItem) -> Unit,
    private val onMoreClick: (FolderItem, View) -> Unit
) : RecyclerView.Adapter<FolderAdapter.VH>() {

    private var items: List<FolderItem> = emptyList()
    var isAudioMode: Boolean = false

    fun submit(list: List<FolderItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun count() = items.size

    class VH(val b: ItemFolderBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemFolderBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.b.tvFolderName.text = item.name

        val unit = if (isAudioMode) {
            if (item.videoCount == 1) "1 song" else "${item.videoCount} songs"
        } else {
            if (item.videoCount == 1) "1 video" else "${item.videoCount} videos"
        }
        holder.b.tvVideoCount.text = unit

        if (item.videoCount >= 10) {
            holder.b.tvBadge.visibility = View.VISIBLE
            holder.b.tvBadge.text = if (item.videoCount > 99) "99+" else item.videoCount.toString()
        } else {
            holder.b.tvBadge.visibility = View.GONE
        }

        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onFolderClick(items[pos])
        }
        holder.b.btnMore.setOnClickListener {
            onMoreClick(item, it)
        }
    }
}
