package com.foridul.videoplayerpro

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.MimeTypes
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.util.Locale

/**
 * Subtitle import helper used by both players.
 *
 * Why: reading the picked file straight from its content:// address is unreliable (permission can be
 * gone after the picker closes, wrong file extension -> wrong parser, non-UTF-8 text -> empty/garbled
 * subtitle). So the file is copied once into the app cache as clean UTF-8 with the correct extension
 * and MIME type detected from the CONTENT, then both ExoPlayer and libVLC load that local copy.
 */
object SubtitleUtil {

    class Result(val file: File, val name: String, val mime: String)

    fun importToCache(ctx: Context, uri: Uri): Result? {
        return try {
            var name = ""
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) name = it.getString(0) ?: ""
                }
            } catch (_: Exception) {
            }
            if (name.isBlank()) name = uri.lastPathSegment ?: "subtitle.srt"

            val raw = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
            if (raw.isEmpty()) return null
            val text = decode(raw)

            val head = text.take(4000).trimStart('\uFEFF', ' ', '\t', '\r', '\n')
            val lowerName = name.lowercase(Locale.ROOT)
            val ext: String
            val mime: String
            when {
                head.startsWith("WEBVTT") -> { ext = "vtt"; mime = MimeTypes.TEXT_VTT }
                head.contains("[Script Info]", true) || head.contains("[Events]", true) ||
                    lowerName.endsWith(".ass") || lowerName.endsWith(".ssa") -> {
                    ext = "ass"; mime = MimeTypes.TEXT_SSA
                }
                head.startsWith("<?xml") || head.startsWith("<tt") -> { ext = "ttml"; mime = MimeTypes.APPLICATION_TTML }
                else -> { ext = "srt"; mime = MimeTypes.APPLICATION_SUBRIP }
            }

            val dir = File(ctx.cacheDir, "subs").also { it.mkdirs() }
            val now = System.currentTimeMillis()
            dir.listFiles()?.forEach { if (now - it.lastModified() > 6L * 3600_000L) it.delete() }
            val f = File(dir, "sub_" + System.nanoTime() + "." + ext)
            f.writeText(text, Charsets.UTF_8)
            Result(f, name, mime)
        } catch (_: Throwable) {
            null
        }
    }

    /** UTF-8 / UTF-16 (with BOM) / plain UTF-8, otherwise fall back to Windows-1252. */
    private fun decode(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        try {
            return Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (_: CharacterCodingException) {
        }
        return String(b, Charset.forName("windows-1252"))
    }
}
