package com.foridul.videoplayerpro

import android.content.SharedPreferences
import android.content.pm.ActivityInfo

/** Default screen orientation used by the video player (chosen in Settings). */
object OrientationPrefs {
    const val PREFS = "player_prefs"
    const val KEY = "default_orientation"

    const val SYSTEM = 0
    const val FIT = 1
    const val AUTO = 2
    const val PORTRAIT = 3
    const val LANDSCAPE = 4
    const val REVERSE_LANDSCAPE = 5

    val NAMES = arrayOf(
        "System default",
        "Fit to video",
        "Auto-rotate (sensor)",
        "Portrait",
        "Landscape",
        "Reverse landscape"
    )

    fun get(prefs: SharedPreferences): Int {
        if (prefs.contains(KEY)) return prefs.getInt(KEY, SYSTEM).coerceIn(0, NAMES.size - 1)
        // migrate the old "Auto-rotate to video" switch
        return if (prefs.getBoolean("auto_orient", false)) FIT else SYSTEM
    }

    fun set(prefs: SharedPreferences, mode: Int) {
        prefs.edit().putInt(KEY, mode).apply()
    }

    /** Orientation to request right away. "Fit to video" waits until the video size is known. */
    fun activityInfoFor(mode: Int): Int = when (mode) {
        AUTO -> ActivityInfo.SCREEN_ORIENTATION_SENSOR
        PORTRAIT -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        REVERSE_LANDSCAPE -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
        else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
}
