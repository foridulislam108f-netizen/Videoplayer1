package com.foridul.videoplayerpro

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.foridul.videoplayerpro.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var folderAdapter: FolderAdapter
    private lateinit var videoAdapter: VideoAdapter
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var showingFolders = true
    private var currentFolder: FolderItem? = null
    private var allFolders: List<FolderItem> = emptyList()
    private var audioFolders: List<FolderItem> = emptyList()

    /** 0 = Video, 1 = Music */
    private var currentMode = 0
    /** 0 = name A-Z, 1 = name Z-A, 2 = count high-low, 3 = count low-high */
    private var sortMode = 0
    /** false = list, true = grid */
    private var isGrid = false

    private val videoPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                if (currentMode == 0) loadVideoFolders() else loadAudioFolders()
            } else {
                showEmpty(
                    if (currentMode == 0) "Allow video access.\nTap here to try again."
                    else "Allow audio access.\nTap here to try again.",
                    true
                )
            }
        }

    private val multiPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { map ->
            val ok = map.values.any { it }
            if (ok) {
                if (currentMode == 0) loadVideoFolders() else loadAudioFolders()
            } else {
                showEmpty("Permission needed.\nTap here to try again.", true)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        folderAdapter = FolderAdapter(
            onFolderClick = { folder -> openFolder(folder) },
            onMoreClick = { folder, view -> showFolderMenu(folder, view) }
        )
        videoAdapter = VideoAdapter { list, pos ->
            startPlayer(list.map { it.uri.toString() }, list.map { it.title }, pos)
        }

        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = folderAdapter

        // Tabs
        b.tabPlaylists.setOnClickListener {
            selectTab(0)
            if (currentMode == 0) submitFolders(allFolders)
        }
        b.tabRecent.setOnClickListener {
            selectTab(1)
            Toast.makeText(this, "Recently played", Toast.LENGTH_SHORT).show()
        }
        b.tabStream.setOnClickListener {
            selectTab(2)
            showStreamDialog()
        }

        // All folders dropdown
        b.btnAllFolders.setOnClickListener { showFoldersDropdown() }

        // View mode toggle (list / grid)
        b.btnViewMode.setOnClickListener {
            isGrid = !isGrid
            applyLayoutManager()
            Toast.makeText(
                this,
                if (isGrid) "Grid view" else "List view",
                Toast.LENGTH_SHORT
            ).show()
        }

        // Sort cycle
        b.btnSort.setOnClickListener {
            sortMode = (sortMode + 1) % 4
            val msg = when (sortMode) {
                0 -> "Name A → Z"
                1 -> "Name Z → A"
                2 -> "Most videos first"
                else -> "Least videos first"
            }
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            if (showingFolders) {
                val source = if (currentMode == 0) allFolders else audioFolders
                submitFolders(source)
            } else {
                currentFolder?.let { openFolder(it) }
            }
        }

        // Bottom nav
        b.navVideo.setOnClickListener { switchToVideo() }
        b.navMusic.setOnClickListener { switchToMusic() }
        b.navSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        b.tvEmpty.setOnClickListener { ensurePermissionAndLoad() }

        updateBottomNavUi()
    }

    override fun onResume() {
        super.onResume()
        ensurePermissionAndLoad()
    }

    private fun switchToVideo() {
        if (currentMode == 0 && showingFolders) return
        currentMode = 0
        showingFolders = true
        currentFolder = null
        b.tvAllFolders.text = "All folders"
        updateBottomNavUi()
        ensurePermissionAndLoad()
    }

    private fun switchToMusic() {
        currentMode = 1
        showingFolders = true
        currentFolder = null
        b.tvAllFolders.text = "All folders"
        updateBottomNavUi()
        ensurePermissionAndLoad()
    }

    private fun updateBottomNavUi() {
        val videoSelected = currentMode == 0
        if (videoSelected) {
            b.navVideoPill.setBackgroundResource(R.drawable.bg_nav_selected)
            b.navVideoLabel.setTextColor(ContextCompat.getColor(this, R.color.nav_selected))
            b.navVideoLabel.setTypeface(null, android.graphics.Typeface.BOLD)

            b.navMusicPill.setBackgroundResource(android.R.color.transparent)
            b.navMusicIcon.alpha = 0.45f
            b.navMusicLabel.setTextColor(ContextCompat.getColor(this, R.color.icon_inactive))
            b.navMusicLabel.setTypeface(null, android.graphics.Typeface.NORMAL)
        } else {
            b.navMusicPill.setBackgroundResource(R.drawable.bg_nav_selected)
            b.navMusicIcon.alpha = 1f
            b.navMusicLabel.setTextColor(ContextCompat.getColor(this, R.color.nav_selected))
            b.navMusicLabel.setTypeface(null, android.graphics.Typeface.BOLD)

            b.navVideoPill.setBackgroundResource(android.R.color.transparent)
            b.navVideoLabel.setTextColor(ContextCompat.getColor(this, R.color.icon_inactive))
            b.navVideoLabel.setTypeface(null, android.graphics.Typeface.NORMAL)
        }
    }

    private fun selectTab(index: Int) {
        val selectedBg = R.drawable.bg_tab_selected
        val unselectedBg = R.drawable.bg_tab_unselected
        b.tabPlaylists.setBackgroundResource(if (index == 0) selectedBg else unselectedBg)
        b.tabRecent.setBackgroundResource(if (index == 1) selectedBg else unselectedBg)
        b.tabStream.setBackgroundResource(if (index == 2) selectedBg else unselectedBg)
    }

    private fun ensurePermissionAndLoad() {
        val perm = if (currentMode == 0) videoPermission else audioPermission
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            if (currentMode == 0) loadVideoFolders() else loadAudioFolders()
        } else {
            if (Build.VERSION.SDK_INT >= 33) {
                multiPermLauncher.launch(
                    arrayOf(
                        Manifest.permission.READ_MEDIA_VIDEO,
                        Manifest.permission.READ_MEDIA_AUDIO
                    )
                )
            } else {
                permLauncher.launch(perm)
            }
        }
    }

    private fun loadVideoFolders() {
        io.execute {
            val folders = queryMediaFolders(isAudio = false)
            ui.post {
                if (isFinishing || isDestroyed) return@post
                allFolders = folders
                if (currentMode == 0) {
                    if (showingFolders) submitFolders(folders)
                    else currentFolder?.let { openFolder(it) }
                }
            }
        }
    }

    private fun loadAudioFolders() {
        io.execute {
            val folders = queryMediaFolders(isAudio = true)
            ui.post {
                if (isFinishing || isDestroyed) return@post
                audioFolders = folders
                if (currentMode == 1) {
                    if (showingFolders) submitFolders(folders)
                    else currentFolder?.let { openFolder(it) }
                }
            }
        }
    }

    private fun queryMediaFolders(isAudio: Boolean): List<FolderItem> {
        val map = LinkedHashMap<String, MutableList<VideoItem>>()
        val collection = if (isAudio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val idColName = if (isAudio) MediaStore.Audio.Media._ID else MediaStore.Video.Media._ID
        val nameColName = if (isAudio) MediaStore.Audio.Media.DISPLAY_NAME else MediaStore.Video.Media.DISPLAY_NAME
        val durColName = if (isAudio) MediaStore.Audio.Media.DURATION else MediaStore.Video.Media.DURATION
        val sizeColName = if (isAudio) MediaStore.Audio.Media.SIZE else MediaStore.Video.Media.SIZE
        val bucketColName = if (isAudio) MediaStore.Audio.Media.BUCKET_DISPLAY_NAME else MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        val dateCol = if (isAudio) MediaStore.Audio.Media.DATE_ADDED else MediaStore.Video.Media.DATE_ADDED

        val projection = arrayOf(idColName, nameColName, durColName, sizeColName, bucketColName)

        try {
            contentResolver.query(
                collection, projection, null, null, "$dateCol DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(idColName)
                val nameCol = c.getColumnIndexOrThrow(nameColName)
                val durCol = c.getColumnIndexOrThrow(durColName)
                val sizeCol = c.getColumnIndexOrThrow(sizeColName)
                val bucketCol = c.getColumnIndexOrThrow(bucketColName)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val bucket = c.getString(bucketCol) ?: "Other"
                    val item = VideoItem(
                        id = id,
                        uri = ContentUris.withAppendedId(collection, id),
                        title = c.getString(nameCol) ?: if (isAudio) "Audio $id" else "Video $id",
                        durationMs = c.getLong(durCol),
                        size = c.getLong(sizeCol)
                    )
                    map.getOrPut(bucket) { mutableListOf() }.add(item)
                }
            }
        } catch (_: Exception) {
        }
        return map.map { (name, items) ->
            FolderItem(name = name, path = name, videoCount = items.size, videos = items)
        }
    }

    private fun sortedFolders(source: List<FolderItem>): List<FolderItem> {
        return when (sortMode) {
            0 -> source.sortedBy { it.name.lowercase() }
            1 -> source.sortedByDescending { it.name.lowercase() }
            2 -> source.sortedByDescending { it.videoCount }
            else -> source.sortedBy { it.videoCount }
        }
    }

    private fun submitFolders(folders: List<FolderItem>) {
        val sorted = sortedFolders(folders)
        folderAdapter.isAudioMode = (currentMode == 1)
        folderAdapter.submit(sorted)
        b.recycler.adapter = folderAdapter
        applyLayoutManager()
        showingFolders = true
        currentFolder = null
        b.tvAllFolders.text = "All folders"
        updateEmptyState()
    }

    private fun openFolder(folder: FolderItem) {
        currentFolder = folder
        showingFolders = false
        val videos = when (sortMode) {
            0 -> folder.videos.sortedBy { it.title.lowercase() }
            1 -> folder.videos.sortedByDescending { it.title.lowercase() }
            2 -> folder.videos.sortedByDescending { it.durationMs }
            else -> folder.videos.sortedBy { it.durationMs }
        }
        videoAdapter.submit(videos)
        b.recycler.adapter = videoAdapter
        applyLayoutManager()
        b.tvAllFolders.text = folder.name
        updateEmptyState()
    }

    private fun applyLayoutManager() {
        if (isGrid && showingFolders) {
            b.recycler.layoutManager = GridLayoutManager(this, 2)
        } else {
            b.recycler.layoutManager = LinearLayoutManager(this)
        }
    }

    private fun showFoldersDropdown() {
        if (!showingFolders) {
            val source = if (currentMode == 0) allFolders else audioFolders
            submitFolders(source)
            return
        }
        val source = if (currentMode == 0) allFolders else audioFolders
        val popup = PopupMenu(this, b.btnAllFolders, Gravity.START)
        popup.menu.add(0, 0, 0, "All folders")
        sortedFolders(source).forEachIndexed { i, f ->
            val unit = if (currentMode == 1) {
                if (f.videoCount == 1) "1 song" else "${f.videoCount} songs"
            } else {
                if (f.videoCount == 1) "1 video" else "${f.videoCount} videos"
            }
            popup.menu.add(0, i + 1, i + 1, "${f.name} ($unit)")
        }
        popup.setOnMenuItemClickListener { item ->
            if (item.itemId == 0) {
                submitFolders(source)
            } else {
                val folder = sortedFolders(source).getOrNull(item.itemId - 1)
                if (folder != null) openFolder(folder)
            }
            true
        }
        popup.show()
    }

    private fun showFolderMenu(folder: FolderItem, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("Play all")
        popup.menu.add("Open folder")
        popup.setOnMenuItemClickListener {
            when (it.title) {
                "Play all" -> {
                    if (folder.videos.isNotEmpty()) {
                        startPlayer(
                            folder.videos.map { v -> v.uri.toString() },
                            folder.videos.map { v -> v.title },
                            0
                        )
                    }
                }
                "Open folder" -> openFolder(folder)
            }
            true
        }
        popup.show()
    }

    private fun updateEmptyState() {
        val count = if (showingFolders) folderAdapter.count() else videoAdapter.count()
        if (count == 0) {
            val msg = when {
                currentMode == 1 && showingFolders -> "No music folders found.\nGrant audio permission."
                currentMode == 1 -> "No songs in this folder."
                showingFolders -> "No video folders found.\nGrant storage permission."
                else -> "No videos in this folder."
            }
            showEmpty(msg, showingFolders)
        } else {
            b.tvEmpty.visibility = View.GONE
        }
    }

    private fun showEmpty(text: String, clickable: Boolean) {
        b.tvEmpty.text = text
        b.tvEmpty.isClickable = clickable
        b.tvEmpty.visibility = View.VISIBLE
    }

    private fun showStreamDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.m3u8"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFA6A6B0.toInt())
            setPadding(48, 36, 48, 36)
        }
        AlertDialog.Builder(this)
            .setTitle("Network stream")
            .setView(input)
            .setPositiveButton("Play") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isEmpty()) {
                    Toast.makeText(this, "Enter a URL", Toast.LENGTH_SHORT).show()
                } else {
                    startPlayer(listOf(url), listOf(Uri.parse(url).lastPathSegment ?: url), 0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) return it.getString(0)
                }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    private fun startPlayer(uris: List<String>, titles: List<String>, index: Int) {
        val i = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra(PlayerActivity.EXTRA_URIS, ArrayList(uris))
            putStringArrayListExtra(PlayerActivity.EXTRA_TITLES, ArrayList(titles))
            putExtra(PlayerActivity.EXTRA_INDEX, index)
        }
        startActivity(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!showingFolders) {
            val source = if (currentMode == 0) allFolders else audioFolders
            submitFolders(source)
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}
