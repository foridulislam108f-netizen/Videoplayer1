package com.foridul.videoplayerpro

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.foridul.videoplayerpro.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: VideoAdapter
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private val videoPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadVideos() else showEmpty("Allow video access to list your videos.\nTap here to try again.", true)
        }

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            uris.forEach {
                try {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            startPlayer(uris.map { it.toString() }, uris.map { displayName(it) }, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        adapter = VideoAdapter { list, pos ->
            startPlayer(list.map { it.uri.toString() }, list.map { it.title }, pos)
        }
        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter

        b.btnOpenFiles.setOnClickListener { pickFiles.launch(arrayOf("video/*", "audio/*")) }
        b.btnStream.setOnClickListener { showStreamDialog() }
        b.tvEmpty.setOnClickListener { ensurePermissionAndLoad() }
        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                adapter.filter(s?.toString().orEmpty())
                updateEmptyState()
            }
        })
    }

    override fun onResume() {
        super.onResume()
        ensurePermissionAndLoad()
    }

    private fun ensurePermissionAndLoad() {
        if (ContextCompat.checkSelfPermission(this, videoPermission) == PackageManager.PERMISSION_GRANTED) {
            loadVideos()
        } else {
            permLauncher.launch(videoPermission)
        }
    }

    private fun loadVideos() {
        io.execute {
            val list = queryVideos()
            ui.post {
                if (isFinishing || isDestroyed) return@post
                adapter.submit(list)
                adapter.filter(b.etSearch.text?.toString().orEmpty())
                updateEmptyState()
            }
        }
    }

    private fun queryVideos(): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE
        )
        try {
            contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    out.add(
                        VideoItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            title = c.getString(nameCol) ?: "Video $id",
                            durationMs = c.getLong(durCol),
                            size = c.getLong(sizeCol)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun updateEmptyState() {
        if (adapter.count() == 0) {
            val searching = !b.etSearch.text.isNullOrBlank()
            showEmpty(
                if (searching) "No videos match your search."
                else "No videos found.\nUse \"Open files\" or \"Network stream\" above.",
                false
            )
        } else {
            b.tvEmpty.visibility = View.GONE
        }
    }

    private fun showEmpty(text: String, clickable: Boolean) {
        b.tvEmpty.text = text
        b.tvEmpty.isClickable = clickable
        b.tvEmpty.visibility = View.VISIBLE
    }

    private fun showStreamDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.m3u8"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFA6A6B0.toInt())
            setPadding(48, 36, 48, 36)
        }
        AlertDialog.Builder(this)
            .setTitle("Network stream")
            .setView(input)
            .setPositiveButton("Play") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isEmpty()) {
                    Toast.makeText(this, "Enter a URL", Toast.LENGTH_SHORT).show()
                } else {
                    startPlayer(listOf(url), listOf(Uri.parse(url).lastPathSegment ?: url), 0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) return it.getString(0)
                }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    private fun startPlayer(uris: List<String>, titles: List<String>, index: Int) {
        val i = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra(PlayerActivity.EXTRA_URIS, ArrayList(uris))
            putStringArrayListExtra(PlayerActivity.EXTRA_TITLES, ArrayList(titles))
            putExtra(PlayerActivity.EXTRA_INDEX, index)
        }
        startActivity(i)
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}
