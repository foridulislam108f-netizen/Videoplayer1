package com.foridul.videoplayerpro

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.os.Environment
import android.util.Base64
import android.webkit.MimeTypeMap
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.foridul.videoplayerpro.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

enum class NavKind { ROOT, FOLDER, RECENT, PLAYLISTS, SMART, PRIVATE }

data class Nav(val kind: NavKind, val key: String = "", val title: String = "")

enum class SortMode { NAME_ASC, NAME_DESC, NEW, OLD, BIG }

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: RowAdapter
    private lateinit var prefs: SharedPreferences
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var videos: List<LibItem> = emptyList()
    private var audios: List<LibItem> = emptyList()
    private var currentMedia: List<LibItem> = emptyList()

    private var tab = 0 // 0 video, 1 music, 2 settings
    private var nav = Nav(NavKind.ROOT)
    private var flat = false
    private var grid = false
    private var sort = SortMode.NEW
    private var permissionMissing = false
    private var askedPermission = false

    private val videoPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            loadMedia()
        }

    private var favs: MutableSet<String> = HashSet()
    private var pendingAfterGrant: (() -> Unit)? = null
    private var pendingOnDeny: (() -> Unit)? = null
    private var vaultUnlocked = false
    private var launchingPlayer = false
    private var busy = false
    private val vaultDurations = ConcurrentHashMap<String, Long>()

    private val grantLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
            val action = pendingAfterGrant
            val deny = pendingOnDeny
            pendingAfterGrant = null
            pendingOnDeny = null
            if (res.resultCode == RESULT_OK) action?.invoke() else deny?.invoke()
        }

    private val writePermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val action = pendingAfterGrant
            val deny = pendingOnDeny
            pendingAfterGrant = null
            pendingOnDeny = null
            if (granted) {
                action?.invoke()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                deny?.invoke()
            }
        }

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            uris.forEach {
                try {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            startPlayerRaw(uris.map { it.toString() }, uris.map { displayName(it) }, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        prefs = getSharedPreferences("home", Context.MODE_PRIVATE)
        grid = prefs.getBoolean("grid", false)
        sort = SortMode.values().getOrElse(prefs.getInt("sort", SortMode.NEW.ordinal)) { SortMode.NEW }
        if (!prefs.contains("baseline")) {
            prefs.edit().putLong("baseline", System.currentTimeMillis() / 1000).apply()
        }

        favs = HashSet(prefs.getStringSet("favs", emptySet()) ?: emptySet())

        adapter = RowAdapter(
            onFolder = { openFolder(it) },
            onFolderMenu = { anchor, row -> showFolderMenu(anchor, row) },
            onMedia = { pos -> playFromCurrent(pos) },
            onMediaLong = { showItemActions(it) }
        )
        adapter.isFav = { favs.contains(it.uri.toString()) }
        b.recycler.adapter = adapter
        applyLayoutMode()

        b.btnBack.setOnClickListener { goBack() }
        b.btnCast.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_CAST_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Cast is not available on this device", Toast.LENGTH_SHORT).show()
            }
        }
        b.btnSearch.setOnClickListener { toggleSearch() }
        b.btnMore.setOnClickListener { showTopMenu() }

        b.chipPlaylists.setOnClickListener { go(Nav(NavKind.PLAYLISTS, "", "Playlists")) }
        b.chipRecent.setOnClickListener { go(Nav(NavKind.RECENT, "", "Recently Played")) }
        b.chipStream.setOnClickListener { showStreamDialog() }
        b.chipPrivate.setOnClickListener { openVault() }

        b.scopeBtn.setOnClickListener { showScopeMenu() }
        val toggleLayout = View.OnClickListener {
            grid = !grid
            prefs.edit().putBoolean("grid", grid).apply()
            applyLayoutMode()
            rebuild()
        }
        b.btnLayout.setOnClickListener(toggleLayout)
        b.btnLayoutTop.setOnClickListener(toggleLayout)
        b.btnSort.setOnClickListener { showSortMenu(b.btnSort, true) }
        b.btnSortTop.setOnClickListener { showSortMenu(b.btnSortTop, true) }

        b.navVideo.setOnClickListener { selectTab(0) }
        b.navMusic.setOnClickListener { selectTab(1) }
        b.navSettings.setOnClickListener { selectTab(2) }

        b.tvEmpty.setOnClickListener {
            if (permissionMissing) {
                askedPermission = false
                ensurePermissionAndLoad()
            }
        }
        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                rebuild()
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!handleBack()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        updateNavBar()
        rebuild()
    }

    override fun onStart() {
        super.onStart()
        launchingPlayer = false
    }

    override fun onStop() {
        super.onStop()
        if (nav.kind == NavKind.PRIVATE && !launchingPlayer && !isChangingConfigurations) {
            vaultUnlocked = false
            nav = Nav(NavKind.ROOT)
            rebuild()
        }
    }

    override fun onResume() {
        super.onResume()
        ensurePermissionAndLoad()
    }

    // ------------------------------------------------------------ navigation

    private fun handleBack(): Boolean {
        if (b.etSearch.visibility == View.VISIBLE) {
            closeSearch()
            return true
        }
        if (nav.kind != NavKind.ROOT && tab != 2) {
            nav = Nav(NavKind.ROOT)
            rebuild()
            return true
        }
        if (tab != 0) {
            selectTab(0)
            return true
        }
        return false
    }

    private fun goBack() {
        handleBack()
    }

    private fun go(n: Nav) {
        nav = n
        rebuild()
        b.recycler.scrollToPosition(0)
    }

    private fun selectTab(t: Int) {
        closeSearch()
        tab = t
        nav = Nav(NavKind.ROOT)
        flat = false
        updateNavBar()
        if (t == 2) buildSettings()
        rebuild()
    }

    private fun applyLayoutMode() {
        adapter.grid = grid
        b.recycler.layoutManager =
            if (grid) GridLayoutManager(this, 2) else LinearLayoutManager(this)
        val layoutIcon = if (grid) R.drawable.ic_list_view else R.drawable.ic_grid_view
        b.btnLayout.setImageResource(layoutIcon)
        b.btnLayoutTop.setImageResource(layoutIcon)
    }

    private fun updateNavBar() {
        fun style(sel: Boolean, pill: View, icon: android.widget.ImageView, label: android.widget.TextView) {
            pill.setBackgroundResource(if (sel) R.drawable.bg_nav_pill else 0)
            val c = Ui.color(this, if (sel) R.color.text_primary else R.color.text_secondary)
            icon.imageTintList = ColorStateList.valueOf(c)
            label.setTextColor(c)
            label.setTypeface(null, if (sel) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        style(tab == 0, b.pillVideo, b.ivNavVideo, b.tvNavVideo)
        style(tab == 1, b.pillMusic, b.ivNavMusic, b.tvNavMusic)
        style(tab == 2, b.pillSettings, b.ivNavSettings, b.tvNavSettings)
    }

    // ------------------------------------------------------------ search

    private fun toggleSearch() {
        if (b.etSearch.visibility == View.VISIBLE) {
            closeSearch()
        } else {
            b.etSearch.visibility = View.VISIBLE
            b.etSearch.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(b.etSearch, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeSearch() {
        if (b.etSearch.visibility != View.VISIBLE) return
        b.etSearch.setText("")
        b.etSearch.visibility = View.GONE
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(b.etSearch.windowToken, 0)
        rebuild()
    }

    // ------------------------------------------------------------ menus

    private fun showTopMenu() {
        ModernPopup.show(
            b.btnMore,
            listOf(
                ModernPopup.Item("Refresh", R.drawable.ic_refresh),
                ModernPopup.Item("Settings", R.drawable.ic_settings)
            ),
            alignEnd = true
        ) {
            when (it) {
                0 -> loadMedia()
                1 -> selectTab(2)
            }
        }
    }

    private fun showScopeMenu() {
        if (nav.kind != NavKind.ROOT) return
        val allLabel = if (tab == 1) "All songs" else "All videos"
        ModernPopup.show(
            b.scopeBtn,
            listOf(
                ModernPopup.Item("All folders", R.drawable.ic_folder, !flat),
                ModernPopup.Item(allLabel, if (tab == 1) R.drawable.ic_music else R.drawable.ic_video, flat)
            )
        ) {
            flat = it == 1
            rebuild()
        }
    }

    private fun showSortMenu(anchor: View, alignEnd: Boolean) {
        val folderMode = tab != 2 && nav.kind == NavKind.ROOT && !flat
        val labels = listOf(
            "Name (A–Z)",
            "Name (Z–A)",
            "Newest first",
            "Oldest first",
            if (folderMode) "Most items" else "Largest first"
        )
        ModernPopup.show(
            anchor,
            labels.mapIndexed { i, l -> ModernPopup.Item(l, 0, sort.ordinal == i) },
            alignEnd
        ) {
            sort = SortMode.values()[it]
            prefs.edit().putInt("sort", it).apply()
            if (tab == 2) buildSettings() else rebuild()
        }
    }

    private fun showFolderMenu(anchor: View, row: Row.Folder) {
        ModernPopup.show(
            anchor,
            listOf(
                ModernPopup.Item("Play all", R.drawable.ic_play),
                ModernPopup.Item("Open", R.drawable.ic_folder)
            ),
            alignEnd = true
        ) {
            when (it) {
                0 -> {
                    val list = itemsFor(row)
                    if (list.isNotEmpty()) startPlayer(list, 0)
                }
                1 -> openFolder(row)
            }
        }
    }

    private fun showStreamDialog() {
        ModernDialog.Builder(this)
            .setTitle("Network stream")
            .setInput("https://example.com/video.m3u8", "Play") { url ->
                if (url.isEmpty()) {
                    Toast.makeText(this, "Enter a URL", Toast.LENGTH_SHORT).show()
                } else {
                    startPlayerRaw(listOf(url), listOf(Uri.parse(url).lastPathSegment ?: url), 0)
                }
            }
            .show()
    }

    // ------------------------------------------------------------ data

    private fun ensurePermissionAndLoad() {
        val need = listOf(videoPermission, audioPermission).distinct().filter { !has(it) }
        if (need.isEmpty() || askedPermission) {
            loadMedia()
        } else {
            askedPermission = true
            permLauncher.launch(need.toTypedArray())
        }
    }

    private fun loadMedia() {
        io.execute {
            val v = if (has(videoPermission)) query(false) else emptyList()
            val a = if (has(audioPermission)) query(true) else emptyList()
            ui.post {
                if (isFinishing || isDestroyed) return@post
                permissionMissing = !has(videoPermission)
                videos = v
                audios = a
                rebuild()
                if (tab == 2) buildSettings()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun query(isAudio: Boolean): List<LibItem> {
        val out = ArrayList<LibItem>()
        val collection =
            if (isAudio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val durKey = if (isAudio) MediaStore.Audio.Media.DURATION else MediaStore.Video.Media.DURATION
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            durKey,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.DATA
        )
        try {
            contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val durCol = c.getColumnIndexOrThrow(durKey)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val addCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val dataCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val data = c.getString(dataCol)
                    out.add(
                        LibItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            title = c.getString(nameCol) ?: "Media $id",
                            durationMs = c.getLong(durCol),
                            size = c.getLong(sizeCol),
                            dateAdded = c.getLong(addCol),
                            folderKey = data?.let { File(it).parent } ?: "Unknown",
                            isAudio = isAudio
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun src(): List<LibItem> = if (tab == 1) audios else videos

    private fun folderName(key: String): String =
        key.trimEnd('/').substringAfterLast('/').ifEmpty { key }

    private fun freshThreshold(key: String): Long =
        maxOf(prefs.getLong("baseline", 0L), prefs.getLong("seen_$key", 0L))

    private fun sorted(list: List<LibItem>): List<LibItem> = when (sort) {
        SortMode.NAME_ASC -> list.sortedBy { it.title.lowercase() }
        SortMode.NAME_DESC -> list.sortedByDescending { it.title.lowercase() }
        SortMode.NEW -> list.sortedByDescending { it.dateAdded }
        SortMode.OLD -> list.sortedBy { it.dateAdded }
        SortMode.BIG -> list.sortedByDescending { it.size }
    }

    private fun folderRows(): List<Row> {
        val groups = src().groupBy { it.folderKey }
        val rows = groups.map { (key, items) ->
            val th = freshThreshold(key)
            Row.Folder(
                key = key,
                name = folderName(key),
                count = items.size,
                fresh = items.count { it.dateAdded > th },
                isAudio = tab == 1
            ) to items.maxOf { it.dateAdded }
        }
        val sortedRows = when (sort) {
            SortMode.NAME_ASC -> rows.sortedBy { it.first.name.lowercase() }
            SortMode.NAME_DESC -> rows.sortedByDescending { it.first.name.lowercase() }
            SortMode.NEW -> rows.sortedByDescending { it.second }
            SortMode.OLD -> rows.sortedBy { it.second }
            SortMode.BIG -> rows.sortedByDescending { it.first.count }
        }
        return sortedRows.map { it.first }
    }

    private fun smartList(key: String): List<LibItem> = when (key) {
        "added" -> videos.sortedByDescending { it.dateAdded }.take(50)
        "long" -> videos.sortedByDescending { it.durationMs }.take(50)
        "big" -> videos.sortedByDescending { it.size }.take(50)
        "fav" -> favItems()
        else -> videos
    }

    private fun favItems(): List<LibItem> =
        (videos + audios).filter { favs.contains(it.uri.toString()) }.sortedByDescending { it.dateAdded }

    private fun smartRows(): List<Row> = listOf(
        Row.Folder("fav", "Favorites", favItems().size, 0, false, true, R.drawable.ic_heart),
        Row.Folder("added", "Recently added", minOf(50, videos.size), 0, false, true, R.drawable.ic_playlist),
        Row.Folder("long", "Longest videos", minOf(50, videos.size), 0, false, true, R.drawable.ic_history),
        Row.Folder("big", "Largest videos", minOf(50, videos.size), 0, false, true, R.drawable.ic_video),
        Row.Folder("all", "All videos", videos.size, 0, false, true, R.drawable.ic_folder)
    )

    private fun itemsFor(row: Row.Folder): List<LibItem> =
        if (row.smart) smartList(row.key) else sorted(src().filter { it.folderKey == row.key })

    private fun openFolder(row: Row.Folder) {
        if (row.smart) {
            go(Nav(NavKind.SMART, row.key, row.name))
        } else {
            prefs.edit().putLong("seen_${row.key}", System.currentTimeMillis() / 1000).apply()
            go(Nav(NavKind.FOLDER, row.key, row.name))
        }
    }

    // ------------------------------------------------------------ recent

    private fun recordRecent(uri: String, title: String) {
        try {
            val old = JSONArray(prefs.getString("recent", "[]"))
            val out = JSONArray()
            out.put(JSONObject().put("u", uri).put("t", title))
            for (i in 0 until old.length()) {
                val o = old.getJSONObject(i)
                if (o.getString("u") != uri && out.length() < 30) out.put(o)
            }
            prefs.edit().putString("recent", out.toString()).apply()
        } catch (_: Exception) {
        }
    }

    /** Drops [uri] from the recent list, or gives it [newTitle] when one is passed. */
    private fun updateRecent(uri: String, newTitle: String?) {
        try {
            val old = JSONArray(prefs.getString("recent", "[]"))
            val out = JSONArray()
            for (i in 0 until old.length()) {
                val o = old.getJSONObject(i)
                if (o.getString("u") == uri) {
                    if (newTitle != null) out.put(JSONObject().put("u", uri).put("t", newTitle))
                } else {
                    out.put(o)
                }
            }
            prefs.edit().putString("recent", out.toString()).apply()
        } catch (_: Exception) {
        }
    }

    private fun recentItems(): List<LibItem> {
        val out = ArrayList<LibItem>()
        try {
            val known = (videos + audios).associateBy { it.uri.toString() }
            val arr = JSONArray(prefs.getString("recent", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val u = o.getString("u")
                out.add(known[u] ?: LibItem(-1, Uri.parse(u), o.optString("t", u), 0, 0, 0, "", false))
            }
        } catch (_: Exception) {
        }
        return out
    }

    // ------------------------------------------------------------ list building

    private fun rebuild() {
        val q = b.etSearch.text?.toString().orEmpty().trim().lowercase()
        val rows = ArrayList<Row>()
        var media: List<LibItem>? = null

        if (nav.kind == NavKind.PRIVATE && !vaultUnlocked) nav = Nav(NavKind.ROOT)
        if (nav.kind != NavKind.PRIVATE) vaultUnlocked = false

        when {
            tab == 2 -> {}
            nav.kind == NavKind.PRIVATE ->
                media = sorted(vaultItems().filter { q.isEmpty() || it.title.lowercase().contains(q) })
            q.isNotEmpty() -> media = sorted(src().filter { it.title.lowercase().contains(q) })
            nav.kind == NavKind.FOLDER -> media = sorted(src().filter { it.folderKey == nav.key })
            nav.kind == NavKind.RECENT -> media = recentItems()
            nav.kind == NavKind.SMART -> media = smartList(nav.key)
            nav.kind == NavKind.PLAYLISTS -> rows.addAll(smartRows())
            flat -> media = sorted(src())
            else -> rows.addAll(folderRows())
        }
        if (media != null) {
            currentMedia = media
            media.forEach { rows.add(Row.Media(it)) }
        }
        adapter.submit(rows)

        // chrome
        val root = nav.kind == NavKind.ROOT
        val onList = tab != 2
        b.pageList.visibility = if (onList) View.VISIBLE else View.GONE
        b.pageSettings.visibility = if (onList) View.GONE else View.VISIBLE
        // Inside a folder: compact header (back, small title, search, layout, sort)
        val inFolder = onList && !root
        b.btnCast.visibility = if (onList && !inFolder) View.VISIBLE else View.GONE
        b.btnSearch.visibility = if (onList) View.VISIBLE else View.GONE
        b.btnMore.visibility = if (onList && !inFolder) View.VISIBLE else View.GONE
        b.btnLayoutTop.visibility = if (inFolder) View.VISIBLE else View.GONE
        b.btnSortTop.visibility = if (inFolder) View.VISIBLE else View.GONE
        b.scopeRow.visibility = if (inFolder) View.GONE else View.VISIBLE
        b.tvTitle.textSize = if (inFolder) 17f else 22f
        b.btnBack.visibility = if (onList && !root) View.VISIBLE else View.GONE
        b.tvTitle.text = when {
            tab == 2 -> "Settings"
            !root -> nav.title
            else -> ""
        }
        b.chipScroll.visibility = if (tab == 0 && root && q.isEmpty()) View.VISIBLE else View.GONE
        b.scopeBtn.isClickable = root
        b.ivScopeArrow.visibility = if (root) View.VISIBLE else View.GONE
        b.tvScopeText.text = when {
            !root -> nav.title
            flat -> if (tab == 1) "All songs" else "All videos"
            else -> "All folders"
        }

        // empty state
        if (onList && rows.isEmpty()) {
            val text = when {
                q.isNotEmpty() -> "No results found."
                permissionMissing -> "Allow media access to see your files.\nTap here to try again."
                nav.kind == NavKind.PRIVATE -> "Nothing here yet.\nLong-press a video and tap the lock icon."
                nav.kind == NavKind.RECENT -> "Nothing played yet."
                tab == 1 -> "No music found."
                else -> "No videos found.\nUse Settings → Open files or Network stream."
            }
            b.tvEmpty.text = text
            b.tvEmpty.isClickable = permissionMissing
            b.tvEmpty.visibility = View.VISIBLE
        } else {
            b.tvEmpty.visibility = View.GONE
        }
    }

    // ------------------------------------------------------------ settings page

    private fun buildSettings() {
        val list = b.settingsList
        list.removeAllViews()

        section(list, "Open")
        settingRow(list, R.drawable.ic_open, "Open files", "Pick videos or audio from storage") {
            pickFiles.launch(arrayOf("video/*", "audio/*", "application/x-matroska", "application/octet-stream"))
        }
        settingRow(list, R.drawable.ic_link, "Network stream", "Play a link (HLS, DASH, MP4, MKV)") {
            showStreamDialog()
        }

        section(list, "Player")
        val playerPrefs = getSharedPreferences(OrientationPrefs.PREFS, MODE_PRIVATE)
        settingRow(
            list, R.drawable.ic_rotate, "Default screen orientation",
            OrientationPrefs.NAMES[OrientationPrefs.get(playerPrefs)]
        ) {
            ModernDialog.Builder(this)
                .setTitle("Default screen orientation")
                .setSingleChoiceItems(OrientationPrefs.NAMES, OrientationPrefs.get(playerPrefs)) { dlg, which ->
                    OrientationPrefs.set(playerPrefs, which)
                    dlg.dismiss()
                    buildSettings()
                }
                .show()
        }

        section(list, "Library")
        val sortLabel = listOf("Name (A–Z)", "Name (Z–A)", "Newest first", "Oldest first", "Largest first")[sort.ordinal]
        settingRow(list, R.drawable.ic_sort, "Sort order", sortLabel) { row -> showSortMenu(row, false) }
        settingRow(list, if (grid) R.drawable.ic_grid_view else R.drawable.ic_list_view, "Layout", if (grid) "Grid" else "List") {
            grid = !grid
            prefs.edit().putBoolean("grid", grid).apply()
            applyLayoutMode()
            buildSettings()
        }
        settingRow(list, R.drawable.ic_refresh, "Rescan library", "Refresh videos and music") {
            loadMedia()
            Toast.makeText(this, "Scanning…", Toast.LENGTH_SHORT).show()
        }
        settingRow(list, R.drawable.ic_trash, "Clear recently played", "Remove the history list") {
            prefs.edit().remove("recent").apply()
            Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
        }

        section(list, "Private")
        settingRow(
            list, R.drawable.ic_lock, "Private folder password",
            if (hasVaultPassword()) "Change password" else "Set a password"
        ) {
            if (hasVaultPassword()) askPassword("Current password") { createPassword("New password") { buildSettings() } }
            else createPassword { buildSettings() }
        }

        section(list, "About")
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
        } catch (_: Exception) {
            "1.0.0"
        }
        settingRow(list, R.drawable.ic_info, "Video Player Pro", "Version $version", null)
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(
            Ui.text(this, title.uppercase(), 12f, Ui.color(this, R.color.accent), true).apply {
                letterSpacing = 0.08f
                setPadding(Ui.dp(this@MainActivity, 24), Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 24), Ui.dp(this@MainActivity, 6))
            }
        )
    }

    private fun settingRow(
        parent: LinearLayout,
        icon: Int,
        title: String,
        subtitle: String?,
        onClick: ((View) -> Unit)?
    ) {
        val ctx = this
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(ctx, 20), Ui.dp(ctx, 10), Ui.dp(ctx, 20), Ui.dp(ctx, 10))
            minimumHeight = Ui.dp(ctx, 64)
            if (onClick != null) {
                setBackgroundResource(R.drawable.bg_row)
                isClickable = true
                isFocusable = true
            }
        }
        val iconBox = android.widget.FrameLayout(ctx).apply {
            setBackgroundResource(R.drawable.bg_setting_icon)
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 44), Ui.dp(ctx, 44))
        }
        val iv = Ui.icon(ctx, icon, 22, Ui.color(ctx, R.color.accent))
        iv.layoutParams = android.widget.FrameLayout.LayoutParams(Ui.dp(ctx, 22), Ui.dp(ctx, 22), Gravity.CENTER)
        iconBox.addView(iv)
        row.addView(iconBox)

        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(ctx, 16)
            }
        }
        texts.addView(Ui.text(ctx, title, 16.5f, Ui.color(ctx, R.color.text_primary)))
        if (subtitle != null) {
            texts.addView(Ui.text(ctx, subtitle, 13.5f, Ui.color(ctx, R.color.text_secondary)).apply {
                setPadding(0, Ui.dp(ctx, 2), 0, 0)
            })
        }
        row.addView(texts)
        if (onClick != null) row.setOnClickListener { onClick(row) }
        parent.addView(row)
    }

    // ------------------------------------------------------------ item actions

    private fun showItemActions(item: LibItem) {
        if (item.id == -1L) { adapter.clearDim(); return }
        if (item.id == -2L) {
            ActionSheet.show(
                this,
                listOf(
                    ActionSheet.Action("Take out", R.drawable.ic_unlock, Ui.color(this, R.color.accent)) {
                        restoreFromVault(item)
                    },
                    ActionSheet.Action("Delete", R.drawable.ic_trash, 0xFFFF6B6B.toInt()) {
                        confirmVaultDelete(item)
                    }
                ),
                onDismiss = { adapter.clearDim() }
            )
            return
        }
        val fav = favs.contains(item.uri.toString())
        val actions = ArrayList<ActionSheet.Action>()
        actions.add(ActionSheet.Action("Rename", R.drawable.ic_edit, Ui.color(this, R.color.accent)) {
            promptRename(item)
        })
        actions.add(ActionSheet.Action("Delete", R.drawable.ic_trash, 0xFFFF6B6B.toInt()) {
            confirmDelete(item)
        })
        actions.add(
            ActionSheet.Action(
                if (fav) "Unfavorite" else "Favorite",
                if (fav) R.drawable.ic_heart_fill else R.drawable.ic_heart,
                0xFFFF5A8A.toInt()
            ) { toggleFav(item) }
        )
        if (!item.isAudio) {
            actions.add(ActionSheet.Action("Private", R.drawable.ic_lock, Ui.color(this, R.color.c_private)) {
                moveToVault(item)
            })
        }
        ActionSheet.show(this, actions) { adapter.clearDim() }
    }

    private fun toggleFav(item: LibItem) {
        val key = item.uri.toString()
        val added = favs.add(key)
        if (!added) favs.remove(key)
        prefs.edit().putStringSet("favs", HashSet(favs)).apply()
        Toast.makeText(this, if (added) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        rebuild()
    }

    private fun promptRename(item: LibItem) {
        val dot = item.title.lastIndexOf('.')
        val base = if (dot > 0) item.title.substring(0, dot) else item.title
        val ext = if (dot > 0) item.title.substring(dot) else ""
        ModernDialog.Builder(this)
            .setTitle("Rename")
            .setInputText(base)
            .setInput("Name", "Rename") { typed ->
                val clean = typed.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                if (clean.isEmpty()) {
                    Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
                } else {
                    val newName = if (ext.isNotEmpty() && clean.endsWith(ext, ignoreCase = true)) clean else clean + ext
                    if (newName != item.title) doRename(item, newName)
                }
            }
            .show()
    }

    private fun doRename(item: LibItem, newName: String) {
        runWithAccess(item.uri) {
            val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, newName) }
            val n = contentResolver.update(item.uri, cv, null, null)
            if (n > 0) {
                updateRecent(item.uri.toString(), newName)
                Toast.makeText(this, "Renamed", Toast.LENGTH_SHORT).show()
                loadMedia()
            } else {
                Toast.makeText(this, "Couldn't rename this file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun confirmDelete(item: LibItem) {
        if (Build.VERSION.SDK_INT >= 30) {
            // The system shows its own confirmation.
            pendingAfterGrant = { afterDelete(item) }
            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(item.uri))
            grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            return
        }
        ModernDialog.Builder(this)
            .setTitle("Delete file?")
            .setMessage(item.title)
            .setPositiveButton("Delete") { _, _ ->
                runWithAccess(item.uri) {
                    val n = contentResolver.delete(item.uri, null, null)
                    if (n > 0) afterDelete(item)
                    else Toast.makeText(this, "Couldn't delete this file", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel")
            .show()
    }

    private fun afterDelete(item: LibItem) {
        val key = item.uri.toString()
        if (favs.remove(key)) prefs.edit().putStringSet("favs", HashSet(favs)).apply()
        updateRecent(key, null)
        Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
        loadMedia()
    }

    /** Runs [action]; if Android asks for write access to [uri], gets it and runs [action] again. */
    private fun runWithAccess(uri: Uri, onDeny: (() -> Unit)? = null, action: () -> Unit) {
        try {
            action()
        } catch (e: SecurityException) {
            when {
                Build.VERSION.SDK_INT >= 30 -> {
                    val pi = MediaStore.createWriteRequest(contentResolver, listOf(uri))
                    pendingAfterGrant = { safely(action) }
                    pendingOnDeny = onDeny
                    grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                }
                Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException -> {
                    pendingAfterGrant = { safely(action) }
                    pendingOnDeny = onDeny
                    grantLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                }
                else -> {
                    pendingAfterGrant = { safely(action) }
                    pendingOnDeny = onDeny
                    writePermLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
            onDeny?.invoke()
        }
    }

    private fun safely(action: () -> Unit) {
        try {
            action()
        } catch (_: Exception) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------ private folder

    private fun vaultDir(): File = File(filesDir, "vault").also { it.mkdirs() }

    private fun isVaultUri(u: String): Boolean =
        u.startsWith("file:") && (Uri.parse(u).path ?: "").startsWith(vaultDir().path)

    private fun vaultItems(): List<LibItem> =
        (vaultDir().listFiles() ?: emptyArray())
            .filter { it.isFile && !it.name.endsWith(".part") }
            .map { f ->
                LibItem(
                    id = -2L,
                    uri = Uri.fromFile(f),
                    title = f.name,
                    durationMs = vaultDurations[f.path] ?: 0L,
                    size = f.length(),
                    dateAdded = f.lastModified() / 1000,
                    folderKey = f.parent ?: "",
                    isAudio = false
                )
            }

    private fun loadVaultDurations() {
        io.execute {
            var changed = false
            vaultDir().listFiles()?.forEach { f ->
                if (f.isFile && !f.name.endsWith(".part") && !vaultDurations.containsKey(f.path)) {
                    var d = 0L
                    try {
                        val r = MediaMetadataRetriever()
                        r.setDataSource(f.path)
                        d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        r.release()
                    } catch (_: Exception) {
                    }
                    vaultDurations[f.path] = d
                    changed = true
                }
            }
            if (changed) ui.post { if (!isFinishing && !isDestroyed && nav.kind == NavKind.PRIVATE) rebuild() }
        }
    }

    private fun hasVaultPassword() = prefs.contains("vault_hash")

    private fun hashPw(pw: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, 20000, 256)).encoded

    private fun savePw(pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("vault_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("vault_hash", Base64.encodeToString(hashPw(pw, salt), Base64.NO_WRAP))
            .apply()
    }

    private fun checkPw(pw: String): Boolean = try {
        val salt = Base64.decode(prefs.getString("vault_salt", "") ?: "", Base64.NO_WRAP)
        val want = Base64.decode(prefs.getString("vault_hash", "") ?: "", Base64.NO_WRAP)
        MessageDigest.isEqual(want, hashPw(pw, salt))
    } catch (_: Exception) {
        false
    }

    private fun askPassword(title: String, onOk: () -> Unit) {
        ModernDialog.Builder(this)
            .setTitle(title)
            .setInputPassword()
            .setInput("Password", "OK") { pw ->
                if (pw.isNotEmpty() && checkPw(pw)) onOk()
                else Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun createPassword(title: String = "Create password", onDone: () -> Unit) {
        ModernDialog.Builder(this)
            .setTitle(title)
            .setInputPassword()
            .setInput("At least 4 characters", "Next") { first ->
                if (first.length < 4) {
                    Toast.makeText(this, "Use at least 4 characters", Toast.LENGTH_SHORT).show()
                } else {
                    ModernDialog.Builder(this)
                        .setTitle("Confirm password")
                        .setInputPassword()
                        .setInput("Repeat password", "Save") { second ->
                            if (second == first) {
                                savePw(first)
                                Toast.makeText(this, "Password saved", Toast.LENGTH_SHORT).show()
                                onDone()
                            } else {
                                Toast.makeText(this, "Passwords don't match", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .show()
                }
            }
            .show()
    }

    private fun openVault() {
        if (!hasVaultPassword()) createPassword { enterVault() }
        else askPassword("Private folder") { enterVault() }
    }

    private fun enterVault() {
        vaultUnlocked = true
        go(Nav(NavKind.PRIVATE, "", "Private"))
        loadVaultDurations()
    }

    private fun moveToVault(item: LibItem) {
        if (!hasVaultPassword()) {
            createPassword { moveToVault(item) }
            return
        }
        if (busy) {
            Toast.makeText(this, "Please wait…", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        Toast.makeText(this, "Moving to private folder…", Toast.LENGTH_LONG).show()
        io.execute {
            val dir = vaultDir()
            var dest = File(dir, item.title)
            if (dest.exists()) dest = File(dir, "${System.currentTimeMillis()}_${item.title}")
            val part = File(dir, dest.name + ".part")
            val ok = try {
                val pfd = contentResolver.openFileDescriptor(item.uri, "r") ?: throw java.io.IOException("no input")
                pfd.use { p ->
                    java.io.FileInputStream(p.fileDescriptor).use { inp ->
                        FileOutputStream(part).use { out -> fastCopy(inp, out) }
                    }
                }
                val good = (item.size <= 0 || part.length() == item.size) && part.renameTo(dest)
                if (good) {
                    prefs.edit()
                        .putString("vo_" + dest.name, item.folderKey)
                        .putString("vn_" + dest.name, item.title)
                        .apply()
                }
                good
            } catch (_: Exception) {
                false
            }
            ui.post {
                busy = false
                if (!ok) {
                    part.delete()
                    Toast.makeText(this, "Couldn't move this video", Toast.LENGTH_SHORT).show()
                } else {
                    deleteOriginalAfterCopy(item, dest)
                }
            }
        }
    }

    private fun deleteOriginalAfterCopy(item: LibItem, dest: File) {
        val rollback: () -> Unit = {
            dest.delete()
            Toast.makeText(this, "Cancelled. The video stays in your library", Toast.LENGTH_SHORT).show()
        }
        val done: () -> Unit = {
            val key = item.uri.toString()
            if (favs.remove(key)) prefs.edit().putStringSet("favs", HashSet(favs)).apply()
            updateRecent(key, null)
            Toast.makeText(this, "Moved to private folder", Toast.LENGTH_SHORT).show()
            loadMedia()
        }
        if (Build.VERSION.SDK_INT >= 30) {
            pendingAfterGrant = done
            pendingOnDeny = rollback
            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(item.uri))
            grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            runWithAccess(item.uri, rollback) {
                if (contentResolver.delete(item.uri, null, null) > 0) done() else rollback()
            }
        }
    }

    private fun confirmVaultDelete(item: LibItem) {
        ModernDialog.Builder(this)
            .setTitle("Delete permanently?")
            .setMessage(item.title)
            .setPositiveButton("Delete") { _, _ ->
                val f = File(item.uri.path ?: "")
                if (f.delete()) {
                    forgetOrigin(f)
                    vaultDurations.remove(f.path)
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Couldn't delete this file", Toast.LENGTH_SHORT).show()
                }
                rebuild()
            }
            .setNegativeButton("Cancel")
            .show()
    }

    private fun restoreFromVault(item: LibItem) {
        if (Build.VERSION.SDK_INT < 29 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            pendingAfterGrant = { restoreFromVault(item) }
            writePermLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        if (busy) {
            Toast.makeText(this, "Please wait…", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        Toast.makeText(this, "Taking out…", Toast.LENGTH_LONG).show()
        io.execute {
            val src = File(item.uri.path ?: "")
            val ok = try {
                copyToLibrary(src)
                src.delete()
                forgetOrigin(src)
                true
            } catch (_: Exception) {
                false
            }
            ui.post {
                busy = false
                vaultDurations.remove(src.path)
                Toast.makeText(
                    this,
                    if (ok) "Moved back to your library" else "Couldn't take it out",
                    Toast.LENGTH_SHORT
                ).show()
                loadMedia()
            }
        }
    }

    private fun fastCopy(inp: java.io.FileInputStream, out: FileOutputStream) {
        val inCh = inp.channel
        val outCh = out.channel
        val total = inCh.size()
        var pos = 0L
        try {
            while (pos < total) {
                val n = inCh.transferTo(pos, minOf(8L shl 20, total - pos), outCh)
                if (n <= 0L) break
                pos += n
            }
        } catch (_: java.io.IOException) {
        }
        if (pos < total) {
            inCh.position(pos)
            outCh.position(pos)
            val buf = java.nio.ByteBuffer.allocateDirect(1 shl 20)
            while (true) {
                buf.clear()
                if (inCh.read(buf) <= 0) break
                buf.flip()
                while (buf.hasRemaining()) outCh.write(buf)
            }
        }
        out.fd.sync()
    }

    private fun originFolder(src: File): String? = prefs.getString("vo_" + src.name, null)

    private fun forgetOrigin(src: File) {
        prefs.edit().remove("vo_" + src.name).remove("vn_" + src.name).apply()
    }

    @Suppress("DEPRECATION")
    private fun copyToLibrary(src: File) {
        val origin = originFolder(src)
        val name = prefs.getString("vn_" + src.name, null) ?: src.name
        if (Build.VERSION.SDK_INT >= 29) {
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(src.extension.lowercase()) ?: "video/mp4"
            val root = Environment.getExternalStorageDirectory().path + "/"
            val rel = if (origin != null && origin.startsWith(root))
                origin.removePrefix(root).trim('/') + "/" else null
            fun insert(path: String): Uri? {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, path)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            }
            val uri = (if (rel != null) try { insert(rel) } catch (_: Exception) { null } else null)
                ?: insert("Movies/Restored")
                ?: throw java.io.IOException("insert failed")
            try {
                val pfd = contentResolver.openFileDescriptor(uri, "w") ?: throw java.io.IOException("no output")
                pfd.use { p ->
                    FileOutputStream(p.fileDescriptor).use { o ->
                        src.inputStream().use { fastCopy(it as java.io.FileInputStream, o) }
                    }
                }
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            } catch (e: Exception) {
                contentResolver.delete(uri, null, null)
                throw e
            }
        } else {
            val dir = if (origin != null) File(origin)
                else File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Restored")
            dir.mkdirs()
            var dest = File(dir, name)
            if (dest.exists()) dest = File(dir, "${System.currentTimeMillis()}_$name")
            src.inputStream().use { i -> FileOutputStream(dest).use { o -> fastCopy(i as java.io.FileInputStream, o) } }
            MediaScannerConnection.scanFile(this, arrayOf(dest.path), null, null)
        }
    }

    // ------------------------------------------------------------ playback

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) return it.getString(0)
                }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    private fun playFromCurrent(pos: Int) {
        if (pos in currentMedia.indices) startPlayer(currentMedia, pos)
    }

    private fun startPlayer(list: List<LibItem>, pos: Int) {
        var items = list
        var index = pos
        if (items.size > 500) {
            val from = maxOf(0, pos - 250)
            items = items.subList(from, minOf(items.size, from + 500))
            index = pos - from
        }
        startPlayerRaw(items.map { it.uri.toString() }, items.map { it.title }, index)
    }

    private fun startPlayerRaw(uris: List<String>, titles: List<String>, index: Int) {
        if (uris.isEmpty()) return
        launchingPlayer = true
        uris.getOrNull(index)?.let { if (!isVaultUri(it)) recordRecent(it, titles.getOrNull(index) ?: it) }
        val i = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra(PlayerActivity.EXTRA_URIS, ArrayList(uris))
            putStringArrayListExtra(PlayerActivity.EXTRA_TITLES, ArrayList(titles))
            putExtra(PlayerActivity.EXTRA_INDEX, index)
        }
        startActivity(i)
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}
