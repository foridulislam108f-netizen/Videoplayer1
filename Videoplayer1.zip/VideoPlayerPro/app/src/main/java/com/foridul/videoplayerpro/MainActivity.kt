package com.foridul.videoplayerpro

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.os.Environment
import android.util.Base64
import android.webkit.MimeTypeMap
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import android.content.res.Configuration
import java.util.Locale
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.foridul.videoplayerpro.databinding.ActivityMainBinding
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

enum class NavKind { ROOT, FOLDER, RECENT, PLAYLISTS, SMART, PRIVATE, PICK }

data class Nav(val kind: NavKind, val key: String = "", val title: String = "")

enum class SortMode { NAME_ASC, NAME_DESC, NEW, OLD, BIG }

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var adapter: RowAdapter
    private lateinit var prefs: SharedPreferences
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var videos: List<LibItem> = emptyList()
    private var audios: List<LibItem> = emptyList()
    private var currentMedia: List<LibItem> = emptyList()

    private var tab = 0 // 0 video, 1 music, 2 settings
    private var nav = Nav(NavKind.ROOT)
    private var flat = false
    private var grid = false
    private var sort = SortMode.NEW
    private var permissionMissing = false
    private var askedPermission = false
    private var askedAllFiles = false

    private val videoPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val audioPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private fun has(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    /** Android 11+ all-files access (MANAGE_EXTERNAL_STORAGE). */
    private fun hasAllFilesAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            // After media perms, ask for All files access once (first time)
            maybeRequestAllFilesAccess()
            loadMedia()
        }

    private val allFilesLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            loadMedia()
        }

    private var favs: MutableSet<String> = HashSet()
    private var pendingAfterGrant: (() -> Unit)? = null
    private var pendingOnDeny: (() -> Unit)? = null
    private var vaultUnlocked = false
    private var launchingPlayer = false
    private var busy = false
    private val vaultDurations = ConcurrentHashMap<String, Long>()

    private val grantLauncher =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
            val action = pendingAfterGrant
            val deny = pendingOnDeny
            pendingAfterGrant = null
            pendingOnDeny = null
            if (res.resultCode == RESULT_OK) action?.invoke() else deny?.invoke()
        }

    private val writePermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val action = pendingAfterGrant
            val deny = pendingOnDeny
            pendingAfterGrant = null
            pendingOnDeny = null
            if (granted) {
                action?.invoke()
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show()
                deny?.invoke()
            }
        }

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            uris.forEach {
                try {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            startPlayerRaw(uris.map { it.toString() }, uris.map { displayName(it) }, 0)
        }


    override fun attachBaseContext(newBase: Context) {
        val p = newBase.getSharedPreferences("home", Context.MODE_PRIVATE)
        val lang = p.getString("lang", "en") ?: "en"
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val config = Configuration(newBase.resources.configuration)
        config.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = getSharedPreferences("home", Context.MODE_PRIVATE)
        applyThemeMode(prefs.getInt("theme_mode", 0))
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        grid = prefs.getBoolean("grid", false)
        sort = SortMode.values().getOrElse(prefs.getInt("sort", SortMode.NEW.ordinal)) { SortMode.NEW }
        if (!prefs.contains("baseline")) {
            prefs.edit().putLong("baseline", System.currentTimeMillis() / 1000).apply()
        }

        favs = HashSet(prefs.getStringSet("favs", emptySet()) ?: emptySet())

        adapter = RowAdapter(
            onFolder = { openFolder(it) },
            onFolderMenu = { anchor, row -> showFolderMenu(anchor, row) },
            onMedia = { pos -> playFromCurrent(pos) },
            onMediaLong = { startSelection(it) },
            onFolderLong = { startFolderSelection(it) },
            onSelectionChanged = { updateSelectionBar() }
        )
        adapter.isFav = { favs.contains(it.uri.toString()) }
        b.recycler.adapter = adapter
        applyLayoutMode()
        setupSelectionBar()
        setupPickBar()
        b.fabAdd.setOnClickListener { openPicker() }

        b.btnBack.setOnClickListener { goBack() }
        b.btnCast.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_CAST_SETTINGS))
            } catch (_: Exception) {
                Toast.makeText(this, "Cast is not available on this device", Toast.LENGTH_SHORT).show()
            }
        }
        b.btnSearch.setOnClickListener { toggleSearch() }
        b.btnMore.setOnClickListener { showTopMenu() }

        b.chipPlaylists.setOnClickListener { go(Nav(NavKind.PLAYLISTS, "", "Playlists")) }
        b.chipRecent.setOnClickListener { go(Nav(NavKind.RECENT, "", "Recently Played")) }
        b.chipStream.setOnClickListener { showStreamDialog() }
        b.chipPrivate.setOnClickListener { openVault() }
        b.chipPrivate.setOnLongClickListener {
            if (prefs.getBoolean("hide_private_setting", false)) {
                ModernDialog.Builder(this)
                    .setTitle("Private Folder")
                    .setMessage("Show the Private Folder option in Settings again?")
                    .setPositiveButton("Show") { _, _ ->
                        prefs.edit().putBoolean("hide_private_setting", false).apply()
                        buildSettings()
                        Toast.makeText(this, "Private Folder is back in Settings", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancel")
                    .show()
                true
            } else false
        }

        b.scopeBtn.setOnClickListener { showScopeMenu() }
        val toggleLayout = View.OnClickListener {
            grid = !grid
            prefs.edit().putBoolean("grid", grid).apply()
            applyLayoutMode()
            rebuild()
        }
        b.btnLayout.setOnClickListener(toggleLayout)
        b.btnLayoutTop.setOnClickListener(toggleLayout)
        b.btnSort.setOnClickListener { showSortMenu(b.btnSort, true) }
        b.btnSortTop.setOnClickListener { showSortMenu(b.btnSortTop, true) }

        b.navVideo.setOnClickListener { selectTab(0) }
        b.navMusic.setOnClickListener { selectTab(1) }
        b.navSettings.setOnClickListener { selectTab(2) }

        b.tvEmpty.setOnClickListener {
            if (permissionMissing) {
                askedPermission = false
                ensurePermissionAndLoad()
            }
        }
        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                rebuild()
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!handleBack()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        updateNavBar()
        rebuild()
    }

    override fun onStart() {
        super.onStart()
        launchingPlayer = false
    }

    override fun onStop() {
        super.onStop()
        if ((nav.kind == NavKind.PRIVATE || nav.kind == NavKind.PICK) && !launchingPlayer && !isChangingConfigurations) {
            vaultUnlocked = false
            nav = Nav(NavKind.ROOT)
            rebuild()
        }
    }

    override fun onResume() {
        super.onResume()
        ensurePermissionAndLoad()
    }

    // ------------------------------------------------------------ navigation

    private fun handleBack(): Boolean {
        if (nav.kind == NavKind.PICK) {
            go(Nav(NavKind.PRIVATE, "", "Private"))
            return true
        }
        if (adapter.selectionMode) {
            exitSelection()
            return true
        }
        if (b.etSearch.visibility == View.VISIBLE) {
            closeSearch()
            return true
        }
        if (nav.kind != NavKind.ROOT && tab != 2) {
            nav = Nav(NavKind.ROOT)
            rebuild()
            return true
        }
        if (tab != 0) {
            selectTab(0)
            return true
        }
        return false
    }

    private fun goBack() {
        handleBack()
    }

    private fun go(n: Nav) {
        exitSelection()
        nav = n
        rebuild()
        b.recycler.scrollToPosition(0)
    }

    private fun selectTab(t: Int) {
        exitSelection()
        closeSearch()
        tab = t
        nav = Nav(NavKind.ROOT)
        flat = false
        updateNavBar()
        if (t == 2) buildSettings()
        rebuild()
    }

    private fun applyLayoutMode() {
        adapter.grid = grid
        b.recycler.layoutManager =
            if (grid) GridLayoutManager(this, 2) else LinearLayoutManager(this)
        val layoutIcon = if (grid) R.drawable.ic_list_view else R.drawable.ic_grid_view
        b.btnLayout.setImageResource(layoutIcon)
        b.btnLayoutTop.setImageResource(layoutIcon)
    }

    private fun updateNavBar() {
        fun style(sel: Boolean, pill: View, icon: android.widget.ImageView, label: android.widget.TextView) {
            pill.setBackgroundResource(if (sel) R.drawable.bg_nav_pill else 0)
            val c = Ui.color(this, if (sel) R.color.text_primary else R.color.text_secondary)
            icon.imageTintList = ColorStateList.valueOf(c)
            label.setTextColor(c)
            label.setTypeface(null, if (sel) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        }
        style(tab == 0, b.pillVideo, b.ivNavVideo, b.tvNavVideo)
        style(tab == 1, b.pillMusic, b.ivNavMusic, b.tvNavMusic)
        style(tab == 2, b.pillSettings, b.ivNavSettings, b.tvNavSettings)
    }

    // ------------------------------------------------------------ search

    private fun toggleSearch() {
        if (b.etSearch.visibility == View.VISIBLE) {
            closeSearch()
        } else {
            b.etSearch.visibility = View.VISIBLE
            b.etSearch.requestFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(b.etSearch, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun closeSearch() {
        if (b.etSearch.visibility != View.VISIBLE) return
        b.etSearch.setText("")
        b.etSearch.visibility = View.GONE
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(b.etSearch.windowToken, 0)
        rebuild()
    }

    // ------------------------------------------------------------ menus

    private fun showTopMenu() {
        ModernPopup.show(
            b.btnMore,
            listOf(
                ModernPopup.Item("Refresh", R.drawable.ic_refresh),
                ModernPopup.Item("Settings", R.drawable.ic_settings)
            ),
            alignEnd = true
        ) {
            when (it) {
                0 -> loadMedia()
                1 -> selectTab(2)
            }
        }
    }

    private fun showScopeMenu() {
        if (nav.kind != NavKind.ROOT) return
        val allLabel = if (tab == 1) "All songs" else "All videos"
        ModernPopup.show(
            b.scopeBtn,
            listOf(
                ModernPopup.Item(getString(R.string.all_folders), R.drawable.ic_folder, !flat),
                ModernPopup.Item(allLabel, if (tab == 1) R.drawable.ic_music else R.drawable.ic_video, flat)
            )
        ) {
            flat = it == 1
            rebuild()
        }
    }

    private fun showSortMenu(anchor: View, alignEnd: Boolean) {
        val folderMode = tab != 2 && nav.kind == NavKind.ROOT && !flat
        val labels = listOf(
            "Name (A–Z)",
            "Name (Z–A)",
            "Newest first",
            "Oldest first",
            if (folderMode) "Most items" else "Largest first"
        )
        ModernPopup.show(
            anchor,
            labels.mapIndexed { i, l -> ModernPopup.Item(l, 0, sort.ordinal == i) },
            alignEnd
        ) {
            sort = SortMode.values()[it]
            prefs.edit().putInt("sort", it).apply()
            if (tab == 2) buildSettings() else rebuild()
        }
    }

    private fun showFolderMenu(anchor: View, row: Row.Folder) {
        ModernPopup.show(
            anchor,
            listOf(
                ModernPopup.Item("Play all", R.drawable.ic_play),
                ModernPopup.Item("Open", R.drawable.ic_folder)
            ),
            alignEnd = true
        ) {
            when (it) {
                0 -> {
                    val list = itemsFor(row)
                    if (list.isNotEmpty()) startPlayer(list, 0)
                }
                1 -> openFolder(row)
            }
        }
    }

    private fun showStreamDialog() {
        ModernDialog.Builder(this)
            .setTitle("Network stream")
            .setInput("https://example.com/video.m3u8", "Play") { url ->
                if (url.isEmpty()) {
                    Toast.makeText(this, "Enter a URL", Toast.LENGTH_SHORT).show()
                } else {
                    startPlayerRaw(listOf(url), listOf(Uri.parse(url).lastPathSegment ?: url), 0)
                }
            }
            .show()
    }

    // ------------------------------------------------------------ data

    private fun ensurePermissionAndLoad() {
        val need = listOf(videoPermission, audioPermission).distinct().filter { !has(it) }
        if (need.isEmpty() || askedPermission) {
            maybeRequestAllFilesAccess()
            loadMedia()
        } else {
            askedPermission = true
            permLauncher.launch(need.toTypedArray())
        }
    }

    /**
     * First time only: open system "All files access" screen so the user can Allow it.
     * Needed on Android 11+ for reliable rename / delete / folder operations.
     */
    private fun maybeRequestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < 30) return
        if (hasAllFilesAccess()) return
        if (askedAllFiles || prefs.getBoolean("asked_all_files", false)) return
        askedAllFiles = true
        prefs.edit().putBoolean("asked_all_files", true).apply()
        try {
            val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                data = Uri.parse("package:$packageName")
            }
            allFilesLauncher.launch(intent)
        } catch (_: Exception) {
            try {
                allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
                // Device may not expose the settings page; ignore
            }
        }
    }

    private fun loadMedia() {
        io.execute {
            val v = if (has(videoPermission)) query(false) else emptyList()
            val a = if (has(audioPermission)) query(true) else emptyList()
            ui.post {
                if (isFinishing || isDestroyed) return@post
                permissionMissing = !has(videoPermission)
                videos = v
                audios = a
                rebuild()
                if (tab == 2) buildSettings()
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun query(isAudio: Boolean): List<LibItem> {
        val out = ArrayList<LibItem>()
        val collection =
            if (isAudio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val durKey = if (isAudio) MediaStore.Audio.Media.DURATION else MediaStore.Video.Media.DURATION
        val projection = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            durKey,
            MediaStore.MediaColumns.SIZE,
            MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.DATA
        )
        try {
            contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.MediaColumns.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val durCol = c.getColumnIndexOrThrow(durKey)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val addCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val dataCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val data = c.getString(dataCol)
                    out.add(
                        LibItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            title = c.getString(nameCol) ?: "Media $id",
                            durationMs = c.getLong(durCol),
                            size = c.getLong(sizeCol),
                            dateAdded = c.getLong(addCol),
                            folderKey = data?.let { File(it).parent } ?: "Unknown",
                            isAudio = isAudio
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun src(): List<LibItem> = if (tab == 1) audios else videos

    private fun folderName(key: String): String =
        key.trimEnd('/').substringAfterLast('/').ifEmpty { key }

    private fun freshThreshold(key: String): Long =
        maxOf(prefs.getLong("baseline", 0L), prefs.getLong("seen_$key", 0L))

    private fun sorted(list: List<LibItem>): List<LibItem> = when (sort) {
        SortMode.NAME_ASC -> list.sortedBy { it.title.lowercase() }
        SortMode.NAME_DESC -> list.sortedByDescending { it.title.lowercase() }
        SortMode.NEW -> list.sortedByDescending { it.dateAdded }
        SortMode.OLD -> list.sortedBy { it.dateAdded }
        SortMode.BIG -> list.sortedByDescending { it.size }
    }

    private fun folderRows(): List<Row> {
        val groups = src().groupBy { it.folderKey }
        val rows = groups.map { (key, items) ->
            val th = freshThreshold(key)
            Row.Folder(
                key = key,
                name = folderName(key),
                count = items.size,
                fresh = items.count { it.dateAdded > th },
                isAudio = tab == 1
            ) to items.maxOf { it.dateAdded }
        }
        val sortedRows = when (sort) {
            SortMode.NAME_ASC -> rows.sortedBy { it.first.name.lowercase() }
            SortMode.NAME_DESC -> rows.sortedByDescending { it.first.name.lowercase() }
            SortMode.NEW -> rows.sortedByDescending { it.second }
            SortMode.OLD -> rows.sortedBy { it.second }
            SortMode.BIG -> rows.sortedByDescending { it.first.count }
        }
        return sortedRows.map { it.first }
    }

    private fun smartList(key: String): List<LibItem> = when (key) {
        "added" -> videos.sortedByDescending { it.dateAdded }.take(50)
        "long" -> videos.sortedByDescending { it.durationMs }.take(50)
        "big" -> videos.sortedByDescending { it.size }.take(50)
        "fav" -> favItems()
        else -> videos
    }

    private fun favItems(): List<LibItem> =
        (videos + audios).filter { favs.contains(it.uri.toString()) }.sortedByDescending { it.dateAdded }

    private fun smartRows(): List<Row> = listOf(
        Row.Folder("fav", "Favorites", favItems().size, 0, false, true, R.drawable.ic_heart),
        Row.Folder("added", "Recently added", minOf(50, videos.size), 0, false, true, R.drawable.ic_playlist),
        Row.Folder("long", "Longest videos", minOf(50, videos.size), 0, false, true, R.drawable.ic_history),
        Row.Folder("big", "Largest videos", minOf(50, videos.size), 0, false, true, R.drawable.ic_video),
        Row.Folder("all", "All videos", videos.size, 0, false, true, R.drawable.ic_folder)
    )

    private fun itemsFor(row: Row.Folder): List<LibItem> =
        if (row.smart) smartList(row.key) else sorted(src().filter { it.folderKey == row.key })

    private fun openFolder(row: Row.Folder) {
        if (row.smart) {
            go(Nav(NavKind.SMART, row.key, row.name))
        } else {
            prefs.edit().putLong("seen_${row.key}", System.currentTimeMillis() / 1000).apply()
            go(Nav(NavKind.FOLDER, row.key, row.name))
        }
    }

    // ------------------------------------------------------------ recent

    private fun recordRecent(uri: String, title: String) {
        try {
            val old = JSONArray(prefs.getString("recent", "[]"))
            val out = JSONArray()
            out.put(JSONObject().put("u", uri).put("t", title))
            for (i in 0 until old.length()) {
                val o = old.getJSONObject(i)
                if (o.getString("u") != uri && out.length() < 30) out.put(o)
            }
            prefs.edit().putString("recent", out.toString()).apply()
        } catch (_: Exception) {
        }
    }

    /** Drops [uri] from the recent list, or gives it [newTitle] when one is passed. */
    private fun updateRecent(uri: String, newTitle: String?) {
        try {
            val old = JSONArray(prefs.getString("recent", "[]"))
            val out = JSONArray()
            for (i in 0 until old.length()) {
                val o = old.getJSONObject(i)
                if (o.getString("u") == uri) {
                    if (newTitle != null) out.put(JSONObject().put("u", uri).put("t", newTitle))
                } else {
                    out.put(o)
                }
            }
            prefs.edit().putString("recent", out.toString()).apply()
        } catch (_: Exception) {
        }
    }

    private fun recentItems(): List<LibItem> {
        val out = ArrayList<LibItem>()
        try {
            val known = (videos + audios).associateBy { it.uri.toString() }
            val arr = JSONArray(prefs.getString("recent", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val u = o.getString("u")
                out.add(known[u] ?: LibItem(-1, Uri.parse(u), o.optString("t", u), 0, 0, 0, "", false))
            }
        } catch (_: Exception) {
        }
        return out
    }

    // ------------------------------------------------------------ list building

    private fun rebuild() {
        val q = b.etSearch.text?.toString().orEmpty().trim().lowercase()
        val rows = ArrayList<Row>()
        var media: List<LibItem>? = null

        if ((nav.kind == NavKind.PRIVATE || nav.kind == NavKind.PICK) && !vaultUnlocked) nav = Nav(NavKind.ROOT)
        if (nav.kind != NavKind.PRIVATE && nav.kind != NavKind.PICK) vaultUnlocked = false

        when {
            tab == 2 -> {}
            nav.kind == NavKind.PRIVATE ->
                media = sorted(vaultItems().filter { q.isEmpty() || it.title.lowercase().contains(q) })
            nav.kind == NavKind.PICK ->
                media = sorted(videos.filter { it.id >= 0 && (q.isEmpty() || it.title.lowercase().contains(q)) })
            q.isNotEmpty() -> media = sorted(src().filter { it.title.lowercase().contains(q) })
            nav.kind == NavKind.FOLDER -> media = sorted(src().filter { it.folderKey == nav.key })
            nav.kind == NavKind.RECENT -> media = recentItems()
            nav.kind == NavKind.SMART -> media = smartList(nav.key)
            nav.kind == NavKind.PLAYLISTS -> rows.addAll(smartRows())
            flat -> media = sorted(src())
            else -> rows.addAll(folderRows())
        }
        if (media != null) {
            currentMedia = media
            media.forEach { rows.add(Row.Media(it)) }
        }
        adapter.submit(rows)

        // chrome
        val root = nav.kind == NavKind.ROOT
        val onList = tab != 2
        b.pageList.visibility = if (onList) View.VISIBLE else View.GONE
        b.pageSettings.visibility = if (onList) View.GONE else View.VISIBLE
        // Inside a folder: compact header (back, small title, search, layout, sort)
        val inFolder = onList && !root
        b.btnCast.visibility = if (onList && !inFolder) View.VISIBLE else View.GONE
        b.btnSearch.visibility = if (onList) View.VISIBLE else View.GONE
        b.btnMore.visibility = if (onList && !inFolder) View.VISIBLE else View.GONE
        adapter.badgeBlue = nav.kind == NavKind.PRIVATE || nav.kind == NavKind.PICK
        b.btnLayoutTop.visibility = if (inFolder) View.VISIBLE else View.GONE
        b.btnSortTop.visibility = if (inFolder) View.VISIBLE else View.GONE
        b.scopeRow.visibility = if (inFolder) View.GONE else View.VISIBLE
        b.tvTitle.textSize = if (inFolder) 17f else 22f
        b.btnBack.visibility = if (onList && !root) View.VISIBLE else View.GONE
        b.tvTitle.text = when {
            tab == 2 -> getString(R.string.settings)
            !root -> nav.title
            else -> ""
        }
        b.chipScroll.visibility = if (tab == 0 && root && q.isEmpty()) View.VISIBLE else View.GONE
        b.scopeBtn.isClickable = root
        b.ivScopeArrow.visibility = if (root) View.VISIBLE else View.GONE
        b.tvScopeText.text = when {
            !root -> nav.title
            flat -> if (tab == 1) "All songs" else "All videos"
            else -> getString(R.string.all_folders)
        }

        // empty state
        if (onList && rows.isEmpty()) {
            val text = when {
                q.isNotEmpty() -> "No results found."
                permissionMissing -> "Allow media access to see your files.\nTap here to try again."
                nav.kind == NavKind.PRIVATE -> "Nothing here yet.\nTap + to add videos."
                nav.kind == NavKind.PICK -> "No videos found."
                nav.kind == NavKind.RECENT -> "Nothing played yet."
                tab == 1 -> "No music found."
                else -> "No videos found.\nUse Settings → Open files or Network stream."
            }
            b.tvEmpty.text = text
            b.tvEmpty.isClickable = permissionMissing
            b.tvEmpty.visibility = View.VISIBLE
        } else {
            b.tvEmpty.visibility = View.GONE
        }

        // private folder: plus button, extra bottom room, picker title
        b.fabAdd.visibility = if (nav.kind == NavKind.PRIVATE && tab != 2) View.VISIBLE else View.GONE
        b.recycler.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, if (nav.kind == NavKind.PRIVATE) 84 else 12))
        if (nav.kind == NavKind.PICK) updatePickBar()
        if (nav.kind == NavKind.PRIVATE && adapter.selectionMode) updateSelectionBar()
    }


    private fun applyThemeMode(mode: Int) {
        val night = when (mode) {
            1 -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM  // System
            2 -> AppCompatDelegate.MODE_NIGHT_NO            // Light
            else -> AppCompatDelegate.MODE_NIGHT_YES        // Dark (0)
        }
        AppCompatDelegate.setDefaultNightMode(night)
    }

    private fun themeLabel(mode: Int): String = when (mode) {
        1 -> getString(R.string.theme_system)
        2 -> getString(R.string.theme_light)
        else -> getString(R.string.theme_dark)
    }

    private fun langLabel(): String {
        val lang = prefs.getString("lang", "en") ?: "en"
        return if (lang == "bn") getString(R.string.bangla) else getString(R.string.english)
    }

    // ------------------------------------------------------------ settings page

    private fun buildSettings() {
        val list = b.settingsList
        list.removeAllViews()

        section(list, getString(R.string.open))
        settingRow(list, R.drawable.ic_open, "Open files", "Pick videos or audio from storage") {
            pickFiles.launch(arrayOf("video/*", "audio/*", "application/x-matroska", "application/octet-stream"))
        }
        settingRow(list, R.drawable.ic_link, "Network stream", "Play a link (HLS, DASH, MP4, MKV)") {
            showStreamDialog()
        }

        section(list, getString(R.string.appearance))
        val themeMode = prefs.getInt("theme_mode", 0)
        settingRow(list, R.drawable.ic_settings, getString(R.string.theme), themeLabel(themeMode)) {
            val labels = arrayOf(getString(R.string.theme_dark), getString(R.string.theme_system), getString(R.string.theme_light))
            ModernDialog.Builder(this)
                .setTitle(getString(R.string.theme))
                .setSingleChoiceItems(labels, themeMode) { dlg, which ->
                    prefs.edit().putInt("theme_mode", which).apply()
                    applyThemeMode(which)
                    dlg.dismiss()
                    recreate()
                }
                .show()
        }
        settingRow(list, R.drawable.ic_info, getString(R.string.language), langLabel()) {
            val labels = arrayOf(getString(R.string.english), getString(R.string.bangla))
            val current = if ((prefs.getString("lang", "en") ?: "en") == "bn") 1 else 0
            ModernDialog.Builder(this)
                .setTitle(getString(R.string.language))
                .setSingleChoiceItems(labels, current) { dlg, which ->
                    val code = if (which == 1) "bn" else "en"
                    prefs.edit().putString("lang", code).apply()
                    dlg.dismiss()
                    recreate()
                }
                .show()
        }

        section(list, getString(R.string.player))
        val playerPrefs = getSharedPreferences(OrientationPrefs.PREFS, MODE_PRIVATE)
        settingRow(
            list, R.drawable.ic_rotate, "Default screen orientation",
            OrientationPrefs.NAMES[OrientationPrefs.get(playerPrefs)]
        ) {
            ModernDialog.Builder(this)
                .setTitle("Default screen orientation")
                .setSingleChoiceItems(OrientationPrefs.NAMES, OrientationPrefs.get(playerPrefs)) { dlg, which ->
                    OrientationPrefs.set(playerPrefs, which)
                    dlg.dismiss()
                    buildSettings()
                }
                .show()
        }

        section(list, getString(R.string.library))
        val sortLabel = listOf("Name (A–Z)", "Name (Z–A)", "Newest first", "Oldest first", "Largest first")[sort.ordinal]
        settingRow(list, R.drawable.ic_sort, "Sort order", sortLabel) { row -> showSortMenu(row, false) }
        settingRow(list, if (grid) R.drawable.ic_grid_view else R.drawable.ic_list_view, "Layout", if (grid) "Grid" else "List") {
            grid = !grid
            prefs.edit().putBoolean("grid", grid).apply()
            applyLayoutMode()
            buildSettings()
        }
        settingRow(list, R.drawable.ic_refresh, "Rescan library", "Refresh videos and music") {
            loadMedia()
            Toast.makeText(this, "Scanning…", Toast.LENGTH_SHORT).show()
        }
        settingRow(list, R.drawable.ic_trash, "Clear recently played", "Remove the history list") {
            prefs.edit().remove("recent").apply()
            Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
        }

        if (!prefs.getBoolean("hide_private_setting", false)) {
            section(list, "Private")
            settingRow(list, R.drawable.ic_lock, "Private Folder", null) { showPrivateFolderMenu() }
        }

        section(list, getString(R.string.about))
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0.0"
        } catch (_: Exception) {
            "1.0.0"
        }
        settingRow(list, R.drawable.ic_info, "Video Player Pro", "Version $version", null)
        settingRow(list, R.drawable.ic_refresh, "Check for updates", "Download the newest version") {
            Updater.check(this)
        }
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(
            Ui.text(this, title.uppercase(), 12f, Ui.color(this, R.color.accent), true).apply {
                letterSpacing = 0.08f
                setPadding(Ui.dp(this@MainActivity, 24), Ui.dp(this@MainActivity, 20), Ui.dp(this@MainActivity, 24), Ui.dp(this@MainActivity, 6))
            }
        )
    }

    private fun settingRow(
        parent: LinearLayout,
        icon: Int,
        title: String,
        subtitle: String?,
        onClick: ((View) -> Unit)?
    ) {
        val ctx = this
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(Ui.dp(ctx, 20), Ui.dp(ctx, 10), Ui.dp(ctx, 20), Ui.dp(ctx, 10))
            minimumHeight = Ui.dp(ctx, 64)
            if (onClick != null) {
                setBackgroundResource(R.drawable.bg_row)
                isClickable = true
                isFocusable = true
            }
        }
        val iconBox = android.widget.FrameLayout(ctx).apply {
            setBackgroundResource(R.drawable.bg_setting_icon)
            layoutParams = LinearLayout.LayoutParams(Ui.dp(ctx, 44), Ui.dp(ctx, 44))
        }
        val iv = Ui.icon(ctx, icon, 22, Ui.color(ctx, R.color.accent))
        iv.layoutParams = android.widget.FrameLayout.LayoutParams(Ui.dp(ctx, 22), Ui.dp(ctx, 22), Gravity.CENTER)
        iconBox.addView(iv)
        row.addView(iconBox)

        val texts = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = Ui.dp(ctx, 16)
            }
        }
        texts.addView(Ui.text(ctx, title, 16.5f, Ui.color(ctx, R.color.text_primary)))
        if (subtitle != null) {
            texts.addView(Ui.text(ctx, subtitle, 13.5f, Ui.color(ctx, R.color.text_secondary)).apply {
                setPadding(0, Ui.dp(ctx, 2), 0, 0)
            })
        }
        row.addView(texts)
        if (onClick != null) row.setOnClickListener { onClick(row) }
        parent.addView(row)
    }

    // ------------------------------------------------------------ item actions / multi-select

    private var selectionBar: LinearLayout? = null
    private var btnSelRename: View? = null
    private var btnSelDelete: View? = null
    private var btnSelFav: View? = null
    private var btnSelPrivate: View? = null
    private var btnSelTakeOut: View? = null

    private fun setupSelectionBar() {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            val r = Ui.dp(this@MainActivity, 14).toFloat()
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Ui.color(this@MainActivity, R.color.surface_high))
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setStroke(Ui.dp(this@MainActivity, 1), Ui.color(this@MainActivity, R.color.outline))
            }
            setPadding(Ui.dp(this@MainActivity, 12), 0, Ui.dp(this@MainActivity, 12), 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                Ui.dp(this@MainActivity, 52)
            )
        }
        fun makeCell(icon: Int, tint: Int, desc: String, onClick: () -> Unit): View {
            val cell = android.widget.FrameLayout(this).apply {
                background = Ui.ripple(this@MainActivity)
                isClickable = true
                isFocusable = true
                contentDescription = desc
                setOnClickListener { onClick() }
            }
            val ic = Ui.icon(this, icon, 24, tint)
            ic.layoutParams = android.widget.FrameLayout.LayoutParams(
                Ui.dp(this, 24), Ui.dp(this, 24), Gravity.CENTER
            )
            cell.addView(ic)
            bar.addView(cell, LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f))
            return cell
        }
        btnSelRename = makeCell(R.drawable.ic_edit, Ui.color(this, R.color.accent), "Rename") {
            val folders = adapter.selectedFolderRows()
            val items = adapter.selectedItems()
            when {
                folders.size == 1 && items.isEmpty() -> promptRenameFolder(folders[0])
                items.size == 1 && folders.isEmpty() -> promptRename(items[0])
            }
        }
        btnSelDelete = makeCell(R.drawable.ic_trash, 0xFFFF6B6B.toInt(), "Delete") {
            if (nav.kind == NavKind.PRIVATE) confirmVaultDeleteSelected() else confirmDeleteSelected()
        }
        btnSelFav = makeCell(R.drawable.ic_heart, 0xFFFF5A8A.toInt(), "Favorite") {
            toggleFavSelected()
        }
        btnSelPrivate = makeCell(R.drawable.ic_lock, Ui.color(this, R.color.c_private), "Private") {
            moveSelectedToVault()
        }
        btnSelTakeOut = makeCell(R.drawable.ic_unlock, Ui.color(this, R.color.accent), "Take out") {
            takeOutSelected()
        }
        // Insert above the bottom nav (last child of root LinearLayout)
        val root = b.root as ViewGroup
        val navIndex = root.indexOfChild(b.navVideo.parent as? View ?: b.navVideo)
        if (navIndex >= 0) root.addView(bar, navIndex) else root.addView(bar)
        selectionBar = bar
    }

    // ------------------------------------------------------------ private folder: add videos picker

    private var pickBar: LinearLayout? = null
    private var pickBtn: android.widget.TextView? = null

    private fun setupPickBar() {
        val ctx = this
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 10), Ui.dp(ctx, 16), Ui.dp(ctx, 10))
            background = Ui.rounded(Ui.color(ctx, R.color.surface_high), 0f, ctx)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val btn = Ui.text(ctx, "Add to Private", 15f, 0xFFFFFFFF.toInt(), true).apply {
            gravity = Gravity.CENTER
            background = Ui.rounded(Ui.color(ctx, R.color.accent), 26f, ctx)
            setPadding(Ui.dp(ctx, 20), Ui.dp(ctx, 13), Ui.dp(ctx, 20), Ui.dp(ctx, 13))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            isClickable = true
            isFocusable = true
            setOnClickListener { addPickedToVault() }
        }
        bar.addView(btn)
        val root = b.root as ViewGroup
        val navIndex = root.indexOfChild(b.navVideo.parent as? View ?: b.navVideo)
        if (navIndex >= 0) root.addView(bar, navIndex) else root.addView(bar)
        pickBar = bar
        pickBtn = btn
    }

    private fun openPicker() {
        if (!vaultUnlocked) return
        go(Nav(NavKind.PICK, "", "Add videos"))
        adapter.enterPickMode()
    }

    private fun updatePickBar() {
        val bar = pickBar ?: return
        selectionBar?.visibility = View.GONE
        val n = adapter.selectedCount()
        b.btnBack.visibility = View.VISIBLE
        b.tvTitle.text = if (n > 0) "$n selected" else nav.title
        if (n > 0) {
            pickBtn?.text = if (n == 1) "Add 1 video to Private" else "Add $n videos to Private"
            bar.visibility = View.VISIBLE
        } else {
            bar.visibility = View.GONE
        }
    }

    private fun addPickedToVault() {
        if (adapter.selectedCount() == 0) return
        moveSelectedToVault()
        go(Nav(NavKind.PRIVATE, "", "Private"))
    }

    private fun startSelection(item: LibItem) {
        if (item.id == -1L) return
        adapter.enterSelection(item)
        updateSelectionBar()
    }

    private fun startFolderSelection(folder: Row.Folder) {
        // Smart playlists still work via long-press selection of their contents
        adapter.enterFolderSelection(folder)
        updateSelectionBar()
    }

    /** Directly selected media + every file inside selected folders. */
    private fun resolvedSelectedMedia(): List<LibItem> {
        val fromMedia = adapter.selectedItems()
        val fromFolders = adapter.selectedFolderRows().flatMap { itemsFor(it) }
        // Dedupe by uri
        val seen = HashSet<String>()
        val out = ArrayList<LibItem>()
        (fromMedia + fromFolders).forEach { item ->
            val k = item.uri.toString()
            if (seen.add(k)) out.add(item)
        }
        return out
    }

    private fun exitSelection() {
        adapter.exitSelection()
        selectionBar?.visibility = View.GONE
        // Restore header title / back button from current nav
        val root = nav.kind == NavKind.ROOT
        val onList = tab != 2
        b.btnBack.visibility = if (onList && !root) View.VISIBLE else View.GONE
        b.tvTitle.text = when {
            tab == 2 -> getString(R.string.settings)
            !root -> nav.title
            else -> ""
        }
    }

    private fun updateSelectionBar() {
        if (nav.kind == NavKind.PICK) {
            updatePickBar()
            return
        }
        pickBar?.visibility = View.GONE
        if (nav.kind == NavKind.PRIVATE) {
            b.fabAdd.visibility = if (adapter.selectionMode) View.GONE else View.VISIBLE
        }
        val bar = selectionBar ?: return
        if (!adapter.selectionMode || adapter.selectedCount() == 0) {
            bar.visibility = View.GONE
            // Restore title if we overwrote it
            if (nav.kind != NavKind.ROOT) {
                b.tvTitle.text = nav.title
            }
            if (adapter.selectionMode && nav.kind == NavKind.PRIVATE) {
                b.tvTitle.text = "Select videos"
                b.btnBack.visibility = View.VISIBLE
            }
            return
        }
        bar.visibility = View.VISIBLE
        val count = adapter.selectedCount()
        val items = resolvedSelectedMedia()
        b.tvTitle.text = "$count selected"
        b.btnBack.visibility = View.VISIBLE
        if (nav.kind == NavKind.PRIVATE) {
            // inside the private folder: only Take out and Delete
            btnSelRename?.visibility = View.GONE
            btnSelFav?.visibility = View.GONE
            btnSelPrivate?.visibility = View.GONE
            btnSelTakeOut?.visibility = View.VISIBLE
            btnSelDelete?.visibility = View.VISIBLE
            return
        }
        btnSelTakeOut?.visibility = View.GONE
        // Rename: one file only, OR one real (non-smart) folder only
        val folders = adapter.selectedFolderRows()
        val singleFile = adapter.selectedItems().size == 1 && folders.isEmpty()
        val singleFolder = folders.size == 1 && adapter.selectedItems().isEmpty() && !folders[0].smart
        btnSelRename?.visibility = if (singleFile || singleFolder) View.VISIBLE else View.GONE
        // Private only if at least one non-audio video is selected
        val hasVideo = items.any { !it.isAudio }
        btnSelPrivate?.visibility = if (hasVideo) View.VISIBLE else View.GONE
        // Fav only if there is at least one file
        btnSelFav?.visibility = if (items.isNotEmpty()) View.VISIBLE else View.GONE
        btnSelDelete?.visibility = if (items.isNotEmpty()) View.VISIBLE else View.GONE
        // Update fav icon based on selection (all fav → unfavorite look)
        val allFav = items.isNotEmpty() && items.all { favs.contains(it.uri.toString()) }
        (btnSelFav as? android.widget.FrameLayout)?.let { cell ->
            val ic = cell.getChildAt(0) as? android.widget.ImageView
            ic?.setImageResource(if (allFav) R.drawable.ic_heart_fill else R.drawable.ic_heart)
        }
    }

    private fun takeOutSelected() {
        val items = adapter.selectedItems().filter { it.id == -2L }
        if (items.isEmpty()) return
        exitSelection()
        restoreManyFromVault(items)
    }

    private fun confirmVaultDeleteSelected() {
        val items = adapter.selectedItems().filter { it.id == -2L }
        if (items.isEmpty()) return
        val one = items.size == 1
        ModernDialog.Builder(this)
            .setTitle(if (one) "Delete permanently?" else "Delete ${items.size} videos permanently?")
            .setMessage(if (one) items[0].title else "They will be removed from the private folder. This can't be undone.")
            .setPositiveButton("Delete") { _, _ ->
                var failed = 0
                items.forEach { item ->
                    val f = File(item.uri.path ?: "")
                    if (f.delete()) {
                        forgetOrigin(f)
                        vaultDurations.remove(f.path)
                    } else {
                        failed++
                    }
                }
                Toast.makeText(
                    this,
                    if (failed == 0) "Deleted" else "Couldn't delete $failed file(s)",
                    Toast.LENGTH_SHORT
                ).show()
                exitSelection()
                rebuild()
            }
            .setNegativeButton("Cancel")
            .show()
    }

    private fun showVaultItemActions(item: LibItem) {
        ActionSheet.show(
            this,
            listOf(
                ActionSheet.Action("Take out", R.drawable.ic_unlock, Ui.color(this, R.color.accent)) {
                    restoreFromVault(item)
                },
                ActionSheet.Action("Delete", R.drawable.ic_trash, 0xFFFF6B6B.toInt()) {
                    confirmVaultDelete(item)
                }
            ),
            onDismiss = { adapter.clearDim() }
        )
    }

    private fun confirmDeleteSelected() {
        val items = resolvedSelectedMedia()
        if (items.isEmpty()) return
        val n = items.size
        val folderCount = adapter.selectedFolderRows().size
        val title = when {
            folderCount > 0 && n > 1 -> "Delete $n files?"
            n == 1 -> "Delete file?"
            else -> "Delete $n files?"
        }
        val msg = when {
            folderCount > 0 -> "All files in the selected folder(s) will be permanently deleted."
            n == 1 -> items[0].title
            else -> "These files will be permanently deleted."
        }
        ModernDialog.Builder(this)
            .setTitle(title)
            .setMessage(msg)
            .setPositiveButton("Delete") { _, _ ->
                deleteSelected(items)
            }
            .setNegativeButton("Cancel")
            .show()
    }

    private fun deleteSelected(items: List<LibItem>) {
        if (items.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createDeleteRequest(contentResolver, items.map { it.uri })
                pendingAfterGrant = {
                    items.forEach { afterDelete(it, silent = true) }
                    exitSelection()
                    Toast.makeText(this, "Deleted ${items.size}", Toast.LENGTH_SHORT).show()
                    loadMedia()
                }
                grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (_: Exception) {
                Toast.makeText(this, "Couldn't delete", Toast.LENGTH_SHORT).show()
            }
        } else {
            var ok = 0
            items.forEach { item ->
                try {
                    if (contentResolver.delete(item.uri, null, null) > 0) {
                        afterDelete(item, silent = true)
                        ok++
                    }
                } catch (_: Exception) {
                }
            }
            exitSelection()
            Toast.makeText(this, if (ok > 0) "Deleted $ok" else "Couldn't delete", Toast.LENGTH_SHORT).show()
            if (ok > 0) loadMedia()
        }
    }

    private fun toggleFavSelected() {
        val items = resolvedSelectedMedia()
        if (items.isEmpty()) return
        val allFav = items.all { favs.contains(it.uri.toString()) }
        items.forEach { item ->
            val key = item.uri.toString()
            if (allFav) favs.remove(key) else favs.add(key)
        }
        prefs.edit().putStringSet("favs", HashSet(favs)).apply()
        Toast.makeText(
            this,
            if (allFav) "Removed from favorites" else "Added to favorites",
            Toast.LENGTH_SHORT
        ).show()
        exitSelection()
        rebuild()
    }

    private fun moveSelectedToVault() {
        val items = resolvedSelectedMedia().filter { !it.isAudio }
        if (items.isEmpty()) {
            Toast.makeText(this, "Only videos can be made private", Toast.LENGTH_SHORT).show()
            return
        }
        exitSelection()
        moveManyToVault(items)
    }

    private fun toggleFav(item: LibItem) {
        val key = item.uri.toString()
        val added = favs.add(key)
        if (!added) favs.remove(key)
        prefs.edit().putStringSet("favs", HashSet(favs)).apply()
        Toast.makeText(this, if (added) "Added to favorites" else "Removed from favorites", Toast.LENGTH_SHORT).show()
        rebuild()
    }

    private fun promptRename(item: LibItem) {
        val dot = item.title.lastIndexOf('.')
        val base = if (dot > 0) item.title.substring(0, dot) else item.title
        val ext = if (dot > 0) item.title.substring(dot) else ""
        ModernDialog.Builder(this)
            .setTitle("Rename")
            .setInputText(base)
            .setInput("Name", "Rename") { typed ->
                val clean = typed.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                if (clean.isEmpty()) {
                    Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
                } else {
                    val newName = if (ext.isNotEmpty() && clean.endsWith(ext, ignoreCase = true)) clean else clean + ext
                    if (newName != item.title) doRename(item, newName)
                }
            }
            .show()
    }

    private fun doRename(item: LibItem, newName: String) {
        exitSelection()
        runWithAccess(item.uri) {
            val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, newName) }
            val n = contentResolver.update(item.uri, cv, null, null)
            if (n > 0) {
                updateRecent(item.uri.toString(), newName)
                Toast.makeText(this, "Renamed", Toast.LENGTH_SHORT).show()
                loadMedia()
            } else {
                Toast.makeText(this, "Couldn't rename this file", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun promptRenameFolder(folder: Row.Folder) {
        if (folder.smart) {
            Toast.makeText(this, "Can't rename this list", Toast.LENGTH_SHORT).show()
            return
        }
        val current = folderName(folder.key)
        ModernDialog.Builder(this)
            .setTitle("Rename folder")
            .setInputText(current)
            .setInput("Folder name", "Rename") { typed ->
                val clean = typed.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                if (clean.isEmpty()) {
                    Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
                } else if (clean != current) {
                    doRenameFolder(folder, clean)
                }
            }
            .show()
    }

    private fun doRenameFolder(folder: Row.Folder, newName: String) {
        exitSelection()
        if (Build.VERSION.SDK_INT >= 30 && !hasAllFilesAccess()) {
            Toast.makeText(this, "Allow All files access to rename folders", Toast.LENGTH_LONG).show()
            // Force open settings even if we already asked once
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                allFilesLauncher.launch(intent)
            } catch (_: Exception) {
                try {
                    allFilesLauncher.launch(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (_: Exception) {
                }
            }
            return
        }
        val oldDir = File(folder.key)
        if (!oldDir.exists() || !oldDir.isDirectory) {
            Toast.makeText(this, "Couldn't find this folder", Toast.LENGTH_SHORT).show()
            return
        }
        val parent = oldDir.parentFile
        if (parent == null) {
            Toast.makeText(this, "Couldn't rename this folder", Toast.LENGTH_SHORT).show()
            return
        }
        val newDir = File(parent, newName)
        if (newDir.exists()) {
            Toast.makeText(this, "A folder with this name already exists", Toast.LENGTH_SHORT).show()
            return
        }
        io.execute {
            val ok = try {
                oldDir.renameTo(newDir)
            } catch (_: Exception) {
                false
            }
            ui.post {
                if (!ok) {
                    Toast.makeText(this, "Couldn't rename this folder", Toast.LENGTH_SHORT).show()
                    return@post
                }
                // Rescan so MediaStore picks up the new path
                try {
                    MediaScannerConnection.scanFile(
                        this,
                        arrayOf(newDir.absolutePath),
                        null
                    ) { _, _ -> ui.post { loadMedia() } }
                } catch (_: Exception) {
                }
                // Also migrate "seen_" badge prefs
                val oldSeen = prefs.getLong("seen_${folder.key}", 0L)
                if (oldSeen > 0L) {
                    prefs.edit()
                        .remove("seen_${folder.key}")
                        .putLong("seen_${newDir.absolutePath}", oldSeen)
                        .apply()
                }
                Toast.makeText(this, "Folder renamed", Toast.LENGTH_SHORT).show()
                // Fallback reload if scanner is slow
                ui.postDelayed({ loadMedia() }, 800)
            }
        }
    }

    private fun confirmDelete(item: LibItem) {
        if (Build.VERSION.SDK_INT >= 30) {
            // The system shows its own confirmation.
            pendingAfterGrant = { afterDelete(item) }
            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(item.uri))
            grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            return
        }
        ModernDialog.Builder(this)
            .setTitle("Delete file?")
            .setMessage(item.title)
            .setPositiveButton("Delete") { _, _ ->
                runWithAccess(item.uri) {
                    val n = contentResolver.delete(item.uri, null, null)
                    if (n > 0) afterDelete(item)
                    else Toast.makeText(this, "Couldn't delete this file", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel")
            .show()
    }

    private fun afterDelete(item: LibItem, silent: Boolean = false) {
        val key = item.uri.toString()
        if (favs.remove(key)) prefs.edit().putStringSet("favs", HashSet(favs)).apply()
        updateRecent(key, null)
        if (!silent) {
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
            loadMedia()
        }
    }

    /** Runs [action]; if Android asks for write access to [uri], gets it and runs [action] again. */
    private fun runWithAccess(uri: Uri, onDeny: (() -> Unit)? = null, action: () -> Unit) {
        try {
            action()
        } catch (e: SecurityException) {
            when {
                Build.VERSION.SDK_INT >= 30 -> {
                    val pi = MediaStore.createWriteRequest(contentResolver, listOf(uri))
                    pendingAfterGrant = { safely(action) }
                    pendingOnDeny = onDeny
                    grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                }
                Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException -> {
                    pendingAfterGrant = { safely(action) }
                    pendingOnDeny = onDeny
                    grantLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                }
                else -> {
                    pendingAfterGrant = { safely(action) }
                    pendingOnDeny = onDeny
                    writePermLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
            onDeny?.invoke()
        }
    }

    private fun safely(action: () -> Unit) {
        try {
            action()
        } catch (_: Exception) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------ private folder

    private fun vaultDir(): File = File(filesDir, "vault").also { it.mkdirs() }

    private fun isVaultUri(u: String): Boolean =
        u.startsWith("file:") && (Uri.parse(u).path ?: "").startsWith(vaultDir().path)

    private fun vaultItems(): List<LibItem> =
        (vaultDir().listFiles() ?: emptyArray())
            .filter { it.isFile && !it.name.endsWith(".part") }
            .map { f ->
                LibItem(
                    id = -2L,
                    uri = Uri.fromFile(f),
                    title = f.name,
                    durationMs = vaultDurations[f.path] ?: 0L,
                    size = f.length(),
                    dateAdded = f.lastModified() / 1000,
                    folderKey = f.parent ?: "",
                    isAudio = false
                )
            }

    private fun loadVaultDurations() {
        io.execute {
            var changed = false
            vaultDir().listFiles()?.forEach { f ->
                if (f.isFile && !f.name.endsWith(".part") && !vaultDurations.containsKey(f.path)) {
                    var d = 0L
                    try {
                        val r = MediaMetadataRetriever()
                        r.setDataSource(f.path)
                        d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        r.release()
                    } catch (_: Exception) {
                    }
                    vaultDurations[f.path] = d
                    changed = true
                }
            }
            if (changed) ui.post { if (!isFinishing && !isDestroyed && nav.kind == NavKind.PRIVATE) rebuild() }
        }
    }

    private fun hasVaultPassword() = prefs.contains("vault_hash")

    private fun hashPw(pw: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pw.toCharArray(), salt, 20000, 256)).encoded

    private fun savePw(pw: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("vault_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("vault_hash", Base64.encodeToString(hashPw(pw, salt), Base64.NO_WRAP))
            .apply()
    }

    private fun checkPw(pw: String): Boolean = try {
        val salt = Base64.decode(prefs.getString("vault_salt", "") ?: "", Base64.NO_WRAP)
        val want = Base64.decode(prefs.getString("vault_hash", "") ?: "", Base64.NO_WRAP)
        MessageDigest.isEqual(want, hashPw(pw, salt))
    } catch (_: Exception) {
        false
    }

    private fun askPassword(title: String, onOk: () -> Unit) {
        ModernDialog.Builder(this)
            .setTitle(title)
            .setInputPassword()
            .setInput("Password", "OK") { pw ->
                if (pw.isNotEmpty() && checkPw(pw)) onOk()
                else Toast.makeText(this, "Wrong password", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun createPassword(title: String = "Create password", onDone: () -> Unit) {
        ModernDialog.Builder(this)
            .setTitle(title)
            .setInputPassword()
            .setInput("At least 4 characters", "Next") { first ->
                if (first.length < 4) {
                    Toast.makeText(this, "Use at least 4 characters", Toast.LENGTH_SHORT).show()
                } else {
                    ModernDialog.Builder(this)
                        .setTitle("Confirm password")
                        .setInputPassword()
                        .setInput("Repeat password", "Save") { second ->
                            if (second == first) {
                                savePw(first)
                                Toast.makeText(this, "Password saved", Toast.LENGTH_SHORT).show()
                                onDone()
                            } else {
                                Toast.makeText(this, "Passwords don't match", Toast.LENGTH_SHORT).show()
                            }
                        }
                        .show()
                }
            }
            .show()
    }

    // ------------------------------------------------------------ private folder settings menu

    private val presetQuestions = arrayOf(
        "What is your pet's name?",
        "What city were you born in?",
        "What is your favorite food?",
        "What is your best friend's name?"
    )

    private fun hasSecurityQuestion() = prefs.contains("vault_qhash")

    private fun normAnswer(a: String) = a.trim().lowercase()

    private fun saveSecurityQa(question: String, answer: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit()
            .putString("vault_q", question)
            .putString("vault_qsalt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("vault_qhash", Base64.encodeToString(hashPw(normAnswer(answer), salt), Base64.NO_WRAP))
            .apply()
    }

    private fun checkSecurityAnswer(answer: String): Boolean = try {
        val salt = Base64.decode(prefs.getString("vault_qsalt", "") ?: "", Base64.NO_WRAP)
        val want = Base64.decode(prefs.getString("vault_qhash", "") ?: "", Base64.NO_WRAP)
        MessageDigest.isEqual(want, hashPw(normAnswer(answer), salt))
    } catch (_: Exception) {
        false
    }

    private fun showPrivateFolderMenu() {
        ModernDialog.Builder(this)
            .setTitle("Private Folder")
            .setItems(arrayOf("Reset password", "Reset security question", "Hide this option")) { _, which ->
                when (which) {
                    0 -> resetPassword()
                    1 -> resetSecurityQuestion()
                    2 -> hidePrivateSetting()
                }
            }
            .show()
    }

    private fun resetPassword() {
        if (!hasVaultPassword()) {
            createPassword { buildSettings() }
            return
        }
        val setNew = { createPassword("New password") { buildSettings() } }
        if (!hasSecurityQuestion()) {
            askPassword("Current password") { setNew() }
            return
        }
        ModernDialog.Builder(this)
            .setTitle("Reset password")
            .setItems(arrayOf("Enter current password", "Forgot password? Answer security question")) { _, which ->
                if (which == 0) askPassword("Current password") { setNew() }
                else askSecurityAnswer { setNew() }
            }
            .show()
    }

    private fun askSecurityAnswer(onOk: () -> Unit) {
        ModernDialog.Builder(this)
            .setTitle(prefs.getString("vault_q", "Security question") ?: "Security question")
            .setInputText("")
            .setInput("Your answer", "OK") { a ->
                if (a.isNotEmpty() && checkSecurityAnswer(a)) onOk()
                else Toast.makeText(this, "Wrong answer", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun resetSecurityQuestion() {
        if (!hasVaultPassword()) createPassword { chooseSecurityQuestion() }
        else askPassword("Current password") { chooseSecurityQuestion() }
    }

    private fun chooseSecurityQuestion() {
        ModernDialog.Builder(this)
            .setTitle("Choose a security question")
            .setItems(presetQuestions + "Write my own question") { _, which ->
                if (which < presetQuestions.size) {
                    askNewAnswer(presetQuestions[which])
                } else {
                    ModernDialog.Builder(this)
                        .setTitle("Your question")
                        .setInputText("")
                        .setInput("Type your question", "Next") { q ->
                            if (q.length < 3) Toast.makeText(this, "Question is too short", Toast.LENGTH_SHORT).show()
                            else askNewAnswer(q)
                        }
                        .show()
                }
            }
            .show()
    }

    private fun askNewAnswer(question: String) {
        ModernDialog.Builder(this)
            .setTitle(question)
            .setInputText("")
            .setInput("Your answer", "Save") { a ->
                if (a.isEmpty()) {
                    Toast.makeText(this, "Enter an answer", Toast.LENGTH_SHORT).show()
                } else {
                    saveSecurityQa(question, a)
                    Toast.makeText(this, "Security question saved", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun hidePrivateSetting() {
        prefs.edit().putBoolean("hide_private_setting", true).apply()
        buildSettings()
        Toast.makeText(
            this,
            "Hidden. Long-press the Private chip on the home screen to show it again.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun openVault() {
        if (!hasVaultPassword()) createPassword { enterVault() }
        else askPassword("Private folder") { enterVault() }
    }

    private fun enterVault() {
        vaultUnlocked = true
        go(Nav(NavKind.PRIVATE, "", "Private"))
        loadVaultDurations()
    }

    private fun moveToVault(item: LibItem) = moveManyToVault(listOf(item))

    /** Copies every video into the vault in one background pass, then asks once to remove the originals. */
    private fun moveManyToVault(items: List<LibItem>) {
        if (items.isEmpty()) return
        if (!hasVaultPassword()) {
            createPassword { moveManyToVault(items) }
            return
        }
        if (busy) {
            Toast.makeText(this, "Please wait…", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        Toast.makeText(
            this,
            if (items.size == 1) "Moving to private folder…" else "Moving ${items.size} videos…",
            Toast.LENGTH_LONG
        ).show()
        io.execute {
            val dir = vaultDir()
            val moved = ArrayList<Pair<LibItem, File>>()
            var failed = 0
            for (item in items) {
                var dest = File(dir, item.title)
                if (dest.exists()) dest = File(dir, "${System.currentTimeMillis()}_${item.title}")
                val part = File(dir, dest.name + ".part")
                val ok = try {
                    val pfd = contentResolver.openFileDescriptor(item.uri, "r") ?: throw java.io.IOException("no input")
                    pfd.use { p ->
                        java.io.FileInputStream(p.fileDescriptor).use { inp ->
                            FileOutputStream(part).use { out -> fastCopy(inp, out) }
                        }
                    }
                    val good = (item.size <= 0 || part.length() == item.size) && part.renameTo(dest)
                    if (good) {
                        prefs.edit()
                            .putString("vo_" + dest.name, item.folderKey)
                            .putString("vn_" + dest.name, item.title)
                            .apply()
                    }
                    good
                } catch (_: Exception) {
                    false
                }
                if (ok) moved.add(item to dest) else {
                    part.delete()
                    failed++
                }
            }
            ui.post {
                busy = false
                if (failed > 0) {
                    Toast.makeText(this, "Couldn't move $failed video(s)", Toast.LENGTH_SHORT).show()
                }
                if (moved.isNotEmpty()) deleteOriginalsAfterCopy(moved)
            }
        }
    }

    /** One system confirmation for all videos (Android 11+). */
    private fun deleteOriginalsAfterCopy(moved: List<Pair<LibItem, File>>) {
        if (Build.VERSION.SDK_INT < 30) {
            moved.forEach { (item, dest) -> deleteOriginalAfterCopy(item, dest) }
            return
        }
        val rollback: () -> Unit = {
            moved.forEach { (_, dest) ->
                dest.delete()
                forgetOrigin(dest)
            }
            Toast.makeText(this, "Cancelled. The videos stay in your library", Toast.LENGTH_SHORT).show()
        }
        val finish: () -> Unit = {
            var favChanged = false
            moved.forEach { (item, _) ->
                val key = item.uri.toString()
                if (favs.remove(key)) favChanged = true
                updateRecent(key, null)
            }
            if (favChanged) prefs.edit().putStringSet("favs", HashSet(favs)).apply()
            Toast.makeText(
                this,
                if (moved.size == 1) "Moved to private folder" else "${moved.size} videos moved to private folder",
                Toast.LENGTH_SHORT
            ).show()
            loadMedia()
        }
        pendingAfterGrant = finish
        pendingOnDeny = rollback
        val pi = MediaStore.createDeleteRequest(contentResolver, moved.map { it.first.uri })
        grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
    }

    private fun deleteOriginalAfterCopy(item: LibItem, dest: File) {
        val rollback: () -> Unit = {
            dest.delete()
            Toast.makeText(this, "Cancelled. The video stays in your library", Toast.LENGTH_SHORT).show()
        }
        val done: () -> Unit = {
            val key = item.uri.toString()
            if (favs.remove(key)) prefs.edit().putStringSet("favs", HashSet(favs)).apply()
            updateRecent(key, null)
            Toast.makeText(this, "Moved to private folder", Toast.LENGTH_SHORT).show()
            loadMedia()
        }
        if (Build.VERSION.SDK_INT >= 30) {
            pendingAfterGrant = done
            pendingOnDeny = rollback
            val pi = MediaStore.createDeleteRequest(contentResolver, listOf(item.uri))
            grantLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            runWithAccess(item.uri, rollback) {
                if (contentResolver.delete(item.uri, null, null) > 0) done() else rollback()
            }
        }
    }

    private fun confirmVaultDelete(item: LibItem) {
        ModernDialog.Builder(this)
            .setTitle("Delete permanently?")
            .setMessage(item.title)
            .setPositiveButton("Delete") { _, _ ->
                val f = File(item.uri.path ?: "")
                if (f.delete()) {
                    forgetOrigin(f)
                    vaultDurations.remove(f.path)
                    Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Couldn't delete this file", Toast.LENGTH_SHORT).show()
                }
                rebuild()
            }
            .setNegativeButton("Cancel")
            .show()
    }

    private fun restoreFromVault(item: LibItem) = restoreManyFromVault(listOf(item))

    /** Takes every video out in one background pass and refreshes the library once. */
    private fun restoreManyFromVault(items: List<LibItem>) {
        if (items.isEmpty()) return
        if (Build.VERSION.SDK_INT < 29 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            pendingAfterGrant = { restoreManyFromVault(items) }
            writePermLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        if (busy) {
            Toast.makeText(this, "Please wait…", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        Toast.makeText(
            this,
            if (items.size == 1) "Taking out…" else "Taking out ${items.size} videos…",
            Toast.LENGTH_LONG
        ).show()
        io.execute {
            var ok = 0
            val removed = ArrayList<String>()
            for (item in items) {
                val src = File(item.uri.path ?: "")
                try {
                    copyToLibrary(src)
                    src.delete()
                    forgetOrigin(src)
                    removed.add(src.path)
                    ok++
                } catch (_: Exception) {
                }
            }
            ui.post {
                busy = false
                removed.forEach { vaultDurations.remove(it) }
                val msg = when {
                    ok == items.size -> if (ok == 1) "Moved back to your library" else "$ok videos moved back to your library"
                    ok == 0 -> "Couldn't take it out"
                    else -> "$ok moved back, ${items.size - ok} failed"
                }
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                loadMedia()
            }
        }
    }

    private fun fastCopy(inp: java.io.FileInputStream, out: FileOutputStream) {
        val inCh = inp.channel
        val outCh = out.channel
        val total = inCh.size()
        var pos = 0L
        try {
            while (pos < total) {
                val n = inCh.transferTo(pos, minOf(8L shl 20, total - pos), outCh)
                if (n <= 0L) break
                pos += n
            }
        } catch (_: java.io.IOException) {
        }
        if (pos < total) {
            inCh.position(pos)
            outCh.position(pos)
            val buf = java.nio.ByteBuffer.allocateDirect(1 shl 20)
            while (true) {
                buf.clear()
                if (inCh.read(buf) <= 0) break
                buf.flip()
                while (buf.hasRemaining()) outCh.write(buf)
            }
        }
        out.fd.sync()
    }

    private fun originFolder(src: File): String? = prefs.getString("vo_" + src.name, null)

    private fun forgetOrigin(src: File) {
        prefs.edit().remove("vo_" + src.name).remove("vn_" + src.name).apply()
    }

    @Suppress("DEPRECATION")
    private fun copyToLibrary(src: File) {
        val origin = originFolder(src)
        val name = prefs.getString("vn_" + src.name, null) ?: src.name
        if (Build.VERSION.SDK_INT >= 29) {
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(src.extension.lowercase()) ?: "video/mp4"
            val root = Environment.getExternalStorageDirectory().path + "/"
            val rel = if (origin != null && origin.startsWith(root))
                origin.removePrefix(root).trim('/') + "/" else null
            fun insert(path: String): Uri? {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, path)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            }
            val uri = (if (rel != null) try { insert(rel) } catch (_: Exception) { null } else null)
                ?: insert("Movies/Restored")
                ?: throw java.io.IOException("insert failed")
            try {
                val pfd = contentResolver.openFileDescriptor(uri, "w") ?: throw java.io.IOException("no output")
                pfd.use { p ->
                    FileOutputStream(p.fileDescriptor).use { o ->
                        src.inputStream().use { fastCopy(it as java.io.FileInputStream, o) }
                    }
                }
                val values = ContentValues()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            } catch (e: Exception) {
                contentResolver.delete(uri, null, null)
                throw e
            }
        } else {
            val dir = if (origin != null) File(origin)
                else File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Restored")
            dir.mkdirs()
            var dest = File(dir, name)
            if (dest.exists()) dest = File(dir, "${System.currentTimeMillis()}_$name")
            src.inputStream().use { i -> FileOutputStream(dest).use { o -> fastCopy(i as java.io.FileInputStream, o) } }
            MediaScannerConnection.scanFile(this, arrayOf(dest.path), null, null)
        }
    }

    // ------------------------------------------------------------ playback

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) return it.getString(0)
                }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    private fun playFromCurrent(pos: Int) {
        if (pos in currentMedia.indices) startPlayer(currentMedia, pos)
    }

    private fun startPlayer(list: List<LibItem>, pos: Int) {
        var items = list
        var index = pos
        if (items.size > 500) {
            val from = maxOf(0, pos - 250)
            items = items.subList(from, minOf(items.size, from + 500))
            index = pos - from
        }
        startPlayerRaw(items.map { it.uri.toString() }, items.map { it.title }, index)
    }

    private fun startPlayerRaw(uris: List<String>, titles: List<String>, index: Int) {
        if (uris.isEmpty()) return
        launchingPlayer = true
        uris.getOrNull(index)?.let { if (!isVaultUri(it)) recordRecent(it, titles.getOrNull(index) ?: it) }
        val i = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra(PlayerActivity.EXTRA_URIS, ArrayList(uris))
            putStringArrayListExtra(PlayerActivity.EXTRA_TITLES, ArrayList(titles))
            putExtra(PlayerActivity.EXTRA_INDEX, index)
        }
        startActivity(i)
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}
