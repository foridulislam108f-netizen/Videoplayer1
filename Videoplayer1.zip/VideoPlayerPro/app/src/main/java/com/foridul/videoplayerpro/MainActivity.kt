package com.foridul.videoplayerpro

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.foridul.videoplayerpro.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var folderAdapter: FolderAdapter
    private lateinit var videoAdapter: VideoAdapter
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())

    private var showingFolders = true
    private var currentFolder: FolderItem? = null
    private var allFolders: List<FolderItem> = emptyList()
    private var sortByName = true

    private val videoPermission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadFolders() else showEmpty("Allow video access to list your videos.\nTap here to try again.", true)
        }

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            uris.forEach {
                try {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            startPlayer(uris.map { it.toString() }, uris.map { displayName(it) }, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        folderAdapter = FolderAdapter(
            onFolderClick = { folder -> openFolder(folder) },
            onMoreClick = { folder, view -> showFolderMenu(folder, view) }
        )
        videoAdapter = VideoAdapter { list, pos ->
            startPlayer(list.map { it.uri.toString() }, list.map { it.title }, pos)
        }

        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = folderAdapter

        // Tabs
        b.tabPlaylists.setOnClickListener { selectTab(0) }
        b.tabRecent.setOnClickListener { selectTab(1) }
        b.tabStream.setOnClickListener {
            selectTab(2)
            showStreamDialog()
        }

        // All folders dropdown
        b.btnAllFolders.setOnClickListener { showFoldersDropdown() }

        // Sort
        b.btnSort.setOnClickListener {
            sortByName = !sortByName
            if (showingFolders) {
                submitFolders(allFolders)
            }
            Toast.makeText(this, if (sortByName) "Sorted by name" else "Sorted by count", Toast.LENGTH_SHORT).show()
        }

        // Bottom nav
        b.navVideo.setOnClickListener {
            // already on video
        }
        b.navMusic.setOnClickListener {
            Toast.makeText(this, "Music player coming soon", Toast.LENGTH_SHORT).show()
        }
        b.navSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        b.tvEmpty.setOnClickListener { ensurePermissionAndLoad() }
    }

    override fun onResume() {
        super.onResume()
        ensurePermissionAndLoad()
    }

    private fun selectTab(index: Int) {
        val selectedBg = R.drawable.bg_tab_selected
        val unselectedBg = R.drawable.bg_tab_unselected
        b.tabPlaylists.setBackgroundResource(if (index == 0) selectedBg else unselectedBg)
        b.tabRecent.setBackgroundResource(if (index == 1) selectedBg else unselectedBg)
        b.tabStream.setBackgroundResource(if (index == 2) selectedBg else unselectedBg)
    }

    private fun ensurePermissionAndLoad() {
        if (ContextCompat.checkSelfPermission(this, videoPermission) == PackageManager.PERMISSION_GRANTED) {
            loadFolders()
        } else {
            permLauncher.launch(videoPermission)
        }
    }

    private fun loadFolders() {
        io.execute {
            val folders = queryFolders()
            ui.post {
                if (isFinishing || isDestroyed) return@post
                allFolders = folders
                if (showingFolders) {
                    submitFolders(folders)
                }
            }
        }
    }

    private fun queryFolders(): List<FolderItem> {
        val map = LinkedHashMap<String, MutableList<VideoItem>>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_ID
        )
        try {
            contentResolver.query(
                collection, projection, null, null,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val bucketCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val bucket = c.getString(bucketCol) ?: "Other"
                    val item = VideoItem(
                        id = id,
                        uri = ContentUris.withAppendedId(collection, id),
                        title = c.getString(nameCol) ?: "Video $id",
                        durationMs = c.getLong(durCol),
                        size = c.getLong(sizeCol)
                    )
                    map.getOrPut(bucket) { mutableListOf() }.add(item)
                }
            }
        } catch (_: Exception) {
        }
        return map.map { (name, videos) ->
            FolderItem(name = name, path = name, videoCount = videos.size, videos = videos)
        }
    }

    private fun submitFolders(folders: List<FolderItem>) {
        val sorted = if (sortByName) {
            folders.sortedBy { it.name.lowercase() }
        } else {
            folders.sortedByDescending { it.videoCount }
        }
        folderAdapter.submit(sorted)
        b.recycler.adapter = folderAdapter
        showingFolders = true
        currentFolder = null
        b.tvAllFolders.text = "All folders"
        updateEmptyState()
    }

    private fun openFolder(folder: FolderItem) {
        currentFolder = folder
        showingFolders = false
        videoAdapter.submit(folder.videos)
        b.recycler.adapter = videoAdapter
        b.tvAllFolders.text = folder.name
        updateEmptyState()
    }

    private fun showFoldersDropdown() {
        if (!showingFolders && currentFolder != null) {
            // Go back to all folders
            submitFolders(allFolders)
            return
        }
        val popup = PopupMenu(this, b.btnAllFolders, Gravity.START)
        popup.menu.add(0, 0, 0, "All folders")
        allFolders.sortedBy { it.name.lowercase() }.forEachIndexed { i, f ->
            popup.menu.add(0, i + 1, i + 1, "${f.name} (${f.videoCount})")
        }
        popup.setOnMenuItemClickListener { item ->
            if (item.itemId == 0) {
                submitFolders(allFolders)
            } else {
                val folder = allFolders.sortedBy { it.name.lowercase() }.getOrNull(item.itemId - 1)
                if (folder != null) openFolder(folder)
            }
            true
        }
        popup.show()
    }

    private fun showFolderMenu(folder: FolderItem, anchor: View) {
        val popup = PopupMenu(this, anchor)
        popup.menu.add("Play all")
        popup.menu.add("Open folder")
        popup.setOnMenuItemClickListener {
            when (it.title) {
                "Play all" -> {
                    if (folder.videos.isNotEmpty()) {
                        startPlayer(
                            folder.videos.map { v -> v.uri.toString() },
                            folder.videos.map { v -> v.title },
                            0
                        )
                    }
                }
                "Open folder" -> openFolder(folder)
            }
            true
        }
        popup.show()
    }

    private fun updateEmptyState() {
        val count = if (showingFolders) folderAdapter.count() else videoAdapter.count()
        if (count == 0) {
            showEmpty(
                if (showingFolders) "No video folders found.\nGrant storage permission or open files from Settings."
                else "No videos in this folder.",
                showingFolders
            )
        } else {
            b.tvEmpty.visibility = View.GONE
        }
    }

    private fun showEmpty(text: String, clickable: Boolean) {
        b.tvEmpty.text = text
        b.tvEmpty.isClickable = clickable
        b.tvEmpty.visibility = View.VISIBLE
    }

    private fun showStreamDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.m3u8"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFA6A6B0.toInt())
            setPadding(48, 36, 48, 36)
        }
        AlertDialog.Builder(this)
            .setTitle("Network stream")
            .setView(input)
            .setPositiveButton("Play") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isEmpty()) {
                    Toast.makeText(this, "Enter a URL", Toast.LENGTH_SHORT).show()
                } else {
                    startPlayer(listOf(url), listOf(Uri.parse(url).lastPathSegment ?: url), 0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) return it.getString(0)
                }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    private fun startPlayer(uris: List<String>, titles: List<String>, index: Int) {
        val i = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra(PlayerActivity.EXTRA_URIS, ArrayList(uris))
            putStringArrayListExtra(PlayerActivity.EXTRA_TITLES, ArrayList(titles))
            putExtra(PlayerActivity.EXTRA_INDEX, index)
        }
        startActivity(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!showingFolders) {
            submitFolders(allFolders)
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }
}
