package com.foridul.videoplayerpro

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.Typeface
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat

/** Small helpers shared by the home page and the player. */
object Ui {
    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun color(ctx: Context, res: Int): Int = ContextCompat.getColor(ctx, res)

    fun rounded(color: Int, radiusDp: Float, ctx: Context, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp * ctx.resources.displayMetrics.density
            if (strokeColor != 0) setStroke(dp(ctx, 1), strokeColor)
        }

    fun ripple(ctx: Context, base: Int = Color.TRANSPARENT): RippleDrawable =
        RippleDrawable(
            ColorStateList.valueOf(0x22FFFFFF),
            ColorDrawable(base),
            ColorDrawable(Color.WHITE)
        )

    fun text(ctx: Context, s: CharSequence, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(ctx).apply {
            text = s
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun icon(ctx: Context, res: Int, sizeDp: Int, tint: Int): ImageView =
        ImageView(ctx).apply {
            setImageResource(res)
            imageTintList = ColorStateList.valueOf(tint)
            layoutParams = LinearLayout.LayoutParams(dp(ctx, sizeDp), dp(ctx, sizeDp))
        }
}

/** ScrollView that never grows taller than [maxHeightPx]. */
class MaxHeightScrollView(ctx: Context, private val maxHeightPx: Int) : ScrollView(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = MeasureSpec.makeMeasureSpec(maxHeightPx, MeasureSpec.AT_MOST)
        super.onMeasure(widthMeasureSpec, h)
    }
}

/**
 * Modern rounded dialog. API mirrors the parts of AlertDialog.Builder that the app uses
 * (setTitle / setMessage / setItems / setSingleChoiceItems / setPositiveButton).
 */
class ModernDialog private constructor(private val dialog: Dialog) {

    fun setOnDismissListener(l: () -> Unit) {
        dialog.setOnDismissListener { l() }
    }

    fun show() = dialog.show()

    class Builder(private val ctx: Context) {
        private var title: CharSequence? = null
        private var message: CharSequence? = null
        private var items: Array<String>? = null
        private var checked = -1
        private var listener: ((DialogInterface, Int) -> Unit)? = null
        private var posText: String? = null
        private var posListener: ((DialogInterface, Int) -> Unit)? = null
        private var negText: String? = null
        private var inputHint: String? = null
        private var inputSubmit: ((String) -> Unit)? = null

        fun setTitle(t: CharSequence) = apply { title = t }
        fun setMessage(m: CharSequence) = apply { message = m }

        fun setItems(items: Array<String>, l: (DialogInterface, Int) -> Unit) = apply {
            this.items = items
            this.checked = -1
            this.listener = l
        }

        fun setSingleChoiceItems(items: Array<String>, checked: Int, l: (DialogInterface, Int) -> Unit) = apply {
            this.items = items
            this.checked = checked
            this.listener = l
        }

        fun setPositiveButton(text: String, l: ((DialogInterface, Int) -> Unit)?) = apply {
            posText = text
            posListener = l
        }

        fun setNegativeButton(text: String) = apply { negText = text }

        fun setInput(hint: String, positive: String, onSubmit: (String) -> Unit) = apply {
            inputHint = hint
            posText = positive
            negText = "Cancel"
            inputSubmit = onSubmit
        }

        fun show(): ModernDialog = create().also { it.show() }

        fun create(): ModernDialog {
            val accent = Ui.color(ctx, R.color.accent)
            val primary = Ui.color(ctx, R.color.text_primary)
            val secondary = Ui.color(ctx, R.color.text_secondary)
            val dm = ctx.resources.displayMetrics

            val d = Dialog(ctx)
            d.requestWindowFeature(Window.FEATURE_NO_TITLE)

            val root = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                background = Ui.rounded(Ui.color(ctx, R.color.surface_high), 24f, ctx, Ui.color(ctx, R.color.outline))
                setPadding(0, Ui.dp(ctx, 10), 0, Ui.dp(ctx, 8))
            }

            title?.let {
                root.addView(
                    Ui.text(ctx, it, 18f, primary, true).apply {
                        setPadding(Ui.dp(ctx, 24), Ui.dp(ctx, 12), Ui.dp(ctx, 24), Ui.dp(ctx, 10))
                    }
                )
            }

            message?.let { m ->
                val sv = MaxHeightScrollView(ctx, (dm.heightPixels * 0.55f).toInt())
                sv.addView(
                    Ui.text(ctx, m, 14f, secondary).apply {
                        setLineSpacing(0f, 1.15f)
                        setTextIsSelectable(true)
                        setPadding(Ui.dp(ctx, 24), Ui.dp(ctx, 4), Ui.dp(ctx, 24), Ui.dp(ctx, 8))
                    }
                )
                root.addView(sv)
            }

            var input: EditText? = null
            inputHint?.let { hint ->
                val et = EditText(ctx).apply {
                    this.hint = hint
                    setHintTextColor(secondary)
                    setTextColor(primary)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    setSingleLine(true)
                    inputType = InputType.TYPE_TEXT_VARIATION_URI
                    background = Ui.rounded(Ui.color(ctx, R.color.chip), 14f, ctx)
                    setPadding(Ui.dp(ctx, 16), Ui.dp(ctx, 12), Ui.dp(ctx, 16), Ui.dp(ctx, 12))
                }
                input = et
                root.addView(
                    et,
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                        .apply {
                            setMargins(Ui.dp(ctx, 20), Ui.dp(ctx, 4), Ui.dp(ctx, 20), Ui.dp(ctx, 8))
                        }
                )
            }

            items?.let { arr ->
                val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
                arr.forEachIndexed { idx, label ->
                    val selected = idx == checked
                    val row = LinearLayout(ctx).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        minimumHeight = Ui.dp(ctx, 52)
                        setPadding(Ui.dp(ctx, 24), 0, Ui.dp(ctx, 20), 0)
                        background = Ui.ripple(ctx, if (selected) 0x1F6C8CFF else Color.TRANSPARENT)
                        isClickable = true
                        isFocusable = true
                    }
                    row.addView(
                        Ui.text(ctx, label, 16f, if (selected) accent else primary, selected).apply {
                            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                        }
                    )
                    if (selected) row.addView(Ui.icon(ctx, R.drawable.ic_check, 22, accent))
                    row.setOnClickListener {
                        d.dismiss()
                        listener?.invoke(d, idx)
                    }
                    list.addView(row)
                }
                val sv = MaxHeightScrollView(ctx, (dm.heightPixels * 0.62f).toInt())
                sv.isVerticalScrollBarEnabled = false
                sv.addView(list)
                root.addView(sv)
            }

            if (posText != null || negText != null) {
                val bar = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.END
                    setPadding(Ui.dp(ctx, 12), Ui.dp(ctx, 6), Ui.dp(ctx, 12), Ui.dp(ctx, 4))
                }
                fun btn(label: String, color: Int, bold: Boolean, onClick: () -> Unit) {
                    bar.addView(
                        Ui.text(ctx, label, 15f, color, bold).apply {
                            gravity = Gravity.CENTER
                            setPadding(Ui.dp(ctx, 18), Ui.dp(ctx, 10), Ui.dp(ctx, 18), Ui.dp(ctx, 10))
                            background = Ui.ripple(ctx)
                            setOnClickListener { onClick() }
                        }
                    )
                }
                negText?.let { btn(it, secondary, false) { d.dismiss() } }
                posText?.let {
                    btn(it, accent, true) {
                        val submit = inputSubmit
                        d.dismiss()
                        if (submit != null) submit(input?.text?.toString().orEmpty().trim())
                        else posListener?.invoke(d, 0)
                    }
                }
                root.addView(bar)
            }

            d.setContentView(root)
            d.window?.apply {
                setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                val w = minOf(Ui.dp(ctx, 340), dm.widthPixels - Ui.dp(ctx, 40))
                setLayout(w, WindowManager.LayoutParams.WRAP_CONTENT)
                setDimAmount(0.6f)
                attributes = attributes.apply { windowAnimations = R.style.ModernDialogAnim }
                if (inputHint != null) {
                    setSoftInputMode(
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                            WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                    )
                }
            }
            return ModernDialog(d)
        }
    }
}

/** Modern anchored drop-down menu. */
object ModernPopup {
    class Item(val label: String, val icon: Int = 0, val checked: Boolean = false)

    fun show(anchor: View, items: List<Item>, alignEnd: Boolean = false, onPick: (Int) -> Unit) {
        val ctx = anchor.context
        val primary = Ui.color(ctx, R.color.text_primary)
        val secondary = Ui.color(ctx, R.color.text_secondary)
        val accent = Ui.color(ctx, R.color.accent)

        val content = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, Ui.dp(ctx, 6), 0, Ui.dp(ctx, 6))
            minimumWidth = Ui.dp(ctx, 210)
        }
        val popup = PopupWindow(content, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(
            Ui.rounded(Ui.color(ctx, R.color.surface_high), 16f, ctx, Ui.color(ctx, R.color.outline))
        )
        popup.elevation = Ui.dp(ctx, 12).toFloat()
        popup.animationStyle = R.style.ModernPopupAnim
        popup.isOutsideTouchable = true

        items.forEachIndexed { idx, item ->
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = Ui.dp(ctx, 48)
                setPadding(Ui.dp(ctx, 16), 0, Ui.dp(ctx, 16), 0)
                background = Ui.ripple(ctx)
                isClickable = true
                isFocusable = true
            }
            if (item.icon != 0) {
                row.addView(
                    Ui.icon(ctx, item.icon, 20, if (item.checked) accent else secondary).apply {
                        (layoutParams as LinearLayout.LayoutParams).marginEnd = Ui.dp(ctx, 14)
                    }
                )
            }
            row.addView(
                Ui.text(ctx, item.label, 15.5f, if (item.checked) accent else primary, item.checked).apply {
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                }
            )
            if (item.checked) {
                row.addView(
                    Ui.icon(ctx, R.drawable.ic_check, 20, accent).apply {
                        (layoutParams as LinearLayout.LayoutParams).marginStart = Ui.dp(ctx, 12)
                    }
                )
            }
            row.setOnClickListener {
                popup.dismiss()
                onPick(idx)
            }
            content.addView(row)
        }
        popup.showAsDropDown(anchor, 0, 0, if (alignEnd) Gravity.END else Gravity.START)
    }
}
