package com.foridul.videoplayerpro

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultAllocator
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.mp4.Mp4Extractor
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory
import androidx.media3.extractor.ts.TsExtractor
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import com.foridul.videoplayerpro.databinding.ActivityPlayerBinding
import io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URIS = "uris"
        const val EXTRA_TITLES = "titles"
        const val EXTRA_INDEX = "index"

        private const val PREFS = "player_prefs"
        private const val KEY_SUB_SCALE = "sub_scale"
        private const val KEY_AUTO_ORIENT = "auto_orient"
        private const val HIDE_DELAY = 4000L
        private const val LOCK_HIDE_DELAY = 3000L
        private const val SEEK_STEP = 10_000L
    }

    private enum class Gesture { NONE, SEEK, BRIGHTNESS, VOLUME, ZOOM }

    private lateinit var b: ActivityPlayerBinding
    private lateinit var prefs: SharedPreferences
    private lateinit var audioManager: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var player: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    private var loudness: LoudnessEnhancer? = null

    // Playlist
    private var uris: List<Uri> = emptyList()
    private var titles: List<String> = emptyList()
    private var index = 0
    private val extSubs = mutableMapOf<Int, Pair<Uri, String>>()

    // State kept across stop/start
    private var pendingStartPos = -1L
    private var startPlaying = true
    private var currentSpeed = 1f
    private var boostMb = 0
    private var repeatMode = Player.REPEAT_MODE_OFF

    // UI state
    private var locked = false
    private var controlsVisible = true
    private var isScrubbing = false
    private var inPip = false
    private var resizeIndex = 0
    private var userScale = 1f
    private var subScale = 1f
    private var autoOrient = false
    private var orientationAuto = true
    private var orientationApplied = false

    // Gesture state
    private var gesture = Gesture.NONE
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var brightStart = 0.5f
    private var volStart = 0.5f
    private var boostActive = false
    private var speedBeforeBoost = 1f
    private var seekAccum = 0L

    private var sleepRunnable: Runnable? = null

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Crop (fill screen)", "Fit width", "Fit height")
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f, 4f)

    private val hideRunnable = Runnable { if (!isScrubbing) hideControls() }
    private val lockHideRunnable = Runnable { if (locked) fade(b.btnLock, false) }
    private val hideInfoRunnable = Runnable { b.tvInfo.visibility = View.GONE }
    private val resetSeekAccum = Runnable { seekAccum = 0L }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 250)
        }
    }

    private val pickSubtitle =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadExternalSubtitle(uri)
        }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(b.root)

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        subScale = prefs.getFloat(KEY_SUB_SCALE, 1f)
        autoOrient = prefs.getBoolean(KEY_AUTO_ORIENT, false)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setupWindow()
        setupSubtitleView()
        setupButtons()
        setupSeekBar()
        setupGestures()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (locked) {
                    Toast.makeText(this@PlayerActivity, "Screen is locked", Toast.LENGTH_SHORT).show()
                    showLockButtonTemporarily()
                } else {
                    finish()
                }
            }
        })

        parseIntent(intent)
        if (uris.isEmpty()) {
            Toast.makeText(this, "No video to play", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val wasRunning = player != null
        if (wasRunning) releasePlayer()
        extSubs.clear()
        pendingStartPos = -1L
        startPlaying = true
        parseIntent(intent)
        if (wasRunning && uris.isNotEmpty()) initPlayer()
    }

    override fun onStart() {
        super.onStart()
        if (player == null && uris.isNotEmpty()) initPlayer()
        handler.post(progressRunnable)
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(progressRunnable)
        if (isInPictureInPictureMode) {
            // PiP window was closed with the X button
            releasePlayer()
            finishAndRemoveTask()
            return
        }
        releasePlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Android 12+ uses setAutoEnterEnabled; older versions enter here.
        if (Build.VERSION.SDK_INT < 31 && player?.isPlaying == true && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(inPipMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(inPipMode, newConfig)
        inPip = inPipMode
        if (inPipMode) {
            b.controlsLayer.visibility = View.GONE
            b.btnLock.visibility = View.GONE
            b.tvInfo.visibility = View.GONE
            b.playerView.scaleX = 1f
            b.playerView.scaleY = 1f
        } else {
            b.playerView.scaleX = userScale
            b.playerView.scaleY = userScale
            if (locked) {
                showLockButtonTemporarily()
            } else {
                showControls()
            }
        }
    }

    // ---------------------------------------------------------------- setup

    private fun setupWindow() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { _, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            b.controlsContent.setPadding(i.left, i.top, i.right, i.bottom)
            b.btnLock.translationX = -i.right.toFloat()
            insets
        }
        hideSystemBars()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, b.root)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun setupSubtitleView() {
        b.playerView.subtitleView?.apply {
            setStyle(
                CaptionStyleCompat(
                    Color.WHITE, Color.TRANSPARENT, Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null
                )
            )
            setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * subScale)
            setBottomPaddingFraction(0.08f)
        }
    }

    private fun setupButtons() {
        b.btnBack.setOnClickListener { finish() }
        b.btnPlayPause.setOnClickListener { togglePlay(); scheduleHide() }
        b.btnNext.setOnClickListener { player?.seekToNextMediaItem(); scheduleHide() }
        b.btnPrev.setOnClickListener {
            val p = player ?: return@setOnClickListener
            if (p.currentPosition > 3000 || !p.hasPreviousMediaItem()) p.seekTo(0)
            else p.seekToPreviousMediaItem()
            scheduleHide()
        }
        b.btnLock.setOnClickListener { toggleLock() }
        b.btnPip.setOnClickListener { enterPip() }
        b.btnAspect.setOnClickListener { cycleAspect(); scheduleHide() }
        b.btnSpeed.setOnClickListener { showSpeedDialog() }
        b.btnRotate.setOnClickListener { rotateScreen(); scheduleHide() }
        b.btnRotate.setOnLongClickListener {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            orientationAuto = true
            showInfo("Auto rotate")
            true
        }
        b.btnSubtitle.setOnClickListener { showSubtitleDialog() }
        b.btnAudio.setOnClickListener { showTrackDialog(C.TRACK_TYPE_AUDIO, "Audio track") }
        b.btnMore.setOnClickListener { showMoreDialog() }
    }

    private fun setupSeekBar() {
        b.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                isScrubbing = true
                handler.removeCallbacks(hideRunnable)
            }

            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val dur = (player?.duration ?: 0L).coerceAtLeast(0L)
                b.tvTime.text = "${formatTime(progress.toLong())} / ${formatTime(dur)}"
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                player?.seekTo(seekBar.progress.toLong())
                isScrubbing = false
                scheduleHide()
            }
        })
    }

    private fun setupGestures() {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                if (locked || inPip) return false
                gesture = Gesture.ZOOM
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                userScale = (userScale * detector.scaleFactor).coerceIn(1f, 4f)
                b.playerView.scaleX = userScale
                b.playerView.scaleY = userScale
                showInfo("Zoom ${(userScale * 100).roundToInt()}%")
                return true
            }
        })

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) showLockButtonTemporarily()
                else if (controlsVisible) hideControls() else showControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked || inPip) return true
                val w = b.gestureView.width
                when {
                    e.x < w * 0.35f -> seekBy(-SEEK_STEP)
                    e.x > w * 0.65f -> seekBy(SEEK_STEP)
                    else -> togglePlay()
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (locked || inPip || gesture != Gesture.NONE) return
                val p = player ?: return
                if (p.isPlaying) {
                    boostActive = true
                    speedBeforeBoost = p.playbackParameters.speed
                    p.setPlaybackSpeed(2f)
                    showInfo("2× speed", persistent = true)
                }
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || inPip || e1 == null || boostActive) return false
                val p = player ?: return false
                val w = b.gestureView.width.toFloat()
                val h = b.gestureView.height.toFloat()
                if (gesture == Gesture.ZOOM) return false

                if (gesture == Gesture.NONE) {
                    val ax = abs(e2.x - e1.x)
                    val ay = abs(e2.y - e1.y)
                    if (ax < touchSlop && ay < touchSlop) return false
                    when {
                        ax > ay -> {
                            if (p.duration == C.TIME_UNSET) return false
                            gesture = Gesture.SEEK
                            seekStartPos = p.currentPosition
                            seekTarget = seekStartPos
                        }
                        e1.x < w / 2f -> {
                            gesture = Gesture.BRIGHTNESS
                            brightStart = currentBrightness()
                        }
                        else -> {
                            gesture = Gesture.VOLUME
                            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            volStart = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
                        }
                    }
                }

                when (gesture) {
                    Gesture.SEEK -> {
                        val dur = p.duration.coerceAtLeast(0L)
                        val delta = ((e2.x - e1.x) / w * 120_000f).toLong()
                        seekTarget = (seekStartPos + delta).coerceIn(0L, dur)
                        val diff = seekTarget - seekStartPos
                        val sign = if (diff >= 0) "+" else "−"
                        showInfo("$sign${formatTime(abs(diff))}   [${formatTime(seekTarget)}]", persistent = true)
                    }
                    Gesture.BRIGHTNESS -> {
                        val level = (brightStart + (e1.y - e2.y) / h * 1.2f).coerceIn(0.01f, 1f)
                        val lp = window.attributes
                        lp.screenBrightness = level
                        window.attributes = lp
                        showInfo("☀ Brightness ${(level * 100).roundToInt()}%", persistent = true)
                    }
                    Gesture.VOLUME -> {
                        val level = (volStart + (e1.y - e2.y) / h * 1.2f).coerceIn(0f, 1f)
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audioManager.setStreamVolume(
                            AudioManager.STREAM_MUSIC, (level * max).roundToInt(), 0
                        )
                        showInfo("🔊 Volume ${(level * 100).roundToInt()}%", persistent = true)
                    }
                    else -> {}
                }
                return true
            }
        })

        b.gestureView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> gesture = Gesture.NONE
            }
            scale.onTouchEvent(ev)
            if (ev.pointerCount == 1 && gesture != Gesture.ZOOM) detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                endGesture()
            }
            true
        }
    }

    private fun endGesture() {
        if (gesture == Gesture.SEEK) player?.seekTo(seekTarget)
        if (boostActive) {
            boostActive = false
            player?.setPlaybackSpeed(speedBeforeBoost)
        }
        if (gesture != Gesture.NONE || b.tvInfo.visibility == View.VISIBLE) {
            handler.removeCallbacks(hideInfoRunnable)
            handler.postDelayed(hideInfoRunnable, 700)
        }
        gesture = Gesture.NONE
    }

    // ---------------------------------------------------------------- intent / items

    private fun parseIntent(i: Intent) {
        val list = i.getStringArrayListExtra(EXTRA_URIS)
        if (!list.isNullOrEmpty()) {
            uris = list.map { Uri.parse(it) }
            val t = i.getStringArrayListExtra(EXTRA_TITLES)
            titles = uris.mapIndexed { n, u -> t?.getOrNull(n) ?: resolveName(u) }
            index = i.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, uris.lastIndex)
        } else if (i.data != null) {
            val u = i.data!!
            uris = listOf(u)
            titles = listOf(resolveName(u))
            index = 0
        } else {
            uris = emptyList()
            titles = emptyList()
        }
    }

    private fun resolveName(u: Uri): String {
        if (u.scheme == "content") {
            try {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) {
                        val n = it.getString(0)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            } catch (_: Exception) {
            }
        }
        return u.lastPathSegment ?: u.toString()
    }

    private fun subtitleMime(name: String): String {
        val n = name.lowercase(Locale.ROOT)
        return when {
            n.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            n.endsWith(".ass") || n.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            n.endsWith(".ttml") || n.endsWith(".xml") || n.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    private fun buildItem(i: Int): MediaItem {
        val mb = MediaItem.Builder()
            .setUri(uris[i])
            .setMediaId(i.toString())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(titles[i]).build())
        // Only force MIME for adaptive streaming; let extractor auto-detect local files (safer)
        val path = uris[i].toString().substringBefore('?').lowercase(Locale.ROOT)
        when {
            path.endsWith(".m3u8") -> mb.setMimeType(MimeTypes.APPLICATION_M3U8)
            path.endsWith(".mpd") -> mb.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        extSubs[i]?.let { (uri, name) ->
            mb.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(uri)
                        .setMimeType(subtitleMime(name))
                        .setLanguage("und")
                        .setLabel(name)
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        return mb.build()
    }

    // ---------------------------------------------------------------- player

    private fun initPlayer() {
        // Prefer high quality but let device decoder decide what it can handle (avoids hard crash on 4K/HEVC)
        val selector = DefaultTrackSelector(this).apply {
            parameters = buildUponParameters()
                .setMaxVideoSize(3840, 2160) // 4K max; 8K often crashes weak devices
                .setMaxVideoBitrate(Int.MAX_VALUE)
                .setForceHighestSupportedBitrate(false)
                .setPreferredVideoMimeTypes(
                    MimeTypes.VIDEO_H265,
                    MimeTypes.VIDEO_VP9,
                    MimeTypes.VIDEO_AV1,
                    MimeTypes.VIDEO_H264
                )
                .setPreferredAudioMimeTypes(
                    MimeTypes.AUDIO_AAC,
                    MimeTypes.AUDIO_OPUS,
                    MimeTypes.AUDIO_E_AC3,
                    MimeTypes.AUDIO_AC3,
                    MimeTypes.AUDIO_VORBIS
                )
                .build()
        }
        trackSelector = selector

        // NextLib FFmpeg software decoders – used when hardware cannot decode (MKV / 2K / 4K etc.)
        val renderers = NextRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
            .setEnableAudioFloatOutput(false)

        // Extractors: WebM, Matroska/MKV, MP4, TS, etc.
        val extractorsFactory = DefaultExtractorsFactory()
            .setConstantBitrateSeekingEnabled(true)
            .setMp4ExtractorFlags(Mp4Extractor.FLAG_WORKAROUND_IGNORE_EDIT_LISTS)
            .setTsExtractorFlags(
                DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES or
                    DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
            )
            .setTsExtractorTimestampSearchBytes(TsExtractor.DEFAULT_TIMESTAMP_SEARCH_BYTES * 2)

        val mediaSourceFactory = DefaultMediaSourceFactory(this, extractorsFactory)

        // Conservative buffers – previous 120s @ 4K could OOM and crash the process
        val loadControl = DefaultLoadControl.Builder()
            .setAllocator(DefaultAllocator(true, 16 * 1024))
            .setBufferDurationsMs(
                5_000,   // min
                30_000,  // max (was 120s)
                1_500,   // playback
                2_500    // rebuffer
            )
            .setPrioritizeTimeOverSizeThresholds(true)
            .setTargetBufferBytes(-1)
            .build()

        val p = ExoPlayer.Builder(this, renderers)
            .setTrackSelector(selector)
            .setMediaSourceFactory(mediaSourceFactory)
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(SEEK_STEP)
            .setSeekForwardIncrementMs(SEEK_STEP)
            .setWakeMode(
                if (uris.any { it.scheme == "http" || it.scheme == "https" })
                    C.WAKE_MODE_NETWORK
                else
                    C.WAKE_MODE_LOCAL
            )
            .build()
        player = p
        b.playerView.player = p
        p.addListener(listener)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val start = if (pendingStartPos >= 0) pendingStartPos else savedPosition(uris[index])
        p.setMediaItems(uris.indices.map { buildItem(it) }, index, start)
        p.repeatMode = repeatMode
        p.setPlaybackSpeed(currentSpeed)
        p.prepare()
        p.playWhenReady = startPlaying
        startPlaying = false

        updateNavButtons()
        updateTitle()
        updatePlayIcon()
        showControls()
        if (start > 5000) showInfo("Resumed at ${formatTime(start)}")
    }

    private fun releasePlayer() {
        val p = player ?: return
        saveResume(p)
        index = p.currentMediaItemIndex.coerceIn(0, (uris.size - 1).coerceAtLeast(0))
        pendingStartPos = if (p.playbackState == Player.STATE_ENDED) 0L else p.currentPosition
        currentSpeed = p.playbackParameters.speed
        repeatMode = p.repeatMode
        p.removeListener(listener)
        runCatching { loudness?.release() }
        loudness = null
        p.release()
        player = null
        trackSelector = null
        b.playerView.player = null
    }

    private fun resumeKey(u: Uri) = "pos_" + u.toString().hashCode()

    private fun savedPosition(u: Uri): Long {
        val pos = prefs.getLong(resumeKey(u), 0L)
        return if (pos > 5000) pos else 0L
    }

    private fun saveResume(p: ExoPlayer) {
        val u = uris.getOrNull(p.currentMediaItemIndex) ?: return
        val dur = p.duration
        val pos = p.currentPosition
        val e = prefs.edit()
        if (dur != C.TIME_UNSET && pos > 5000 && pos < dur - 8000) e.putLong(resumeKey(u), pos)
        else e.remove(resumeKey(u))
        e.apply()
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            b.loading.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            updatePlayIcon()
            if (state == Player.STATE_ENDED) {
                player?.let { saveResume(it) }
                if (!locked) showControls()
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlayIcon()
            if (isPlaying) scheduleHide() else handler.removeCallbacks(hideRunnable)
            if (Build.VERSION.SDK_INT >= 26) updatePipParams()
            if (!isPlaying) player?.let { saveResume(it) }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateTitle()
            updateNavButtons()
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (Build.VERSION.SDK_INT >= 26) updatePipParams()
            if (autoOrient && !orientationApplied && videoSize.width > 0 && videoSize.height > 0) {
                orientationApplied = true
                requestedOrientation = if (videoSize.width >= videoSize.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            val hasText = tracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
            b.btnSubtitle.alpha = if (tracks.isTypeSelected(C.TRACK_TYPE_TEXT)) 1f else 0.55f
            b.btnSubtitle.visibility = View.VISIBLE
            val audioCount = tracks.groups.count { it.type == C.TRACK_TYPE_AUDIO }
            b.btnAudio.alpha = if (audioCount > 1) 1f else 0.55f
            if (!hasText && extSubs[player?.currentMediaItemIndex ?: -1] == null) b.btnSubtitle.alpha = 0.55f
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            setupLoudness(audioSessionId)
        }

        override fun onPlayerError(error: PlaybackException) {
            b.loading.visibility = View.GONE
            val cause = error.cause?.message?.take(150)
            val code = error.errorCode
            val msg = buildString {
                append("Cannot play this video\n")
                append(error.errorCodeName)
                if (!cause.isNullOrBlank()) {
                    append("\n")
                    append(cause)
                }
                when {
                    code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                        code == PlaybackException.ERROR_CODE_DECODING_FAILED ->
                        append("\n\nCodec not supported even with software decoder")
                    code == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ||
                        code == PlaybackException.ERROR_CODE_IO_NO_PERMISSION ->
                        append("\n\nFile missing or permission denied")
                    else -> append("\n\nTry another video")
                }
            }
            Toast.makeText(this@PlayerActivity, msg, Toast.LENGTH_LONG).show()
            if (!locked) showControls()

            // Soft recovery: if decoder failed, try next item in playlist instead of dying
            if (code == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                code == PlaybackException.ERROR_CODE_DECODING_FAILED) {
                player?.let { p ->
                    if (p.hasNextMediaItem()) {
                        handler.postDelayed({
                            p.seekToNextMediaItem()
                            p.prepare()
                            p.play()
                        }, 800)
                    }
                }
            }
        }
    }

    private fun setupLoudness(sessionId: Int) {
        runCatching { loudness?.release() }
        loudness = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
        try {
            loudness = LoudnessEnhancer(sessionId).apply {
                setTargetGain(boostMb)
                enabled = boostMb > 0
            }
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- controls

    private fun togglePlay() {
        val p = player ?: return
        if (p.playbackState == Player.STATE_ENDED) {
            p.seekTo(0)
            p.play()
        } else if (p.playWhenReady) {
            p.pause()
        } else {
            p.play()
        }
    }

    private fun updatePlayIcon() {
        val p = player
        val showPause = p != null && p.playWhenReady && p.playbackState != Player.STATE_ENDED
        b.btnPlayPause.setImageResource(if (showPause) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun updateTitle() {
        val i = player?.currentMediaItemIndex ?: index
        b.tvTitle.text = titles.getOrNull(i) ?: ""
    }

    private fun updateNavButtons() {
        val multi = uris.size > 1
        b.btnPrev.visibility = if (multi) View.VISIBLE else View.GONE
        b.btnNext.visibility = if (multi) View.VISIBLE else View.GONE
    }

    private fun updateProgress() {
        val p = player ?: return
        if (isScrubbing) return
        val dur = if (p.duration == C.TIME_UNSET) 0L else p.duration
        val pos = p.currentPosition.coerceAtLeast(0L)
        b.seekBar.max = dur.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        b.seekBar.progress = pos.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        b.seekBar.secondaryProgress = p.bufferedPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        b.tvTime.text = "${formatTime(pos)} / ${formatTime(dur)}"
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val dur = if (p.duration == C.TIME_UNSET) Long.MAX_VALUE else p.duration
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, dur))
        handler.removeCallbacks(resetSeekAccum)
        seekAccum += deltaMs
        handler.postDelayed(resetSeekAccum, 900)
        val secs = abs(seekAccum) / 1000
        showInfo(if (seekAccum < 0) "⏪  $secs s" else "$secs s  ⏩")
    }

    private fun fade(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            if (v.visibility != View.VISIBLE) v.alpha = 0f
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(150).start()
        } else {
            v.animate().alpha(0f).setDuration(200).withEndAction { v.visibility = View.GONE }.start()
        }
    }

    private fun showControls() {
        if (locked || inPip) return
        controlsVisible = true
        fade(b.controlsLayer, true)
        fade(b.btnLock, true)
        scheduleHide()
    }

    private fun hideControls() {
        if (isScrubbing) return
        controlsVisible = false
        handler.removeCallbacks(hideRunnable)
        fade(b.controlsLayer, false)
        if (!locked) fade(b.btnLock, false)
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        if (player?.isPlaying == true && controlsVisible && !locked) {
            handler.postDelayed(hideRunnable, HIDE_DELAY)
        }
    }

    private fun toggleLock() {
        locked = !locked
        handler.removeCallbacks(lockHideRunnable)
        if (locked) {
            b.btnLock.setImageResource(R.drawable.ic_lock)
            controlsVisible = false
            handler.removeCallbacks(hideRunnable)
            fade(b.controlsLayer, false)
            showInfo("🔒 Locked")
            handler.postDelayed(lockHideRunnable, LOCK_HIDE_DELAY)
        } else {
            b.btnLock.setImageResource(R.drawable.ic_unlock)
            showInfo("🔓 Unlocked")
            showControls()
        }
    }

    private fun showLockButtonTemporarily() {
        fade(b.btnLock, true)
        handler.removeCallbacks(lockHideRunnable)
        handler.postDelayed(lockHideRunnable, LOCK_HIDE_DELAY)
    }

    private fun showInfo(text: String, persistent: Boolean = false) {
        b.tvInfo.text = text
        b.tvInfo.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfoRunnable)
        if (!persistent) handler.postDelayed(hideInfoRunnable, 900)
    }

    private fun cycleAspect() {
        resizeIndex = (resizeIndex + 1) % resizeModes.size
        b.playerView.resizeMode = resizeModes[resizeIndex]
        userScale = 1f
        b.playerView.scaleX = 1f
        b.playerView.scaleY = 1f
        showInfo(resizeNames[resizeIndex])
    }

    private fun rotateScreen() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        orientationAuto = false
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        showInfo(if (landscape) "Portrait" else "Landscape")
    }

    private fun currentBrightness(): Float {
        val v = window.attributes.screenBrightness
        if (v >= 0f) return v
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) {
            0.5f
        }
    }

    // ---------------------------------------------------------------- PiP

    private fun buildPipParams(): PictureInPictureParams {
        var ratio = Rational(16, 9)
        val vs = player?.videoSize
        if (vs != null && vs.width > 0 && vs.height > 0) {
            val r = vs.width * vs.pixelWidthHeightRatio / vs.height
            ratio = when {
                r > 2.39f -> Rational(239, 100)
                r < 0.42f -> Rational(100, 239)
                else -> Rational((r * 1000).roundToInt(), 1000)
            }
        }
        val builder = PictureInPictureParams.Builder().setAspectRatio(ratio)
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setAutoEnterEnabled(player?.isPlaying == true && !locked)
        }
        return builder.build()
    }

    private fun updatePipParams() {
        try {
            setPictureInPictureParams(buildPipParams())
        } catch (_: Exception) {
        }
    }

    private fun enterPip() {
        if (!packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            Toast.makeText(this, "Picture-in-picture is not supported", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            enterPictureInPictureMode(buildPipParams())
        } catch (_: Exception) {
            Toast.makeText(this, "Enable picture-in-picture in app settings", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- dialogs

    private fun showDialog(builder: AlertDialog.Builder) {
        handler.removeCallbacks(hideRunnable)
        val d = builder.create()
        d.setOnDismissListener {
            hideSystemBars()
            scheduleHide()
        }
        d.show()
    }

    private fun showSpeedDialog() {
        val p = player ?: return
        val cur = p.playbackParameters.speed
        val labels = speeds.map { if (it == 1f) "Normal (1×)" else "${trimFloat(it)}×" }.toTypedArray()
        var checked = speeds.indexOfFirst { abs(it - cur) < 0.01f }
        if (checked < 0) checked = 3
        showDialog(
            AlertDialog.Builder(this)
                .setTitle("Playback speed")
                .setSingleChoiceItems(labels, checked) { dlg, which ->
                    p.setPlaybackSpeed(speeds[which])
                    currentSpeed = speeds[which]
                    showInfo("Speed ${trimFloat(speeds[which])}×")
                    dlg.dismiss()
                }
        )
    }

    private fun trimFloat(f: Float): String =
        if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString()

    private fun trackName(f: Format, i: Int): String {
        val parts = mutableListOf<String>()
        val lang = f.language?.takeIf { it != "und" && it.isNotBlank() }
            ?.let { Locale.forLanguageTag(it).displayLanguage.ifBlank { it } }
        val label = f.label?.takeIf { it.isNotBlank() }
        if (label != null) parts += label
        if (lang != null && !(label?.contains(lang, ignoreCase = true) ?: false)) parts += lang
        if (f.channelCount > 0) {
            parts += when (f.channelCount) {
                1 -> "Mono"
                2 -> "Stereo"
                6 -> "5.1"
                8 -> "7.1"
                else -> "${f.channelCount}ch"
            }
        }
        f.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)
            ?.takeIf { f.channelCount > 0 }?.let { parts += it }
        return if (parts.isEmpty()) "Track ${i + 1}" else parts.joinToString(" · ")
    }

    private fun showTrackDialog(trackType: Int, title: String) {
        val p = player ?: return
        val groups = p.currentTracks.groups.filter { it.type == trackType }
        if (groups.isEmpty()) {
            Toast.makeText(this, "No $title available", Toast.LENGTH_SHORT).show()
            return
        }
        data class Entry(val group: Tracks.Group, val idx: Int)

        val entries = mutableListOf<Entry>()
        val names = mutableListOf<String>()
        var checked = -1
        var n = 0
        for (g in groups) {
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                if (g.isTrackSelected(i)) checked = names.size
                entries += Entry(g, i)
                names += trackName(g.getTrackFormat(i), n++)
            }
        }
        val isText = trackType == C.TRACK_TYPE_TEXT
        if (isText) {
            names.add(0, "Off")
            if (p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || checked < 0) checked = 0
            else checked += 1
        }
        showDialog(
            AlertDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(names.toTypedArray(), checked) { dlg, which ->
                    val params = p.trackSelectionParameters.buildUpon()
                    if (isText && which == 0) {
                        params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    } else {
                        val e = entries[if (isText) which - 1 else which]
                        params.setTrackTypeDisabled(trackType, false)
                        params.setOverrideForType(TrackSelectionOverride(e.group.mediaTrackGroup, e.idx))
                    }
                    p.trackSelectionParameters = params.build()
                    dlg.dismiss()
                }
        )
    }

    private fun showSubtitleDialog() {
        val p = player ?: return
        val hasText = p.currentTracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
        val items = arrayOf("Choose subtitle track", "Load subtitle file (.srt .vtt .ass)", "Subtitle size")
        showDialog(
            AlertDialog.Builder(this)
                .setTitle("Subtitles")
                .setItems(items) { _, which ->
                    when (which) {
                        0 -> if (hasText) showTrackDialog(C.TRACK_TYPE_TEXT, "Subtitles")
                        else Toast.makeText(this, "No embedded subtitles", Toast.LENGTH_SHORT).show()
                        1 -> pickSubtitle.launch(arrayOf("*/*"))
                        2 -> showSubtitleSizeDialog()
                    }
                }
        )
    }

    private fun showSubtitleSizeDialog() {
        val labels = arrayOf("Small", "Normal", "Large", "Extra large")
        val values = floatArrayOf(0.7f, 1f, 1.4f, 1.9f)
        var checked = values.indexOfFirst { abs(it - subScale) < 0.05f }
        if (checked < 0) checked = 1
        showDialog(
            AlertDialog.Builder(this)
                .setTitle("Subtitle size")
                .setSingleChoiceItems(labels, checked) { dlg, which ->
                    subScale = values[which]
                    prefs.edit().putFloat(KEY_SUB_SCALE, subScale).apply()
                    b.playerView.subtitleView?.setFractionalTextSize(
                        SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * subScale
                    )
                    dlg.dismiss()
                }
        )
    }

    private fun loadExternalSubtitle(uri: Uri) {
        val p = player ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        val idx = p.currentMediaItemIndex
        val pos = p.currentPosition
        val wasPlaying = p.playWhenReady
        extSubs[idx] = Pair(uri, resolveName(uri))
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        p.replaceMediaItem(idx, buildItem(idx))
        p.seekTo(idx, pos)
        p.playWhenReady = wasPlaying
        showInfo("Subtitle loaded")
    }

    private fun showMoreDialog() {
        val p = player ?: return
        val repeatLabel = when (p.repeatMode) {
            Player.REPEAT_MODE_ONE -> "Repeat: this video"
            Player.REPEAT_MODE_ALL -> "Repeat: all videos"
            else -> "Repeat: off"
        }
        val items = arrayOf(
            "Quality / Resolution",
            repeatLabel,
            "Sleep timer",
            "Volume boost" + if (boostMb > 0) " (+${boostMb / 100} dB)" else "",
            "Auto-rotate to video: " + if (autoOrient) "on" else "off",
            "Video info"
        )
        showDialog(
            AlertDialog.Builder(this)
                .setTitle("More")
                .setItems(items) { _, which ->
                    when (which) {
                        0 -> showQualityDialog()
                        1 -> {
                            p.repeatMode = when (p.repeatMode) {
                                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
                                Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
                                else -> Player.REPEAT_MODE_OFF
                            }
                            repeatMode = p.repeatMode
                            showInfo(
                                when (p.repeatMode) {
                                    Player.REPEAT_MODE_ONE -> "Repeat this video"
                                    Player.REPEAT_MODE_ALL -> "Repeat all"
                                    else -> "Repeat off"
                                }
                            )
                        }
                        2 -> showSleepDialog()
                        3 -> showBoostDialog()
                        4 -> {
                            autoOrient = !autoOrient
                            orientationApplied = false
                            prefs.edit().putBoolean(KEY_AUTO_ORIENT, autoOrient).apply()
                            showInfo("Auto-rotate to video " + if (autoOrient) "on" else "off")
                        }
                        5 -> showVideoInfo()
                    }
                }
        )
    }

    private fun showQualityDialog() {
        val p = player ?: return
        val tracks = p.currentTracks
        val options = mutableListOf<String>()
        val overrides = mutableListOf<TrackSelectionOverride?>()

        // Auto (highest)
        options.add("Auto (highest)")
        overrides.add(null)

        for (group in tracks.groups) {
            if (group.type != C.TRACK_TYPE_VIDEO) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSupported(i)) continue
                val format = group.getTrackFormat(i)
                val h = format.height
                val w = format.width
                val br = format.bitrate
                val label = when {
                    h >= 2160 -> "4K UHD (${w}x${h})"
                    h >= 1440 -> "2K QHD (${w}x${h})"
                    h >= 1080 -> "Full HD (${w}x${h})"
                    h >= 720 -> "HD (${w}x${h})"
                    h > 0 -> "${w}x${h}"
                    else -> "Track ${i + 1}"
                } + if (br > 0) " · ${br / 1000} kbps" else ""
                options.add(label)
                overrides.add(TrackSelectionOverride(group.mediaTrackGroup, i))
            }
        }

        if (options.size <= 1) {
            Toast.makeText(this, "Only one quality available", Toast.LENGTH_SHORT).show()
            return
        }

        showDialog(
            AlertDialog.Builder(this)
                .setTitle("Quality / Resolution")
                .setItems(options.toTypedArray()) { _, which ->
                    val params = p.trackSelectionParameters.buildUpon()
                        .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                    val ov = overrides[which]
                    if (ov != null) {
                        params.addOverride(ov)
                        params.setForceHighestSupportedBitrate(false)
                    } else {
                        params.setForceHighestSupportedBitrate(true)
                    }
                    p.trackSelectionParameters = params.build()
                    showInfo(options[which])
                }
        )
    }

    private fun showSleepDialog() {
        val labels = arrayOf("Off", "10 minutes", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        val mins = intArrayOf(0, 10, 15, 30, 45, 60, 90)
        showDialog(
            AlertDialog.Builder(this)
                .setTitle("Sleep timer")
                .setItems(labels) { _, which ->
                    sleepRunnable?.let { handler.removeCallbacks(it) }
                    sleepRunnable = null
                    if (mins[which] > 0) {
                        val r = Runnable {
                            player?.pause()
                            Toast.makeText(this, "Sleep timer: paused", Toast.LENGTH_LONG).show()
                        }
                        sleepRunnable = r
                        handler.postDelayed(r, mins[which] * 60_000L)
                        showInfo("Sleep in ${mins[which]} min")
                    } else {
                        showInfo("Sleep timer off")
                    }
                }
        )
    }

    private fun showBoostDialog() {
        val labels = arrayOf("Off", "+3 dB", "+6 dB", "+9 dB", "+12 dB")
        val values = intArrayOf(0, 300, 600, 900, 1200)
        var checked = values.indexOf(boostMb)
        if (checked < 0) checked = 0
        showDialog(
            AlertDialog.Builder(this)
                .setTitle("Volume boost")
                .setSingleChoiceItems(labels, checked) { dlg, which ->
                    boostMb = values[which]
                    try {
                        loudness?.setTargetGain(boostMb)
                        loudness?.enabled = boostMb > 0
                    } catch (_: Exception) {
                    }
                    showInfo(if (boostMb > 0) "Boost +${boostMb / 100} dB" else "Boost off")
                    dlg.dismiss()
                }
        )
    }

    private fun showVideoInfo() {
        val p = player ?: return
        val v = p.videoFormat
        val a = p.audioFormat
        val sb = StringBuilder()
        sb.append("Title: ").append(titles.getOrNull(p.currentMediaItemIndex) ?: "-").append('\n')
        if (p.duration != C.TIME_UNSET) sb.append("Duration: ").append(formatTime(p.duration)).append('\n')
        if (v != null) {
            sb.append("Video: ").append(v.width).append('×').append(v.height)
            if (v.frameRate > 0) sb.append(" @ ").append(String.format(Locale.US, "%.2f", v.frameRate)).append(" fps")
            sb.append('\n')
            v.sampleMimeType?.let { sb.append("Video codec: ").append(it.substringAfter('/')).append('\n') }
            if (v.bitrate > 0) sb.append("Video bitrate: ").append(v.bitrate / 1000).append(" kbps\n")
        }
        if (a != null) {
            a.sampleMimeType?.let { sb.append("Audio codec: ").append(it.substringAfter('/')).append('\n') }
            if (a.channelCount > 0) sb.append("Channels: ").append(a.channelCount).append('\n')
            if (a.sampleRate > 0) sb.append("Sample rate: ").append(a.sampleRate).append(" Hz\n")
        }
        sb.append("Source: ").append(uris.getOrNull(p.currentMediaItemIndex) ?: "-")
        showDialog(
            AlertDialog.Builder(this)
                .setTitle("Video info")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
        )
    }

    // ---------------------------------------------------------------- keys

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && !locked) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    togglePlay(); return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    seekBy(-SEEK_STEP); return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    seekBy(SEEK_STEP); return true
                }
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    player?.seekToNextMediaItem(); return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    player?.seekToPreviousMediaItem(); return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }
}
