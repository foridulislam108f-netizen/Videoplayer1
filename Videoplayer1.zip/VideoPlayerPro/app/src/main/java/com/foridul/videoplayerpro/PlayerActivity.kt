package com.foridul.videoplayerpro

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.media.AudioManager
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.GestureDetector
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.SubtitleView
import com.foridul.videoplayerpro.databinding.ActivityPlayerBinding
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URIS = "uris"
        const val EXTRA_TITLES = "titles"
        const val EXTRA_INDEX = "index"

        private const val PREFS = "player_prefs"
        private const val KEY_SUB_SCALE = "sub_scale"
        private const val KEY_SUB_OFFSET = "sub_offset"
        private const val KEY_SUB_DISABLED = "sub_disabled"
        private const val KEY_AUTO_ORIENT = "auto_orient"
        private const val HIDE_DELAY = 4000L
        private const val LOCK_HIDE_DELAY = 3000L
        private const val SEEK_STEP = 10_000L
    }

    private enum class Gesture { NONE, SEEK, BRIGHTNESS, VOLUME, ZOOM }

    private lateinit var b: ActivityPlayerBinding
    private lateinit var prefs: SharedPreferences
    private lateinit var audioManager: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var player: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    private var loudness: LoudnessEnhancer? = null

    // Playlist
    private var uris: List<Uri> = emptyList()
    private var titles: List<String> = emptyList()
    private var index = 0
    private val extSubs = mutableMapOf<Int, Triple<Uri, String, String>>() // local uri, label, mime

    // State kept across stop/start
    private var pendingStartPos = -1L
    private var startPlaying = true
    private var currentSpeed = 1f
    private var boostMb = 0
    private var repeatMode = Player.REPEAT_MODE_OFF

    // UI state
    private var locked = false
    private var controlsVisible = true
    private var isScrubbing = false
    private var inPip = false
    private var resizeIndex = 0
    private var insetBottom = 0f
    private var userScale = 1f
    private var subScale = 1f
    private var subOffsetSec = 0f
    private var subDisabled = false
    private var subtitlePanelVisible = false
    private var autoOrient = false
    private var orientationAuto = true
    private var orientationApplied = false
    private var audioOnly = false

    // Gesture state
    private var gesture = Gesture.NONE
    private var seekStartPos = 0L
    private var seekTarget = 0L
    private var brightStart = 0.5f
    private var volStart = 0.5f
    private var boostActive = false
    private var speedBeforeBoost = 1f
    private var seekAccum = 0L

    private var sleepRunnable: Runnable? = null

    private val resizeModes = intArrayOf(
        AspectRatioFrameLayout.RESIZE_MODE_FIT,
        AspectRatioFrameLayout.RESIZE_MODE_FILL,
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    )
    private val resizeNames = arrayOf("Fit", "Stretch", "Crop (fill screen)", "Fit width", "Fit height")
    private val speeds = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f, 4f)

    private val hideRunnable = Runnable { if (!isScrubbing) hideControls() }
    private val lockHideRunnable = Runnable { if (locked) fade(b.btnLock, false) }
    private val hideInfoRunnable = Runnable { hideHuds() }
    private val resetSeekAccum = Runnable { seekAccum = 0L }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 250)
        }
    }

    private val pickSubtitle =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) loadExternalSubtitle(uri)
        }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(b.root)

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        subScale = prefs.getFloat(KEY_SUB_SCALE, 1f)
        subOffsetSec = prefs.getFloat(KEY_SUB_OFFSET, 0f)
        subDisabled = prefs.getBoolean(KEY_SUB_DISABLED, false)
        applyOrientationMode()

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setupWindow()
        setupSubtitleView()
        setupButtons()
        setupSubtitlePanelListeners()
        setupSeekBar()
        setupGestures()
        if (subDisabled) applySubtitleDisabled()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (subtitlePanelVisible) {
                    hideSubtitlePanel()
                } else if (locked) {
                    Toast.makeText(this@PlayerActivity, "Screen is locked", Toast.LENGTH_SHORT).show()
                    showLockButtonTemporarily()
                } else {
                    finish()
                }
            }
        })

        parseIntent(intent)
        if (uris.isEmpty()) {
            Toast.makeText(this, "No video to play", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val wasRunning = player != null
        if (wasRunning) releasePlayer()
        extSubs.clear()
        selectExtSubNext = false
        pendingStartPos = -1L
        startPlaying = true
        parseIntent(intent)
        if (wasRunning && uris.isNotEmpty()) initPlayer()
    }

    override fun onStart() {
        super.onStart()
        if (player == null && uris.isNotEmpty()) initPlayer()
        handler.post(progressRunnable)
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(progressRunnable)
        if (isInPictureInPictureMode) {
            // PiP window was closed with the X button
            releasePlayer()
            finishAndRemoveTask()
            return
        }
        releasePlayer()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Android 12+ uses setAutoEnterEnabled; older versions enter here.
        if (Build.VERSION.SDK_INT < 31 && player?.isPlaying == true && !locked && !audioOnly) enterPip()
    }

    override fun onPictureInPictureModeChanged(inPipMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(inPipMode, newConfig)
        inPip = inPipMode
        if (inPipMode) {
            b.controlsLayer.visibility = View.GONE
            b.btnLock.visibility = View.GONE
            hideHuds()
            b.playerView.scaleX = 1f
            b.playerView.scaleY = 1f
        } else {
            b.playerView.scaleX = userScale
            b.playerView.scaleY = userScale
            if (locked) {
                showLockButtonTemporarily()
            } else {
                showControls()
            }
        }
    }

    // ---------------------------------------------------------------- setup

    private fun setupWindow() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        else
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { _, insets ->
            val i = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            b.controlsContent.setPadding(i.left, i.top, i.right, i.bottom)
            // Lock button is bottom-left: keep it inside system bars / display cutout
            b.btnLock.translationX = i.left.toFloat()
            insetBottom = i.bottom.toFloat()
            applyFitLift()
            insets
        }
        hideSystemBars()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, b.root)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun setupSubtitleView() {
        b.playerView.subtitleView?.apply {
            setStyle(
                CaptionStyleCompat(
                    Color.WHITE, Color.TRANSPARENT, Color.TRANSPARENT,
                    CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null
                )
            )
            setFractionalTextSize(SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * subScale)
            setBottomPaddingFraction(0.08f)
        }
    }

    private fun setupButtons() {
        b.btnBack.setOnClickListener { finish() }
        b.btnPlayPause.setOnClickListener { togglePlay(); scheduleHide() }
        b.btnNext.setOnClickListener { player?.seekToNextMediaItem(); scheduleHide() }
        b.btnPrev.setOnClickListener {
            val p = player ?: return@setOnClickListener
            if (p.currentPosition > 3000 || !p.hasPreviousMediaItem()) p.seekTo(0)
            else p.seekToPreviousMediaItem()
            scheduleHide()
        }
        b.btnLock.setOnClickListener { toggleLock() }
        b.btnPip.setOnClickListener { enterPip() }
        b.btnAspect.setOnClickListener { cycleAspect(); scheduleHide() }
        b.btnSpeed.setOnClickListener { showSpeedDialog() }
        b.btnRotate.setOnClickListener { rotateScreen(); scheduleHide() }
        b.btnRotate.setOnLongClickListener {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            orientationAuto = true
            showInfo("Auto rotate")
            true
        }
        b.btnSubtitle.setOnClickListener { toggleSubtitlePanel() }
        b.btnAudio.setOnClickListener { showTrackDialog(C.TRACK_TYPE_AUDIO, "Audio track") }
        b.btnMore.setOnClickListener { showMoreDialog() }
    }

    private fun setupSeekBar() {
        b.seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar) {
                isScrubbing = true
                handler.removeCallbacks(hideRunnable)
            }

            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val dur = (player?.duration ?: 0L).coerceAtLeast(0L)
                b.tvTime.text = "${formatTime(progress.toLong())} / ${formatTime(dur)}"
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                player?.seekTo(seekBar.progress.toLong())
                isScrubbing = false
                scheduleHide()
            }
        })
    }

    private fun setupGestures() {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop

        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                if (locked || inPip) return false
                gesture = Gesture.ZOOM
                return true
            }

            override fun onScale(detector: ScaleGestureDetector): Boolean {
                userScale = (userScale * detector.scaleFactor).coerceIn(1f, 4f)
                b.playerView.scaleX = userScale
                b.playerView.scaleY = userScale
                showInfo("Zoom ${(userScale * 100).roundToInt()}%")
                return true
            }
        })

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (subtitlePanelVisible) {
                    hideSubtitlePanel()
                    return true
                }
                if (locked) showLockButtonTemporarily()
                else if (controlsVisible) hideControls() else showControls()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked || inPip) return true
                val w = b.gestureView.width
                when {
                    e.x < w * 0.35f -> seekBy(-SEEK_STEP)
                    e.x > w * 0.65f -> seekBy(SEEK_STEP)
                    else -> togglePlay()
                }
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
                if (locked || inPip || e1 == null || boostActive) return false
                val p = player ?: return false
                val w = b.gestureView.width.toFloat()
                val h = b.gestureView.height.toFloat()
                if (gesture == Gesture.ZOOM) return false

                if (gesture == Gesture.NONE) {
                    val ax = abs(e2.x - e1.x)
                    val ay = abs(e2.y - e1.y)
                    if (ax < touchSlop && ay < touchSlop) return false
                    when {
                        ax > ay -> {
                            if (p.duration == C.TIME_UNSET) return false
                            gesture = Gesture.SEEK
                            seekStartPos = p.currentPosition
                            seekTarget = seekStartPos
                        }
                        e1.x < w / 2f -> {
                            gesture = Gesture.BRIGHTNESS
                            brightStart = currentBrightness()
                        }
                        else -> {
                            gesture = Gesture.VOLUME
                            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                            volStart = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) / max.toFloat()
                        }
                    }
                }

                when (gesture) {
                    Gesture.SEEK -> {
                        val dur = p.duration.coerceAtLeast(0L)
                        val delta = ((e2.x - e1.x) / w * 120_000f).toLong()
                        seekTarget = (seekStartPos + delta).coerceIn(0L, dur)
                        val diff = seekTarget - seekStartPos
                        showSeekHud(diff, seekTarget, dur)
                    }
                    Gesture.BRIGHTNESS -> {
                        val level = (brightStart + (e1.y - e2.y) / h * 1.2f).coerceIn(0.01f, 1f)
                        val lp = window.attributes
                        lp.screenBrightness = level
                        window.attributes = lp
                        showLevel(R.drawable.ic_brightness, 0xFFFFC857.toInt(), (level * 100).roundToInt(), onRight = true)
                    }
                    Gesture.VOLUME -> {
                        val level = (volStart + (e1.y - e2.y) / h * 1.2f).coerceIn(0f, 1f)
                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                        audioManager.setStreamVolume(
                            AudioManager.STREAM_MUSIC, (level * max).roundToInt(), 0
                        )
                        val pct = (level * 100).roundToInt()
                        val icon = when {
                            pct == 0 -> R.drawable.ic_volume_off
                            pct < 50 -> R.drawable.ic_volume_low
                            else -> R.drawable.ic_volume_high
                        }
                        showLevel(icon, if (pct == 0) 0xFFFF6B6B.toInt() else 0xFF6C8CFF.toInt(), pct, onRight = false)
                    }
                    else -> {}
                }
                return true
            }
        })

        b.gestureView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> gesture = Gesture.NONE
            }
            scale.onTouchEvent(ev)
            if (ev.pointerCount == 1 && gesture != Gesture.ZOOM) detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                endGesture()
            }
            true
        }
    }

    private fun endGesture() {
        if (gesture == Gesture.SEEK) player?.seekTo(seekTarget)
        if (boostActive) {
            boostActive = false
            player?.setPlaybackSpeed(speedBeforeBoost)
        }
        if (gesture != Gesture.NONE || hudShowing()) {
            handler.removeCallbacks(hideInfoRunnable)
            handler.postDelayed(hideInfoRunnable, 700)
        }
        gesture = Gesture.NONE
    }

    // ---------------------------------------------------------------- intent / items

    private fun parseIntent(i: Intent) {
        val list = i.getStringArrayListExtra(EXTRA_URIS)
        if (!list.isNullOrEmpty()) {
            uris = list.map { Uri.parse(it) }
            val t = i.getStringArrayListExtra(EXTRA_TITLES)
            titles = uris.mapIndexed { n, u -> t?.getOrNull(n) ?: resolveName(u) }
            index = i.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, uris.lastIndex)
        } else if (i.data != null) {
            val u = i.data!!
            uris = listOf(u)
            titles = listOf(resolveName(u))
            index = 0
        } else {
            uris = emptyList()
            titles = emptyList()
        }
    }

    private fun resolveName(u: Uri): String {
        if (u.scheme == "content") {
            try {
                contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) {
                        val n = it.getString(0)
                        if (!n.isNullOrBlank()) return n
                    }
                }
            } catch (_: Exception) {
            }
        }
        return u.lastPathSegment ?: u.toString()
    }

    private fun subtitleMime(name: String): String {
        val n = name.lowercase(Locale.ROOT)
        return when {
            n.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            n.endsWith(".ass") || n.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            n.endsWith(".ttml") || n.endsWith(".xml") || n.endsWith(".dfxp") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
    }

    private fun buildItem(i: Int): MediaItem {
        val mb = MediaItem.Builder()
            .setUri(uris[i])
            .setMediaId(i.toString())
            .setMediaMetadata(MediaMetadata.Builder().setTitle(titles[i]).build())
        val path = uris[i].toString().substringBefore('?').lowercase(Locale.ROOT)
        when {
            path.endsWith(".m3u8") -> mb.setMimeType(MimeTypes.APPLICATION_M3U8)
            path.endsWith(".mpd") -> mb.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        extSubs[i]?.let { (uri, name, mime) ->
            mb.setSubtitleConfigurations(
                listOf(
                    MediaItem.SubtitleConfiguration.Builder(uri)
                        .setMimeType(mime)
                        .setLanguage("und")
                        .setLabel(name)
                        .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                        .build()
                )
            )
        }
        return mb.build()
    }

    // ---------------------------------------------------------------- player

    private fun initPlayer() {
        val selector = DefaultTrackSelector(this)
        selector.setParameters(
            selector.buildUponParameters()
                .setExceedRendererCapabilitiesIfNecessary(true)
                .setExceedVideoConstraintsIfNecessary(true)
                .setExceedAudioConstraintsIfNecessary(true)
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowAudioMixedMimeTypeAdaptiveness(true)
                .setAllowVideoMixedDecoderSupportAdaptiveness(true)
                .setAllowAudioMixedDecoderSupportAdaptiveness(true)
        )
        trackSelector = selector
        val renderers = DefaultRenderersFactory(this)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)
            .setEnableAudioTrackPlaybackParams(true)
            .forceEnableMediaCodecAsynchronousQueueing()

        // Start playing after ~0.5 s of data instead of the default 2.5 s, and resume quickly after stalls.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, 500, 1_500)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val p = ExoPlayer.Builder(this, renderers)
            .setLoadControl(loadControl)
            .setTrackSelector(selector)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(SEEK_STEP)
            .setSeekForwardIncrementMs(SEEK_STEP)
            .build()
        player = p
        // Jump to the nearest keyframe: much faster resume/seek on large HEVC/4K files than exact seeking.
        p.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC)
        b.playerView.player = p
        p.addListener(listener)

        val start = if (pendingStartPos >= 0) pendingStartPos else savedPosition(uris[index])
        p.setMediaItems(uris.indices.map { buildItem(it) }, index, start)
        p.repeatMode = repeatMode
        p.setPlaybackSpeed(currentSpeed)
        p.prepare()
        p.playWhenReady = startPlaying
        startPlaying = false // after any later restart, stay paused until the user resumes

        updateNavButtons()
        updateTitle()
        updatePlayIcon()
        showControls()
        if (selectExtSubNext && extSubs.isNotEmpty()) showInfo("Subtitle loaded")
        else if (start > 5000) showInfo("Resumed at ${formatTime(start)}")
    }

    private fun releasePlayer() {
        val p = player ?: return
        saveResume(p)
        index = p.currentMediaItemIndex.coerceIn(0, (uris.size - 1).coerceAtLeast(0))
        pendingStartPos = if (p.playbackState == Player.STATE_ENDED) 0L else p.currentPosition
        currentSpeed = p.playbackParameters.speed
        repeatMode = p.repeatMode
        p.removeListener(listener)
        runCatching { loudness?.release() }
        loudness = null
        p.release()
        player = null
        trackSelector = null
        b.playerView.player = null
    }

    private fun resumeKey(u: Uri) = "pos_" + u.toString().hashCode()

    private fun savedPosition(u: Uri): Long {
        val pos = prefs.getLong(resumeKey(u), 0L)
        return if (pos > 5000) pos else 0L
    }

    private fun saveResume(p: ExoPlayer) {
        val u = uris.getOrNull(p.currentMediaItemIndex) ?: return
        val dur = p.duration
        val pos = p.currentPosition
        val e = prefs.edit()
        if (dur == C.TIME_UNSET) return // not prepared yet: don't wipe the saved position
        if (pos > 5000 && pos < dur - 8000) e.putLong(resumeKey(u), pos)
        else e.remove(resumeKey(u))
        e.apply()
    }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(state: Int) {
            b.loading.visibility = if (state == Player.STATE_BUFFERING) View.VISIBLE else View.GONE
            updatePlayIcon()
            if (state == Player.STATE_ENDED) {
                player?.let { saveResume(it) }
                if (!locked) showControls()
            }
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePlayIcon()
            if (isPlaying) scheduleHide() else handler.removeCallbacks(hideRunnable)
            if (Build.VERSION.SDK_INT >= 26) updatePipParams()
            if (!isPlaying) player?.let { saveResume(it) }
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int
        ) {
            // Leaving an item (next/previous/auto-advance): remember where we left the old one.
            if (oldPosition.mediaItemIndex == newPosition.mediaItemIndex) return
            val u = uris.getOrNull(oldPosition.mediaItemIndex) ?: return
            val e = prefs.edit()
            if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) e.remove(resumeKey(u))
            else if (oldPosition.positionMs > 5000) e.putLong(resumeKey(u), oldPosition.positionMs)
            e.apply()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updateTitle()
            updateNavButtons()
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (Build.VERSION.SDK_INT >= 26) updatePipParams()
            if (autoOrient && !orientationApplied && videoSize.width > 0 && videoSize.height > 0) {
                orientationApplied = true
                requestedOrientation = if (videoSize.width >= videoSize.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            val hasVideoTrack = tracks.groups.any { it.type == C.TRACK_TYPE_VIDEO }
            if (hasVideoTrack && !tracks.isTypeSelected(C.TRACK_TYPE_VIDEO)) {
                // phone cannot decode this video codec/size -> universal engine
                handler.post { fallbackToVlc() }
                return
            }
            // SOUND FIX: the picture plays but the phone has no decoder for the audio codec
            // (AC3 / E-AC3 / DTS / TrueHD / some Vorbis, Opus, AMR, WMA ...). ExoPlayer then plays
            // the video silently without any error, so switch to the universal engine (libVLC),
            // which decodes all of these in software.
            val audioGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
            if (audioGroups.isNotEmpty() && !tracks.isTypeSelected(C.TRACK_TYPE_AUDIO)) {
                handler.post { fallbackToVlc("This audio format needs the universal engine…") }
                return
            }
            val audioOnlyNow = !hasVideoTrack && audioGroups.isNotEmpty()
            if (audioOnlyNow != audioOnly) {
                audioOnly = audioOnlyNow
                applyAudioLayout()
            }
            selectExternalSubtitleTrack(tracks)
            val hasText = tracks.groups.any { it.type == C.TRACK_TYPE_TEXT }
            b.btnSubtitle.alpha = if (tracks.isTypeSelected(C.TRACK_TYPE_TEXT)) 1f else 0.55f
            b.btnSubtitle.visibility = View.VISIBLE
            val audioCount = tracks.groups.count { it.type == C.TRACK_TYPE_AUDIO }
            b.btnAudio.alpha = if (audioCount > 1) 1f else 0.55f
            if (!hasText && extSubs[player?.currentMediaItemIndex ?: -1] == null) b.btnSubtitle.alpha = 0.55f
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            setupLoudness(audioSessionId)
        }

        override fun onPlayerError(error: PlaybackException) {
            b.loading.visibility = View.GONE
            if (fallbackToVlc()) return
            val detail = error.cause?.message?.take(120)?.let { " ($it)" } ?: ""
            Toast.makeText(
                this@PlayerActivity,
                "Playback error: ${error.errorCodeName}$detail",
                Toast.LENGTH_LONG
            ).show()
            if (!locked) showControls()
        }
    }

    private var vlcLaunched = false

    /** Hand the current file to the libVLC engine (plays almost every codec, 2K/4K included). */
    private fun fallbackToVlc(notice: String? = null): Boolean {
        if (vlcLaunched) return true
        val p = player ?: return false
        val i = p.currentMediaItemIndex
        val u = uris.getOrNull(i) ?: return false
        vlcLaunched = true
        if (notice != null) Toast.makeText(this, notice, Toast.LENGTH_SHORT).show()
        val pos = p.currentPosition
        runCatching { p.pause() }
        val it = Intent(this, VlcPlayerActivity::class.java)
            .setData(u)
            .putExtra("title", titles.getOrNull(i) ?: "")
            .putStringArrayListExtra(EXTRA_URIS, ArrayList(uris.map { it.toString() }))
            .putStringArrayListExtra(EXTRA_TITLES, ArrayList(titles))
            .putExtra(EXTRA_INDEX, i)
            .putExtra("pos", pos)
            .putExtra("sub", extSubs[i]?.first?.toString())
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(it)
        finish()
        return true
    }

    private fun setupLoudness(sessionId: Int) {
        runCatching { loudness?.release() }
        loudness = null
        if (sessionId == C.AUDIO_SESSION_ID_UNSET) return
        try {
            loudness = LoudnessEnhancer(sessionId).apply {
                setTargetGain(boostMb)
                enabled = boostMb > 0
            }
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- controls

    private fun togglePlay() {
        val p = player ?: return
        if (p.playbackState == Player.STATE_ENDED) {
            p.seekTo(0)
            p.play()
        } else if (p.playWhenReady) {
            p.pause()
        } else {
            p.play()
        }
    }

    private fun updatePlayIcon() {
        val p = player
        val showPause = p != null && p.playWhenReady && p.playbackState != Player.STATE_ENDED
        b.btnPlayPause.setImageResource(if (showPause) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun updateTitle() {
        val i = player?.currentMediaItemIndex ?: index
        b.tvTitle.text = titles.getOrNull(i) ?: ""
    }

    private fun updateNavButtons() {
        val multi = uris.size > 1
        b.btnPrev.visibility = if (multi) View.VISIBLE else View.GONE
        b.btnNext.visibility = if (multi) View.VISIBLE else View.GONE
    }

    private fun updateProgress() {
        val p = player ?: return
        if (isScrubbing) return
        val dur = if (p.duration == C.TIME_UNSET) 0L else p.duration
        val pos = p.currentPosition.coerceAtLeast(0L)
        b.seekBar.max = dur.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        b.seekBar.progress = pos.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        b.seekBar.secondaryProgress = p.bufferedPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        b.tvTime.text = "${formatTime(pos)} / ${formatTime(dur)}"
    }

    private fun seekBy(deltaMs: Long) {
        val p = player ?: return
        val dur = if (p.duration == C.TIME_UNSET) Long.MAX_VALUE else p.duration
        p.seekTo((p.currentPosition + deltaMs).coerceIn(0L, dur))
        handler.removeCallbacks(resetSeekAccum)
        seekAccum += deltaMs
        handler.postDelayed(resetSeekAccum, 900)
        val secs = abs(seekAccum) / 1000
        showInfo(
            "$secs s",
            icon = if (seekAccum < 0) R.drawable.ic_rewind else R.drawable.ic_fast_forward
        )
    }

    private fun fade(v: View, show: Boolean) {
        v.animate().cancel()
        if (show) {
            if (v.visibility != View.VISIBLE) v.alpha = 0f
            v.visibility = View.VISIBLE
            v.animate().alpha(1f).setDuration(150).start()
        } else {
            v.animate().alpha(0f).setDuration(200).withEndAction { v.visibility = View.GONE }.start()
        }
    }

    /**
     * Audio-only screen: hide lock / PiP / aspect (full screen) / rotate, put prev / play / next
     * at the bottom with seek bar + time (left) + speed right above them. Video keeps the old layout.
     */
    private fun applyAudioLayout() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).roundToInt()
        val vis = if (audioOnly) View.GONE else View.VISIBLE
        b.btnPip.visibility = vis
        // speed control is for audio only
        b.btnSpeed.visibility = if (audioOnly) View.VISIBLE else View.GONE
        b.btnAspect.visibility = vis
        b.btnRotate.visibility = vis
        if (audioOnly) b.btnLock.visibility = View.GONE
        else if (controlsVisible) b.btnLock.visibility = View.VISIBLE

        // prev / play / next
        val clp = b.centerControls.layoutParams as FrameLayout.LayoutParams
        if (audioOnly) {
            clp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            clp.bottomMargin = dp(30)
        } else {
            clp.gravity = Gravity.CENTER
            clp.bottomMargin = 0
        }
        b.centerControls.layoutParams = clp

        // seek bar + time + speed sit right above the buttons
        b.bottomBar.setPadding(
            b.bottomBar.paddingLeft, b.bottomBar.paddingTop,
            b.bottomBar.paddingRight, if (audioOnly) dp(114) else dp(8)
        )
        // time at the far left
        b.timeRow.setPadding(
            if (audioOnly) dp(16) else dp(66), b.timeRow.paddingTop,
            b.timeRow.paddingRight, b.timeRow.paddingBottom
        )
        if (audioOnly && locked) toggleLock()
        applyFitLift()
        if (Build.VERSION.SDK_INT >= 26) updatePipParams()
    }

    private fun showControls(keepPanel: Boolean = false) {
        if (locked || inPip) return
        controlsVisible = true
        fade(b.controlsLayer, true)
        if (!audioOnly) fade(b.btnLock, true)
        if (!keepPanel) scheduleHide()
    }

    private fun hideControls() {
        if (isScrubbing || subtitlePanelVisible) return
        controlsVisible = false
        handler.removeCallbacks(hideRunnable)
        fade(b.controlsLayer, false)
        if (!locked) fade(b.btnLock, false)
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        if (player?.isPlaying == true && controlsVisible && !locked && !subtitlePanelVisible) {
            handler.postDelayed(hideRunnable, HIDE_DELAY)
        }
    }

    private fun toggleLock() {
        locked = !locked
        if (Build.VERSION.SDK_INT >= 26) updatePipParams()
        handler.removeCallbacks(lockHideRunnable)
        if (locked) {
            b.btnLock.setImageResource(R.drawable.ic_lock)
            controlsVisible = false
            handler.removeCallbacks(hideRunnable)
            fade(b.controlsLayer, false)
            showInfo("🔒 Locked")
            handler.postDelayed(lockHideRunnable, LOCK_HIDE_DELAY)
        } else {
            b.btnLock.setImageResource(R.drawable.ic_unlock)
            showInfo("🔓 Unlocked")
            showControls()
        }
    }

    private fun showLockButtonTemporarily() {
        fade(b.btnLock, true)
        handler.removeCallbacks(lockHideRunnable)
        handler.postDelayed(lockHideRunnable, LOCK_HIDE_DELAY)
    }

    private fun showInfo(text: String, persistent: Boolean = false, icon: Int = 0) {
        b.hudLevel.visibility = View.GONE
        b.hudSeek.visibility = View.GONE
        b.tvInfo.text = text
        b.tvInfo.setCompoundDrawablesWithIntrinsicBounds(icon, 0, 0, 0)
        b.tvInfo.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfoRunnable)
        if (!persistent) handler.postDelayed(hideInfoRunnable, 900)
    }

    private fun hideHuds() {
        b.tvInfo.visibility = View.GONE
        b.hudLevel.animate().cancel()
        b.hudLevel.alpha = 1f
        b.hudLevel.visibility = View.GONE
        b.hudSeek.visibility = View.GONE
    }

    private fun hudShowing() =
        b.tvInfo.visibility == View.VISIBLE || b.hudLevel.visibility == View.VISIBLE ||
            b.hudSeek.visibility == View.VISIBLE

    /**
     * Vertical brightness / volume indicator. Volume (right-side swipe) shows its bar on the LEFT,
     * brightness (left-side swipe) shows its bar on the RIGHT, so the finger never covers it.
     */
    private fun showLevel(icon: Int, tint: Int, percent: Int, onRight: Boolean) {
        b.tvInfo.visibility = View.GONE
        b.hudSeek.visibility = View.GONE
        val tintList = android.content.res.ColorStateList.valueOf(tint)
        b.ivHudIcon.setImageResource(icon)
        b.ivHudIcon.imageTintList = tintList
        b.hudFill.backgroundTintList = tintList
        val trackH = (90 * resources.displayMetrics.density).toInt()
        val flp = b.hudFill.layoutParams
        flp.height = (trackH * percent.coerceIn(0, 100) / 100f).toInt()
        b.hudFill.layoutParams = flp
        b.tvHudValue.text = "$percent%"

        val lp = b.hudLevel.layoutParams as android.widget.FrameLayout.LayoutParams
        val margin = (44 * resources.displayMetrics.density).toInt()
        val wantGravity = (if (onRight) android.view.Gravity.END else android.view.Gravity.START) or
            android.view.Gravity.CENTER_VERTICAL
        if (lp.gravity != wantGravity) {
            lp.gravity = wantGravity
            lp.marginStart = if (onRight) 0 else margin
            lp.marginEnd = if (onRight) margin else 0
            b.hudLevel.layoutParams = lp
        }

        if (b.hudLevel.visibility != View.VISIBLE) {
            b.hudLevel.alpha = 0f
            b.hudLevel.visibility = View.VISIBLE
            b.hudLevel.animate().alpha(1f).setDuration(120).start()
        }
        handler.removeCallbacks(hideInfoRunnable)
    }

    /** Swipe-to-seek indicator: direction icon, time change, position and a slim progress bar. */
    private fun showSeekHud(diff: Long, target: Long, dur: Long) {
        b.tvInfo.visibility = View.GONE
        b.hudLevel.visibility = View.GONE
        b.ivSeekIcon.setImageResource(if (diff >= 0) R.drawable.ic_fast_forward else R.drawable.ic_rewind)
        val sign = if (diff >= 0) "+" else "−"
        b.tvSeekDelta.text = "$sign${formatTime(abs(diff))}"
        b.tvSeekPos.text = "${formatTime(target)} / ${formatTime(dur)}"
        b.pbSeekHud.progress = if (dur > 0) (target * 1000 / dur).toInt() else 0
        b.hudSeek.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfoRunnable)
    }

    private fun cycleAspect() {
        resizeIndex = (resizeIndex + 1) % resizeModes.size
        b.playerView.resizeMode = resizeModes[resizeIndex]
        userScale = 1f
        b.playerView.scaleX = 1f
        b.playerView.scaleY = 1f
        showInfo(resizeNames[resizeIndex])
        applyFitLift()
    }

    /** In Fit (screen fit) video mode only: raise bottom controls 15dp. */
    private fun applyFitLift() {
        val lift = if (resizeIndex == 0 && !audioOnly) 15f * resources.displayMetrics.density else 0f
        b.bottomBar.translationY = -lift
        b.btnLock.translationY = -(insetBottom + lift)
    }

    private fun rotateScreen() {
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        orientationAuto = false
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        showInfo(if (landscape) "Portrait" else "Landscape")
    }

    private fun currentBrightness(): Float {
        val v = window.attributes.screenBrightness
        if (v >= 0f) return v
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) {
            0.5f
        }
    }

    // ---------------------------------------------------------------- PiP

    private fun buildPipParams(): PictureInPictureParams {
        var ratio = Rational(16, 9)
        val vs = player?.videoSize
        if (vs != null && vs.width > 0 && vs.height > 0) {
            val r = vs.width * vs.pixelWidthHeightRatio / vs.height
            ratio = when {
                r > 2.39f -> Rational(239, 100)
                r < 0.42f -> Rational(100, 239)
                else -> Rational((r * 1000).roundToInt(), 1000)
            }
        }
        val builder = PictureInPictureParams.Builder().setAspectRatio(ratio)
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setAutoEnterEnabled(player?.isPlaying == true && !locked && !audioOnly)
        }
        return builder.build()
    }

    private var lastPipKey: String? = null

    /** setPictureInPictureParams is a system call; only make it when something actually changed. */
    private fun updatePipParams() {
        try {
            val vs = player?.videoSize
            val key = "${vs?.width}x${vs?.height}:${vs?.pixelWidthHeightRatio}:${player?.isPlaying}:$locked:$audioOnly"
            if (key == lastPipKey) return
            lastPipKey = key
            setPictureInPictureParams(buildPipParams())
        } catch (_: Exception) {
        }
    }

    private fun enterPip() {
        if (!packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            Toast.makeText(this, "Picture-in-picture is not supported", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            enterPictureInPictureMode(buildPipParams())
        } catch (_: Exception) {
            Toast.makeText(this, "Enable picture-in-picture in app settings", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------- dialogs

    private fun showDialog(builder: ModernDialog.Builder) {
        handler.removeCallbacks(hideRunnable)
        val d = builder.create()
        d.setOnDismissListener {
            hideSystemBars()
            scheduleHide()
        }
        d.show()
    }

    private fun showSpeedDialog() {
        val p = player ?: return
        val cur = p.playbackParameters.speed
        val labels = speeds.map { if (it == 1f) "Normal (1×)" else "${trimFloat(it)}×" }.toTypedArray()
        var checked = speeds.indexOfFirst { abs(it - cur) < 0.01f }
        if (checked < 0) checked = 3
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Playback speed")
                .setSingleChoiceItems(labels, checked) { dlg, which ->
                    p.setPlaybackSpeed(speeds[which])
                    currentSpeed = speeds[which]
                    showInfo("Speed ${trimFloat(speeds[which])}×")
                    dlg.dismiss()
                }
        )
    }

    private fun trimFloat(f: Float): String =
        if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString()

    private fun trackName(f: Format, i: Int): String {
        val parts = mutableListOf<String>()
        val lang = f.language?.takeIf { it != "und" && it.isNotBlank() }
            ?.let { Locale.forLanguageTag(it).displayLanguage.ifBlank { it } }
        val label = f.label?.takeIf { it.isNotBlank() }
        if (label != null) parts += label
        if (lang != null && !(label?.contains(lang, ignoreCase = true) ?: false)) parts += lang
        if (f.channelCount > 0) {
            parts += when (f.channelCount) {
                1 -> "Mono"
                2 -> "Stereo"
                6 -> "5.1"
                8 -> "7.1"
                else -> "${f.channelCount}ch"
            }
        }
        f.sampleMimeType?.substringAfter('/')?.uppercase(Locale.ROOT)
            ?.takeIf { f.channelCount > 0 }?.let { parts += it }
        return if (parts.isEmpty()) "Track ${i + 1}" else parts.joinToString(" · ")
    }

    private fun showTrackDialog(trackType: Int, title: String) {
        val p = player ?: return
        val groups = p.currentTracks.groups.filter { it.type == trackType }
        if (groups.isEmpty()) {
            Toast.makeText(this, "No $title available", Toast.LENGTH_SHORT).show()
            return
        }
        data class Entry(val group: Tracks.Group, val idx: Int)

        val entries = mutableListOf<Entry>()
        val names = mutableListOf<String>()
        var checked = -1
        var n = 0
        for (g in groups) {
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                if (g.isTrackSelected(i)) checked = names.size
                entries += Entry(g, i)
                names += trackName(g.getTrackFormat(i), n++)
            }
        }
        val isText = trackType == C.TRACK_TYPE_TEXT
        if (isText) {
            names.add(0, "Off")
            if (p.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT) || checked < 0) checked = 0
            else checked += 1
        }
        showDialog(
            ModernDialog.Builder(this)
                .setTitle(title)
                .setSingleChoiceItems(names.toTypedArray(), checked) { dlg, which ->
                    val params = p.trackSelectionParameters.buildUpon()
                    if (isText && which == 0) {
                        params.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                    } else {
                        val e = entries[if (isText) which - 1 else which]
                        params.setTrackTypeDisabled(trackType, false)
                        params.setOverrideForType(TrackSelectionOverride(e.group.mediaTrackGroup, e.idx))
                    }
                    p.trackSelectionParameters = params.build()
                    dlg.dismiss()
                }
        )
    }

    private fun toggleSubtitlePanel() {
        if (subtitlePanelVisible) hideSubtitlePanel() else showSubtitlePanel()
    }

    private fun showSubtitlePanel() {
        val panel = b.root.findViewById<View>(R.id.subtitlePanel) ?: return
        updateSubtitlePanelUi()
        panel.animate().cancel()
        panel.visibility = View.VISIBLE
        panel.bringToFront()
        val w = (300 * resources.displayMetrics.density)
        panel.translationX = w
        panel.animate().translationX(0f).setDuration(220).start()
        subtitlePanelVisible = true
        // Keep controls visible while panel open
        showControls(true)
    }

    private fun hideSubtitlePanel() {
        val panel = b.root.findViewById<View>(R.id.subtitlePanel) ?: return
        val w = panel.width.toFloat().coerceAtLeast(300f * resources.displayMetrics.density)
        panel.animate().translationX(w).setDuration(180).withEndAction {
            panel.visibility = View.GONE
            panel.translationX = 0f
        }.start()
        subtitlePanelVisible = false
    }

    private fun updateSubtitlePanelUi() {
        val panel = b.root.findViewById<View>(R.id.subtitlePanel) ?: return
        val cb = panel.findViewById<android.widget.CheckBox>(R.id.cbDisableSub)
        val tvSync = panel.findViewById<android.widget.TextView>(R.id.tvSyncValue)
        val tvSpeed = panel.findViewById<android.widget.TextView>(R.id.tvSpeedValue)
        val tvCustom = panel.findViewById<android.widget.TextView>(R.id.tvCustomInfo)
        val tvPreview = panel.findViewById<android.widget.TextView>(R.id.tvSubPreview)

        panel.findViewById<View>(R.id.rowSpeed)?.visibility = if (audioOnly) View.VISIBLE else View.GONE
        cb?.isChecked = subDisabled
        tvSync?.text = String.format("%.1fs", subOffsetSec)
        // Speed here refers to overall playback for simplicity, or keep 100%
        val spd = (player?.playbackParameters?.speed ?: currentSpeed) * 100f
        tvSpeed?.text = String.format("%.1f%%", spd)
        val spSize = (24 * subScale).toInt()
        tvCustom?.text = "${spSize}sp • Margin 8"
        tvPreview?.textSize = 16f * subScale
        tvPreview?.alpha = if (subDisabled) 0.35f else 1f
    }

    private fun setupSubtitlePanelListeners() {
        val panel = b.root.findViewById<View>(R.id.subtitlePanel) ?: return

        panel.findViewById<android.widget.CheckBox>(R.id.cbDisableSub)?.setOnCheckedChangeListener { _, checked ->
            subDisabled = checked
            prefs.edit().putBoolean(KEY_SUB_DISABLED, subDisabled).apply()
            applySubtitleDisabled()
            updateSubtitlePanelUi()
        }

        panel.findViewById<View>(R.id.tvOpenSub)?.setOnClickListener {
            pickSubtitle.launch(arrayOf("*/*"))
        }

        panel.findViewById<View>(R.id.tvOnlineSub)?.setOnClickListener {
            Toast.makeText(this, "Online subtitles coming soon", Toast.LENGTH_SHORT).show()
        }

        panel.findViewById<View>(R.id.btnSyncMinus)?.setOnClickListener {
            subOffsetSec = (subOffsetSec - 0.5f).coerceIn(-30f, 30f)
            prefs.edit().putFloat(KEY_SUB_OFFSET, subOffsetSec).apply()
            applySubtitleOffset()
            updateSubtitlePanelUi()
        }
        panel.findViewById<View>(R.id.btnSyncPlus)?.setOnClickListener {
            subOffsetSec = (subOffsetSec + 0.5f).coerceIn(-30f, 30f)
            prefs.edit().putFloat(KEY_SUB_OFFSET, subOffsetSec).apply()
            applySubtitleOffset()
            updateSubtitlePanelUi()
        }

        panel.findViewById<View>(R.id.btnSpeedMinus)?.setOnClickListener {
            val p = player ?: return@setOnClickListener
            val next = (speeds.indexOfFirst { abs(it - currentSpeed) < 0.01f } - 1).coerceAtLeast(0)
            currentSpeed = speeds[next]
            p.setPlaybackSpeed(currentSpeed)
            updateSubtitlePanelUi()
        }
        panel.findViewById<View>(R.id.btnSpeedPlus)?.setOnClickListener {
            val p = player ?: return@setOnClickListener
            val idx = speeds.indexOfFirst { abs(it - currentSpeed) < 0.01f }
            val next = (if (idx < 0) 3 else idx + 1).coerceAtMost(speeds.lastIndex)
            currentSpeed = speeds[next]
            p.setPlaybackSpeed(currentSpeed)
            updateSubtitlePanelUi()
        }

        panel.findViewById<View>(R.id.tvPanel)?.setOnClickListener {
            // Toggle subtitle track selection panel / choose track
            val p = player
            val hasText = p?.currentTracks?.groups?.any { it.type == C.TRACK_TYPE_TEXT } == true
            if (hasText) showTrackDialog(C.TRACK_TYPE_TEXT, "Subtitles")
            else Toast.makeText(this, "No embedded subtitles", Toast.LENGTH_SHORT).show()
        }

        panel.findViewById<View>(R.id.rowCustomization)?.setOnClickListener {
            showSubtitleSizeDialog()
        }
    }

    private fun applySubtitleDisabled() {
        val p = player ?: return
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, subDisabled)
            .build()
        b.btnSubtitle.alpha = if (subDisabled) 0.55f else 1f
    }

    private fun applySubtitleOffset() {
        // Best-effort: Media3 does not expose a simple global subtitle delay on all versions.
        // We keep the value and apply via track selection / future renderer support.
        // For external SRT the offset can be handled by reloading with adjusted timestamps in advanced builds.
        showInfo(String.format("Subtitle offset: %.1fs", subOffsetSec))
    }

    private fun showSubtitleSizeDialog() {
        val labels = arrayOf("Small", "Normal", "Large", "Extra large")
        val values = floatArrayOf(0.7f, 1f, 1.4f, 1.9f)
        var checked = values.indexOfFirst { abs(it - subScale) < 0.05f }
        if (checked < 0) checked = 1
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Subtitle size")
                .setSingleChoiceItems(labels, checked) { dlg, which ->
                    subScale = values[which]
                    prefs.edit().putFloat(KEY_SUB_SCALE, subScale).apply()
                    b.playerView.subtitleView?.setFractionalTextSize(
                        SubtitleView.DEFAULT_TEXT_SIZE_FRACTION * subScale
                    )
                    updateSubtitlePanelUi()
                    dlg.dismiss()
                }
        )
    }

    /** Set when a subtitle file was just added; the next track list auto-selects it. */
    private var selectExtSubNext = false

    private fun loadExternalSubtitle(uri: Uri) {
        // Copy to a clean local UTF-8 file first (see SubtitleUtil) - this is what makes loading reliable.
        val r = SubtitleUtil.importToCache(this, uri)
        if (r == null) {
            Toast.makeText(this, "Could not read subtitle file", Toast.LENGTH_SHORT).show()
            return
        }
        val p = player
        val idx = p?.currentMediaItemIndex ?: index
        extSubs[idx] = Triple(Uri.fromFile(r.file), r.name, r.mime)
        selectExtSubNext = true
        // a freshly loaded subtitle must be visible, even if "disable subtitles" was ticked before
        subDisabled = false
        prefs.edit().putBoolean(KEY_SUB_DISABLED, false).apply()
        if (p == null) {
            // The picker result arrives while the player is released (activity was stopped).
            // initPlayer() builds its items from extSubs, so the subtitle is applied right there.
            return
        }
        val pos = p.currentPosition
        val wasPlaying = p.playWhenReady
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        p.replaceMediaItem(idx, buildItem(idx))
        p.seekTo(idx, pos)
        p.playWhenReady = wasPlaying
        showInfo("Subtitle loaded")
    }

    /** Explicitly pick the external subtitle track once the player has listed it. */
    private fun selectExternalSubtitleTrack(tracks: Tracks) {
        if (!selectExtSubNext) return
        val p = player ?: return
        val ext = extSubs[p.currentMediaItemIndex] ?: return
        // Only act when OUR subtitle is really in the list. (Before, any embedded track made this
        // give up early and pick the wrong one, so the loaded file stayed hidden.)
        val g = tracks.groups.firstOrNull { grp ->
            grp.type == C.TRACK_TYPE_TEXT &&
                (0 until grp.length).any { grp.getTrackFormat(it).label == ext.second }
        } ?: return // not listed yet; wait for the next callback
        selectExtSubNext = false
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0))
            .build()
    }

    private fun showMoreDialog() {
        val p = player ?: return
        val repeatLabel = when (p.repeatMode) {
            Player.REPEAT_MODE_ONE -> "Repeat: this video"
            Player.REPEAT_MODE_ALL -> "Repeat: all videos"
            else -> "Repeat: off"
        }
        val items = arrayOf(
            repeatLabel,
            "Sleep timer",
            "Volume boost" + if (boostMb > 0) " (+${boostMb / 100} dB)" else "",
            "Screen orientation: " + OrientationPrefs.NAMES[orientMode],
            "Video info"
        )
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("More")
                .setItems(items) { _, which ->
                    when (which) {
                        0 -> {
                            p.repeatMode = when (p.repeatMode) {
                                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
                                Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
                                else -> Player.REPEAT_MODE_OFF
                            }
                            repeatMode = p.repeatMode
                            showInfo(
                                when (p.repeatMode) {
                                    Player.REPEAT_MODE_ONE -> "Repeat this video"
                                    Player.REPEAT_MODE_ALL -> "Repeat all"
                                    else -> "Repeat off"
                                }
                            )
                        }
                        1 -> showSleepDialog()
                        2 -> showBoostDialog()
                        3 -> showOrientationDialog()
                        4 -> showVideoInfo()
                    }
                }
        )
    }

    private var orientMode = OrientationPrefs.SYSTEM

    private fun applyOrientationMode() {
        orientMode = OrientationPrefs.get(prefs)
        autoOrient = orientMode == OrientationPrefs.FIT
        orientationApplied = false
        orientationAuto = true
        requestedOrientation = OrientationPrefs.activityInfoFor(orientMode)
        if (autoOrient) {
            val vs = player?.videoSize
            if (vs != null && vs.width > 0 && vs.height > 0) {
                orientationApplied = true
                requestedOrientation = if (vs.width >= vs.height)
                    ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            }
        }
    }

    private fun showOrientationDialog() {
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Default screen orientation")
                .setSingleChoiceItems(OrientationPrefs.NAMES, orientMode) { dlg, which ->
                    OrientationPrefs.set(prefs, which)
                    applyOrientationMode()
                    showInfo(OrientationPrefs.NAMES[which])
                    dlg.dismiss()
                }
        )
    }

    private fun showSleepDialog() {
        val labels = arrayOf("Off", "10 minutes", "15 minutes", "30 minutes", "45 minutes", "60 minutes", "90 minutes")
        val mins = intArrayOf(0, 10, 15, 30, 45, 60, 90)
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Sleep timer")
                .setItems(labels) { _, which ->
                    sleepRunnable?.let { handler.removeCallbacks(it) }
                    sleepRunnable = null
                    if (mins[which] > 0) {
                        val r = Runnable {
                            player?.pause()
                            Toast.makeText(this, "Sleep timer: paused", Toast.LENGTH_LONG).show()
                        }
                        sleepRunnable = r
                        handler.postDelayed(r, mins[which] * 60_000L)
                        showInfo("Sleep in ${mins[which]} min")
                    } else {
                        showInfo("Sleep timer off")
                    }
                }
        )
    }

    private fun showBoostDialog() {
        val labels = arrayOf("Off", "+3 dB", "+6 dB", "+9 dB", "+12 dB")
        val values = intArrayOf(0, 300, 600, 900, 1200)
        var checked = values.indexOf(boostMb)
        if (checked < 0) checked = 0
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Volume boost")
                .setSingleChoiceItems(labels, checked) { dlg, which ->
                    boostMb = values[which]
                    try {
                        loudness?.setTargetGain(boostMb)
                        loudness?.enabled = boostMb > 0
                    } catch (_: Exception) {
                    }
                    showInfo(if (boostMb > 0) "Boost +${boostMb / 100} dB" else "Boost off")
                    dlg.dismiss()
                }
        )
    }

    private fun showVideoInfo() {
        val p = player ?: return
        val v = p.videoFormat
        val a = p.audioFormat
        val sb = StringBuilder()
        sb.append("Title: ").append(titles.getOrNull(p.currentMediaItemIndex) ?: "-").append('\n')
        if (p.duration != C.TIME_UNSET) sb.append("Duration: ").append(formatTime(p.duration)).append('\n')
        if (v != null) {
            sb.append("Video: ").append(v.width).append('×').append(v.height)
            if (v.frameRate > 0) sb.append(" @ ").append(String.format(Locale.US, "%.2f", v.frameRate)).append(" fps")
            sb.append('\n')
            v.sampleMimeType?.let { sb.append("Video codec: ").append(it.substringAfter('/')).append('\n') }
            if (v.bitrate > 0) sb.append("Video bitrate: ").append(v.bitrate / 1000).append(" kbps\n")
        }
        if (a != null) {
            a.sampleMimeType?.let { sb.append("Audio codec: ").append(it.substringAfter('/')).append('\n') }
            if (a.channelCount > 0) sb.append("Channels: ").append(a.channelCount).append('\n')
            if (a.sampleRate > 0) sb.append("Sample rate: ").append(a.sampleRate).append(" Hz\n")
        }
        sb.append("Source: ").append(uris.getOrNull(p.currentMediaItemIndex) ?: "-")
        showDialog(
            ModernDialog.Builder(this)
                .setTitle("Video info")
                .setMessage(sb.toString())
                .setPositiveButton("OK", null)
        )
    }

    // ---------------------------------------------------------------- keys

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN && !locked) {
            when (e.keyCode) {
                KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    togglePlay(); return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    seekBy(-SEEK_STEP); return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    seekBy(SEEK_STEP); return true
                }
                KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    player?.seekToNextMediaItem(); return true
                }
                KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    player?.seekToPreviousMediaItem(); return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }
}
