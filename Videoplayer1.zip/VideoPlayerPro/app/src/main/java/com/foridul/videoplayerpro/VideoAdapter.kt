package com.foridul.videoplayerpro

import android.net.Uri
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.foridul.videoplayerpro.databinding.ItemVideoBinding

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val size: Long
)

fun formatTime(ms: Long): String {
    if (ms < 0) return "00:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

class VideoAdapter(
    private val onClick: (list: List<VideoItem>, position: Int) -> Unit
) : RecyclerView.Adapter<VideoAdapter.VH>() {

    private var all: List<VideoItem> = emptyList()
    private var shown: List<VideoItem> = emptyList()

    fun submit(items: List<VideoItem>) {
        all = items
        shown = items
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        val q = query.trim().lowercase()
        shown = if (q.isEmpty()) all else all.filter { it.title.lowercase().contains(q) }
        notifyDataSetChanged()
    }

    fun count() = shown.size

    class VH(val b: ItemVideoBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemVideoBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = shown.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = shown[position]
        val ctx = holder.itemView.context
        holder.b.tvTitle.text = item.title
        holder.b.tvDuration.text = formatTime(item.durationMs)
        holder.b.tvMeta.text = Formatter.formatShortFileSize(ctx, item.size)
        Glide.with(holder.b.ivThumb).load(item.uri).centerCrop().into(holder.b.ivThumb)
        holder.itemView.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onClick(shown, pos)
        }
    }
}
