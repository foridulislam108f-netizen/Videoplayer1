package com.foridul.videoplayerpro

import android.net.Uri
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

/** One playable file from the device library (video or audio). */
data class LibItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val size: Long,
    val dateAdded: Long,
    val folderKey: String,
    val isAudio: Boolean
)

sealed class Row {
    data class Folder(
        val key: String,
        val name: String,
        val count: Int,
        val fresh: Int,
        val isAudio: Boolean,
        val smart: Boolean = false,
        val icon: Int = 0
    ) : Row()

    data class Media(val item: LibItem) : Row()
}

fun formatTime(ms: Long): String {
    if (ms < 0) return "00:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

class RowAdapter(
    private val onFolder: (Row.Folder) -> Unit,
    private val onFolderMenu: (View, Row.Folder) -> Unit,
    private val onMedia: (Int) -> Unit,
    private val onMediaLong: (LibItem) -> Unit = {},
    private val onFolderLong: (Row.Folder) -> Unit = {},
    private val onSelectionChanged: () -> Unit = {}
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var isFav: (LibItem) -> Boolean = { false }

    private var dimmedView: View? = null
    fun clearDim() {
        dimmedView?.alpha = 1f
        dimmedView = null
    }

    private var rows: List<Row> = emptyList()
    var grid: Boolean = false

    /** Multi-select state — media keyed by uri string, folders by "f:" + key */
    var selectionMode: Boolean = false
        private set
    private val selectedMedia = linkedSetOf<String>()
    private val selectedFolders = linkedSetOf<String>()

    fun selectedCount(): Int = selectedMedia.size + selectedFolders.size

    fun selectedItems(): List<LibItem> =
        rows.mapNotNull { (it as? Row.Media)?.item }.filter { selectedMedia.contains(it.uri.toString()) }

    fun selectedFolderRows(): List<Row.Folder> =
        rows.mapNotNull { it as? Row.Folder }.filter { selectedFolders.contains(it.key) }

    fun isSelected(item: LibItem): Boolean = selectedMedia.contains(item.uri.toString())
    fun isFolderSelected(folder: Row.Folder): Boolean = selectedFolders.contains(folder.key)

    fun enterSelection(item: LibItem) {
        selectionMode = true
        selectedMedia.clear()
        selectedFolders.clear()
        selectedMedia.add(item.uri.toString())
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun enterFolderSelection(folder: Row.Folder) {
        selectionMode = true
        selectedMedia.clear()
        selectedFolders.clear()
        selectedFolders.add(folder.key)
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun toggleSelect(item: LibItem) {
        if (!selectionMode) return
        val key = item.uri.toString()
        if (selectedMedia.contains(key)) {
            selectedMedia.remove(key)
        } else {
            selectedMedia.add(key)
        }
        if (selectedMedia.isEmpty() && selectedFolders.isEmpty()) {
            exitSelection()
            return
        }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun toggleFolderSelect(folder: Row.Folder) {
        if (!selectionMode) return
        val key = folder.key
        if (selectedFolders.contains(key)) {
            selectedFolders.remove(key)
        } else {
            selectedFolders.add(key)
        }
        if (selectedMedia.isEmpty() && selectedFolders.isEmpty()) {
            exitSelection()
            return
        }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun exitSelection() {
        if (!selectionMode && selectedMedia.isEmpty() && selectedFolders.isEmpty()) return
        selectionMode = false
        selectedMedia.clear()
        selectedFolders.clear()
        clearDim()
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun submit(list: List<Row>) {
        rows = list
        if (selectionMode) {
            val presentMedia = list.mapNotNull { (it as? Row.Media)?.item?.uri?.toString() }.toSet()
            val presentFolders = list.mapNotNull { (it as? Row.Folder)?.key }.toSet()
            selectedMedia.retainAll(presentMedia)
            selectedFolders.retainAll(presentFolders)
            if (selectedMedia.isEmpty() && selectedFolders.isEmpty()) {
                selectionMode = false
            }
        }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun count() = rows.size

    class VH(v: View) : RecyclerView.ViewHolder(v)

    override fun getItemViewType(position: Int): Int {
        val folder = rows[position] is Row.Folder
        return (if (folder) 0 else 2) + (if (grid) 1 else 0)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = when (viewType) {
            0 -> R.layout.item_folder
            1 -> R.layout.item_folder_grid
            2 -> R.layout.item_video
            else -> R.layout.item_video_grid
        }
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun getItemCount() = rows.size

    private fun attachCheckBadge(parent: ViewGroup, ctx: android.content.Context, visible: Boolean) {
        var badge = parent.findViewWithTag<ImageView>("sel_check")
        if (visible) {
            if (badge == null) {
                badge = ImageView(ctx).apply {
                    tag = "sel_check"
                    setImageResource(R.drawable.ic_check)
                    setBackgroundResource(R.drawable.bg_red_badge)
                    val s = Ui.dp(ctx, 22)
                    layoutParams = android.widget.FrameLayout.LayoutParams(s, s).apply {
                        gravity = android.view.Gravity.TOP or android.view.Gravity.START
                        setMargins(Ui.dp(ctx, 6), Ui.dp(ctx, 6), 0, 0)
                    }
                    setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3))
                    imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt())
                }
                parent.addView(badge)
            }
            badge.visibility = View.VISIBLE
        } else {
            badge?.visibility = View.GONE
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val v = holder.itemView
        v.alpha = 1f
        when (val row = rows[position]) {
            is Row.Folder -> {
                val ctx = v.context
                v.findViewById<TextView>(R.id.tvName).text = row.name
                val nounSing = if (row.isAudio) ctx.getString(R.string.song) else ctx.getString(R.string.video)
                val nounPl = if (row.isAudio) ctx.getString(R.string.songs) else ctx.getString(R.string.videos)
                v.findViewById<TextView>(R.id.tvCount).text =
                    if (row.count == 1) "1 $nounSing" else "${row.count} $nounPl"
                val icon = v.findViewById<ImageView>(R.id.ivIcon)
                if (row.icon != 0) {
                    icon.setImageResource(row.icon)
                    icon.imageTintList = android.content.res.ColorStateList.valueOf(
                        Ui.color(ctx, R.color.accent)
                    )
                } else {
                    icon.setImageResource(R.drawable.ic_folder_fill)
                    icon.imageTintList = android.content.res.ColorStateList.valueOf(
                        Ui.color(ctx, R.color.folder)
                    )
                }
                val badge = v.findViewById<TextView>(R.id.tvBadge)
                if (row.fresh > 0) {
                    badge.text = if (row.fresh > 99) "99+" else row.fresh.toString()
                    badge.visibility = View.VISIBLE
                } else {
                    badge.visibility = View.GONE
                }

                val selected = selectionMode && isFolderSelected(row)
                v.alpha = if (selected) 0.85f else 1f
                // Put check on icon parent if possible
                val iconParent = icon.parent as? ViewGroup
                if (iconParent != null) attachCheckBadge(iconParent, ctx, selected)

                v.setOnClickListener {
                    if (selectionMode) toggleFolderSelect(row)
                    else onFolder(row)
                }
                v.setOnLongClickListener {
                    if (selectionMode) toggleFolderSelect(row)
                    else onFolderLong(row)
                    true
                }
                val menu = v.findViewById<ImageButton>(R.id.btnMenu)
                menu.setOnClickListener { onFolderMenu(menu, row) }
                // Hide overflow menu while selecting
                menu.visibility = if (selectionMode) View.INVISIBLE else View.VISIBLE
            }
            is Row.Media -> {
                val item = row.item
                val ctx = v.context
                v.findViewById<TextView>(R.id.tvTitle).text = item.title
                val dur = v.findViewById<TextView>(R.id.tvDuration)
                if (item.durationMs > 0) {
                    dur.text = formatTime(item.durationMs)
                    dur.visibility = View.VISIBLE
                } else {
                    dur.visibility = View.GONE
                }
                val meta =
                    if (item.size > 0) Formatter.formatShortFileSize(ctx, item.size) else "Stream"
                v.findViewById<TextView>(R.id.tvMeta).text = if (isFav(item)) "$meta  ♥" else meta
                val thumb = v.findViewById<ImageView>(R.id.ivThumb)
                Glide.with(thumb).clear(thumb)
                if (item.isAudio || item.id == -1L) {
                    val pad = Ui.dp(ctx, 22)
                    thumb.setPadding(pad, pad, pad, pad)
                    thumb.scaleType = ImageView.ScaleType.FIT_CENTER
                    thumb.setImageResource(if (item.isAudio) R.drawable.ic_music_big else R.drawable.ic_link)
                    thumb.imageTintList = android.content.res.ColorStateList.valueOf(
                        Ui.color(ctx, R.color.accent)
                    )
                } else {
                    thumb.setPadding(0, 0, 0, 0)
                    thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                    thumb.imageTintList = null
                    Glide.with(thumb).load(item.uri).centerCrop().into(thumb)
                }

                val selected = selectionMode && isSelected(item)
                val thumbParent = thumb.parent as? ViewGroup
                if (selected) {
                    v.alpha = 0.92f
                    if (thumbParent != null) attachCheckBadge(thumbParent, ctx, true)
                } else {
                    v.alpha = 1f
                    if (thumbParent != null) attachCheckBadge(thumbParent, ctx, false)
                }

                v.setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
                    if (selectionMode) toggleSelect(item)
                    else onMedia(pos)
                }
                v.setOnLongClickListener {
                    if (selectionMode) toggleSelect(item)
                    else {
                        clearDim()
                        onMediaLong(item)
                    }
                    true
                }
            }
        }
    }
}
