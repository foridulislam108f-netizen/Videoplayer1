package com.foridul.videoplayerpro

import android.net.Uri
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

/** One playable file from the device library (video or audio). */
data class LibItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val size: Long,
    val dateAdded: Long,
    val folderKey: String,
    val isAudio: Boolean
)

sealed class Row {
    data class Folder(
        val key: String,
        val name: String,
        val count: Int,
        val fresh: Int,
        val isAudio: Boolean,
        val smart: Boolean = false,
        val icon: Int = 0
    ) : Row()

    data class Media(val item: LibItem) : Row()
}

fun formatTime(ms: Long): String {
    if (ms < 0) return "00:00"
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%02d:%02d", m, s)
}

class RowAdapter(
    private val onFolder: (Row.Folder) -> Unit,
    private val onFolderMenu: (View, Row.Folder) -> Unit,
    private val onMedia: (Int) -> Unit,
    private val onMediaLong: (LibItem) -> Unit = {},
    private val onSelectionChanged: () -> Unit = {}
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var isFav: (LibItem) -> Boolean = { false }

    private var dimmedView: View? = null
    fun clearDim() {
        dimmedView?.alpha = 1f
        dimmedView = null
    }

    private var rows: List<Row> = emptyList()
    var grid: Boolean = false

    /** Multi-select state */
    var selectionMode: Boolean = false
        private set
    private val selectedKeys = linkedSetOf<String>()

    fun selectedCount(): Int = selectedKeys.size

    fun selectedItems(): List<LibItem> =
        rows.mapNotNull { (it as? Row.Media)?.item }.filter { selectedKeys.contains(it.uri.toString()) }

    fun isSelected(item: LibItem): Boolean = selectedKeys.contains(item.uri.toString())

    fun enterSelection(item: LibItem) {
        selectionMode = true
        selectedKeys.clear()
        selectedKeys.add(item.uri.toString())
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun toggleSelect(item: LibItem) {
        if (!selectionMode) return
        val key = item.uri.toString()
        if (selectedKeys.contains(key)) {
            selectedKeys.remove(key)
            if (selectedKeys.isEmpty()) {
                exitSelection()
                return
            }
        } else {
            selectedKeys.add(key)
        }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun exitSelection() {
        if (!selectionMode && selectedKeys.isEmpty()) return
        selectionMode = false
        selectedKeys.clear()
        clearDim()
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun submit(list: List<Row>) {
        rows = list
        // Drop selections that no longer exist
        if (selectionMode) {
            val present = list.mapNotNull { (it as? Row.Media)?.item?.uri?.toString() }.toSet()
            selectedKeys.retainAll(present)
            if (selectedKeys.isEmpty()) {
                selectionMode = false
            }
        }
        notifyDataSetChanged()
        onSelectionChanged()
    }

    fun count() = rows.size

    class VH(v: View) : RecyclerView.ViewHolder(v)

    override fun getItemViewType(position: Int): Int {
        val folder = rows[position] is Row.Folder
        return (if (folder) 0 else 2) + (if (grid) 1 else 0)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = when (viewType) {
            0 -> R.layout.item_folder
            1 -> R.layout.item_folder_grid
            2 -> R.layout.item_video
            else -> R.layout.item_video_grid
        }
        return VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))
    }

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val v = holder.itemView
        v.alpha = 1f
        when (val row = rows[position]) {
            is Row.Folder -> {
                val ctx = v.context
                v.findViewById<TextView>(R.id.tvName).text = row.name
                val nounSing = if (row.isAudio) ctx.getString(R.string.song) else ctx.getString(R.string.video)
                val nounPl = if (row.isAudio) ctx.getString(R.string.songs) else ctx.getString(R.string.videos)
                v.findViewById<TextView>(R.id.tvCount).text =
                    if (row.count == 1) "1 $nounSing" else "${row.count} $nounPl"
                val icon = v.findViewById<ImageView>(R.id.ivIcon)
                if (row.icon != 0) {
                    icon.setImageResource(row.icon)
                    icon.imageTintList = android.content.res.ColorStateList.valueOf(
                        Ui.color(ctx, R.color.accent)
                    )
                } else {
                    icon.setImageResource(R.drawable.ic_folder_fill)
                    icon.imageTintList = android.content.res.ColorStateList.valueOf(
                        Ui.color(ctx, R.color.folder)
                    )
                }
                val badge = v.findViewById<TextView>(R.id.tvBadge)
                if (row.fresh > 0) {
                    badge.text = if (row.fresh > 99) "99+" else row.fresh.toString()
                    badge.visibility = View.VISIBLE
                } else {
                    badge.visibility = View.GONE
                }
                v.setOnClickListener { onFolder(row) }
                val menu = v.findViewById<ImageButton>(R.id.btnMenu)
                menu.setOnClickListener { onFolderMenu(menu, row) }
            }
            is Row.Media -> {
                val item = row.item
                val ctx = v.context
                v.findViewById<TextView>(R.id.tvTitle).text = item.title
                val dur = v.findViewById<TextView>(R.id.tvDuration)
                if (item.durationMs > 0) {
                    dur.text = formatTime(item.durationMs)
                    dur.visibility = View.VISIBLE
                } else {
                    dur.visibility = View.GONE
                }
                val meta =
                    if (item.size > 0) Formatter.formatShortFileSize(ctx, item.size) else "Stream"
                v.findViewById<TextView>(R.id.tvMeta).text = if (isFav(item)) "$meta  ♥" else meta
                val thumb = v.findViewById<ImageView>(R.id.ivThumb)
                Glide.with(thumb).clear(thumb)
                if (item.isAudio || item.id == -1L) {
                    val pad = Ui.dp(ctx, 22)
                    thumb.setPadding(pad, pad, pad, pad)
                    thumb.scaleType = ImageView.ScaleType.FIT_CENTER
                    thumb.setImageResource(if (item.isAudio) R.drawable.ic_music_big else R.drawable.ic_link)
                    thumb.imageTintList = android.content.res.ColorStateList.valueOf(
                        Ui.color(ctx, R.color.accent)
                    )
                } else {
                    thumb.setPadding(0, 0, 0, 0)
                    thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                    thumb.imageTintList = null
                    Glide.with(thumb).load(item.uri).centerCrop().into(thumb)
                }

                val selected = selectionMode && isSelected(item)
                // Visual selection: check overlay on thumbnail
                val thumbParent = thumb.parent as? ViewGroup
                if (selected) {
                    v.alpha = 0.92f
                    if (thumbParent != null) {
                        var badge = thumbParent.findViewWithTag<ImageView>("sel_check")
                        if (badge == null) {
                            badge = ImageView(ctx).apply {
                                tag = "sel_check"
                                setImageResource(R.drawable.ic_check)
                                setBackgroundResource(R.drawable.bg_red_badge)
                                val s = Ui.dp(ctx, 22)
                                layoutParams = android.widget.FrameLayout.LayoutParams(s, s).apply {
                                    gravity = android.view.Gravity.TOP or android.view.Gravity.START
                                    setMargins(Ui.dp(ctx, 6), Ui.dp(ctx, 6), 0, 0)
                                }
                                setPadding(Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3), Ui.dp(ctx, 3))
                                imageTintList = android.content.res.ColorStateList.valueOf(0xFFFFFFFF.toInt())
                            }
                            thumbParent.addView(badge)
                        }
                        badge.visibility = View.VISIBLE
                    }
                } else {
                    v.alpha = 1f
                    thumbParent?.findViewWithTag<View>("sel_check")?.visibility = View.GONE
                }

                v.setOnClickListener {
                    val pos = holder.bindingAdapterPosition
                    if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
                    if (selectionMode) {
                        toggleSelect(item)
                    } else {
                        onMedia(pos)
                    }
                }
                v.setOnLongClickListener {
                    if (selectionMode) {
                        toggleSelect(item)
                    } else {
                        clearDim()
                        onMediaLong(item)
                    }
                    true
                }
            }
        }
    }
}
