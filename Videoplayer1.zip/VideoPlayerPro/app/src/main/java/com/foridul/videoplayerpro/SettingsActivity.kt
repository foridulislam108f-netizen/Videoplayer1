package com.foridul.videoplayerpro

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.foridul.videoplayerpro.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    companion object {
        const val PREFS = "player_settings"
        const val KEY_RESUME = "resume_mode"          // 0=ask, 1=always, 2=never
        const val KEY_BRIGHTNESS = "remember_brightness"
        const val KEY_BG_PLAY = "remember_bg_play"
        const val KEY_ASPECT = "remember_aspect"
        const val KEY_SPEED = "remember_speed"
        const val KEY_ORIENTATION = "orientation"     // 0=auto, 1=portrait, 2=landscape
        const val KEY_SEEK_STEP = "seek_step_sec"     // 5,10,15,30
        const val KEY_AUTOPLAY = "autoplay_next"
        const val KEY_AUTO_PIP = "auto_pip"
        const val KEY_GESTURES = "gestures"
        const val KEY_SUBTITLES = "show_subtitles"
        const val KEY_AUDIO_LANG = "audio_lang"
        const val KEY_SUB_LANG = "sub_lang"
        const val KEY_MUSIC = "show_music"
        const val KEY_RECENT = "show_recent"
        const val KEY_FLOATING = "show_floating"
    }

    private lateinit var b: ActivitySettingsBinding
    private lateinit var prefs: SharedPreferences

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNullOrEmpty()) return@registerForActivityResult
            uris.forEach {
                try {
                    contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
            }
            startPlayer(uris.map { it.toString() }, uris.map { displayName(it) }, 0)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        b.btnBack.setOnClickListener { finish() }

        // Load switches
        b.swBrightness.isChecked = prefs.getBoolean(KEY_BRIGHTNESS, true)
        b.swBgPlay.isChecked = prefs.getBoolean(KEY_BG_PLAY, true)
        b.swAspect.isChecked = prefs.getBoolean(KEY_ASPECT, true)
        b.swSpeed.isChecked = prefs.getBoolean(KEY_SPEED, true)
        b.swAutoplay.isChecked = prefs.getBoolean(KEY_AUTOPLAY, true)
        b.swAutoPip.isChecked = prefs.getBoolean(KEY_AUTO_PIP, false)
        b.swGestures.isChecked = prefs.getBoolean(KEY_GESTURES, true)
        b.swSubtitles.isChecked = prefs.getBoolean(KEY_SUBTITLES, true)
        b.swMusic.isChecked = prefs.getBoolean(KEY_MUSIC, true)
        b.swRecent.isChecked = prefs.getBoolean(KEY_RECENT, true)
        b.swFloating.isChecked = prefs.getBoolean(KEY_FLOATING, true)

        updateResumeLabel()
        updateOrientationLabel()
        updateSeekStepLabel()
        updateLangLabels()

        // Switch listeners
        b.swBrightness.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_BRIGHTNESS, v).apply() }
        b.swBgPlay.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_BG_PLAY, v).apply() }
        b.swAspect.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_ASPECT, v).apply() }
        b.swSpeed.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_SPEED, v).apply() }
        b.swAutoplay.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_AUTOPLAY, v).apply() }
        b.swAutoPip.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_AUTO_PIP, v).apply() }
        b.swGestures.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_GESTURES, v).apply() }
        b.swSubtitles.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_SUBTITLES, v).apply() }
        b.swMusic.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_MUSIC, v).apply() }
        b.swRecent.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_RECENT, v).apply() }
        b.swFloating.setOnCheckedChangeListener { _, v -> prefs.edit().putBoolean(KEY_FLOATING, v).apply() }

        // Choice rows
        b.rowResume.setOnClickListener {
            val labels = arrayOf("Ask every time", "Always resume", "Never resume")
            AlertDialog.Builder(this)
                .setTitle("Resume playback")
                .setItems(labels) { _, which ->
                    prefs.edit().putInt(KEY_RESUME, which).apply()
                    updateResumeLabel()
                }.show()
        }

        b.rowOrientation.setOnClickListener {
            val labels = arrayOf("Auto rotate (video)", "Portrait", "Landscape")
            AlertDialog.Builder(this)
                .setTitle("Default screen orientation")
                .setItems(labels) { _, which ->
                    prefs.edit().putInt(KEY_ORIENTATION, which).apply()
                    updateOrientationLabel()
                }.show()
        }

        b.rowSeekStep.setOnClickListener {
            val labels = arrayOf("5s", "10s", "15s", "30s")
            val values = intArrayOf(5, 10, 15, 30)
            AlertDialog.Builder(this)
                .setTitle("Fast forward / rewind")
                .setItems(labels) { _, which ->
                    prefs.edit().putInt(KEY_SEEK_STEP, values[which]).apply()
                    updateSeekStepLabel()
                }.show()
        }

        b.rowAudioLang.setOnClickListener {
            val labels = arrayOf("No preference", "English", "বাংলা", "Hindi", "Arabic", "Spanish")
            val codes = arrayOf("", "en", "bn", "hi", "ar", "es")
            AlertDialog.Builder(this)
                .setTitle("Preferred audio language")
                .setItems(labels) { _, which ->
                    prefs.edit().putString(KEY_AUDIO_LANG, codes[which]).apply()
                    updateLangLabels()
                }.show()
        }

        b.rowSubLang.setOnClickListener {
            val labels = arrayOf("No preference", "English", "বাংলা", "Hindi", "Arabic", "Spanish")
            val codes = arrayOf("", "en", "bn", "hi", "ar", "es")
            AlertDialog.Builder(this)
                .setTitle("Preferred subtitle language")
                .setItems(labels) { _, which ->
                    prefs.edit().putString(KEY_SUB_LANG, codes[which]).apply()
                    updateLangLabels()
                }.show()
        }

        b.rowOpenFiles.setOnClickListener {
            pickFiles.launch(arrayOf("video/*", "audio/*"))
        }

        b.rowStream.setOnClickListener { showStreamDialog() }

        b.rowAbout.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Video Player Pro")
                .setMessage("Version 1.0.0\n\n4K / HEVC / AV1 ready\nFolder library · Music · Gestures · PiP · Subtitles")
                .setPositiveButton("OK", null)
                .show()
        }

        b.rowFeedback.setOnClickListener {
            Toast.makeText(this, "Thanks! Feedback coming soon.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateResumeLabel() {
        val v = when (prefs.getInt(KEY_RESUME, 0)) {
            1 -> "Always resume"
            2 -> "Never resume"
            else -> "Ask every time"
        }
        b.tvResumeValue.text = v
    }

    private fun updateOrientationLabel() {
        val v = when (prefs.getInt(KEY_ORIENTATION, 0)) {
            1 -> "Portrait"
            2 -> "Landscape"
            else -> "Auto rotate (video)"
        }
        b.tvOrientationValue.text = v
    }

    private fun updateSeekStepLabel() {
        b.tvSeekStepValue.text = "${prefs.getInt(KEY_SEEK_STEP, 10)}s"
    }

    private fun updateLangLabels() {
        fun name(code: String) = when (code) {
            "en" -> "English"
            "bn" -> "বাংলা"
            "hi" -> "Hindi"
            "ar" -> "Arabic"
            "es" -> "Spanish"
            else -> "No language preference"
        }
        b.tvAudioLang.text = name(prefs.getString(KEY_AUDIO_LANG, "") ?: "")
        b.tvSubLang.text = name(prefs.getString(KEY_SUB_LANG, "") ?: "")
    }

    private fun showStreamDialog() {
        val input = EditText(this).apply {
            hint = "https://example.com/video.m3u8"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFA6A6B0.toInt())
            setPadding(48, 36, 48, 36)
        }
        AlertDialog.Builder(this)
            .setTitle("Network stream")
            .setView(input)
            .setPositiveButton("Play") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isEmpty()) {
                    Toast.makeText(this, "Enter a URL", Toast.LENGTH_SHORT).show()
                } else {
                    startPlayer(listOf(url), listOf(Uri.parse(url).lastPathSegment ?: url), 0)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun displayName(uri: Uri): String {
        if (uri.scheme == "content") {
            try {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) return it.getString(0)
                }
            } catch (_: Exception) {
            }
        }
        return uri.lastPathSegment ?: uri.toString()
    }

    private fun startPlayer(uris: List<String>, titles: List<String>, index: Int) {
        val i = Intent(this, PlayerActivity::class.java).apply {
            putStringArrayListExtra(PlayerActivity.EXTRA_URIS, ArrayList(uris))
            putStringArrayListExtra(PlayerActivity.EXTRA_TITLES, ArrayList(titles))
            putExtra(PlayerActivity.EXTRA_INDEX, index)
        }
        startActivity(i)
    }
}
