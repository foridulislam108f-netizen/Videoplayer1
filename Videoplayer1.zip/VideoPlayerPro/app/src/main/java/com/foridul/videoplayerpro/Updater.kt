package com.foridul.videoplayerpro

import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Checks the GitHub "latest" release and offers to download the newer APK. */
object Updater {
    fun check(activity: AppCompatActivity, silent: Boolean = false) {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isEmpty()) {
            if (!silent) Toast.makeText(activity, "Update source not set (build via GitHub Actions)", Toast.LENGTH_LONG).show()
            return
        }
        if (!silent) Toast.makeText(activity, "Checking for updates…", Toast.LENGTH_SHORT).show()
        val ui = Handler(Looper.getMainLooper())
        thread {
            try {
                val c = URL("https://api.github.com/repos/$repo/releases/tags/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                if (c.responseCode != 200) throw Exception("HTTP ${c.responseCode}")
                val json = JSONObject(c.inputStream.bufferedReader().readText())
                val name = json.optString("name")
                val build = Regex("build (\\d+)").find(name)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val assets = json.optJSONArray("assets")
                var url = ""
                if (assets != null) for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk")) url = a.optString("browser_download_url")
                }
                ui.post {
                    if (activity.isFinishing) return@post
                    if (url.isNotEmpty() && build > BuildConfig.RUN_NUMBER) {
                        ModernDialog.Builder(activity)
                            .setTitle("Update available")
                            .setMessage("A new version ($name) is ready. Download it and install over the current app - your data stays.")
                            .setPositiveButton("Download") { _, _ ->
                                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            }
                            .setNegativeButton("Later")
                            .show()
                    } else if (!silent) {
                        Toast.makeText(activity, "You have the latest version", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                if (!silent) ui.post { Toast.makeText(activity, "Update check failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }
}
