# Media3 / Glide keep rules are bundled with the libraries.
